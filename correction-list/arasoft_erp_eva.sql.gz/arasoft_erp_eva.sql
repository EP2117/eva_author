-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 09, 2018 at 07:04 PM
-- Server version: 5.6.38
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `arasoft_erp_eva`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_expense_payable`
--

CREATE TABLE `account_expense_payable` (
  `expensePayId` int(11) NOT NULL,
  `exP_branchid` int(11) NOT NULL,
  `exP_payable_typ` varchar(20) NOT NULL,
  `exP_payment_mode` varchar(20) NOT NULL,
  `exP_credit_ac` varchar(20) NOT NULL,
  `exP_debit_ac` varchar(20) NOT NULL,
  `exP_amount` decimal(11,2) NOT NULL,
  `exP_expense_date` date NOT NULL,
  `exP_ref_details` varchar(25) NOT NULL,
  `exP_narration` varchar(20) NOT NULL,
  `exP_request_by` varchar(20) NOT NULL,
  `exP_approval_by` varchar(20) NOT NULL,
  `exP_company_id` int(11) NOT NULL,
  `exP_added_by` int(11) NOT NULL,
  `exP_added_on` datetime NOT NULL,
  `exP_added_ip` varchar(20) NOT NULL,
  `exP_modified_by` int(11) NOT NULL,
  `exP_modified_on` datetime NOT NULL,
  `exP_modified_ip` varchar(20) NOT NULL,
  `exP_deleted_by` int(11) NOT NULL,
  `exP_deleted_on` datetime NOT NULL,
  `exP_deleted_ip` varchar(20) NOT NULL,
  `exP_deleted_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `account_heads`
--

CREATE TABLE `account_heads` (
  `account_head_id` int(11) NOT NULL,
  `account_head_code` varchar(100) NOT NULL,
  `account_head_name` varchar(60) NOT NULL,
  `account_head_type1` varchar(30) NOT NULL,
  `account_head_type2` varchar(30) NOT NULL,
  `account_head_type3` int(11) NOT NULL,
  `account_customized_type` varchar(255) NOT NULL,
  `account_head_company_id` int(11) NOT NULL,
  `account_head_branch_id` int(11) NOT NULL,
  `account_head_financial_year` varchar(20) NOT NULL,
  `account_head_added_by` int(11) NOT NULL,
  `account_head_added_on` int(11) NOT NULL,
  `account_head_added_ip` varchar(20) NOT NULL,
  `account_head_modified_by` int(11) NOT NULL,
  `account_head_modified_on` int(11) NOT NULL,
  `account_head_modified_ip` varchar(20) NOT NULL,
  `account_head_deleted_by` int(11) NOT NULL,
  `account_head_deleted_on` int(11) NOT NULL,
  `account_head_deleted_ip` varchar(20) NOT NULL,
  `account_head_active_status` varchar(20) NOT NULL DEFAULT 'active',
  `account_head_deleted_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account_heads`
--

INSERT INTO `account_heads` (`account_head_id`, `account_head_code`, `account_head_name`, `account_head_type1`, `account_head_type2`, `account_head_type3`, `account_customized_type`, `account_head_company_id`, `account_head_branch_id`, `account_head_financial_year`, `account_head_added_by`, `account_head_added_on`, `account_head_added_ip`, `account_head_modified_by`, `account_head_modified_on`, `account_head_modified_ip`, `account_head_deleted_by`, `account_head_deleted_on`, `account_head_deleted_ip`, `account_head_active_status`, `account_head_deleted_status`) VALUES
(1, '', 'Sundry Debitors', 'bs', 'a', 0, '', 1, 0, '', 1, 2147483647, '103.197.196.43', 0, 0, '', 0, 0, '', 'active', 0),
(2, '', 'Other Income', 'pl', 'in', 0, '', 1, 0, '', 1, 2147483647, '103.197.196.14', 1, 2147483647, '103.197.196.6', 0, 0, '', 'inactive', 1),
(3, '', 'Labour and Production Overheads', 'pl', 'ex', 0, '', 1, 0, '', 1, 2147483647, '103.197.196.14', 0, 0, '', 0, 0, '', 'active', 1),
(4, '', 'Cost Of Good Sold ', 'pl', 'op', 0, '', 1, 0, '', 1, 2147483647, '103.197.196.6', 1, 2147483647, '103.197.196.6', 0, 0, '', 'active', 0),
(5, '', 'Cost Of Good Sold Less', 'pl', 'cl', 0, '', 1, 0, '', 1, 2147483647, '103.197.196.6', 1, 2147483647, '103.197.196.6', 0, 0, '', 'active', 0),
(6, '', 'Cost Of Good Sold Add', 'pl', 'pu', 0, '', 1, 0, '', 1, 2147483647, '103.197.196.6', 1, 2147483647, '103.197.196.6', 0, 0, '', 'active', 0),
(7, '', 'Total Net Sale', 'pl', 'sa', 0, '', 1, 0, '', 1, 2147483647, '103.197.196.6', 0, 0, '', 0, 0, '', 'active', 0),
(8, '', 'Other Income', 'pl', 'in', 0, '', 1, 0, '', 1, 2147483647, '103.197.196.6', 1, 2147483647, '103.197.196.6', 0, 0, '', 'active', 1),
(9, '', 'Adminstration & Selling & Distribution Expenses', 'pl', 'ex', 0, '', 1, 0, '', 1, 2147483647, '103.197.196.6', 0, 0, '', 0, 0, '', 'active', 1),
(10, '', 'Sundry creditor', 'bs', 'a', 0, '', 1, 0, '', 1, 2147483647, '103.197.196.6', 0, 0, '', 0, 0, '', 'active', 0),
(11, '', 'Long Term Liabilities', 'bs', 'l', 0, '', 1, 0, '', 1, 2147483647, '103.197.196.6', 0, 0, '', 0, 0, '', 'active', 0),
(12, '', 'Provision for Depreciation', 'bs', 'l', 0, '', 1, 0, '', 1, 2147483647, '103.197.196.6', 0, 0, '', 0, 0, '', 'active', 0),
(13, '', 'Fixed Assets', 'bs', 'a', 0, '', 1, 0, '', 1, 2147483647, '103.197.196.6', 0, 0, '', 0, 0, '', 'active', 1);

-- --------------------------------------------------------

--
-- Table structure for table `account_journal`
--

CREATE TABLE `account_journal` (
  `acJournalId` int(11) NOT NULL,
  `acJ_branchid` int(11) NOT NULL,
  `acJ_credit_ac` varchar(20) NOT NULL,
  `acJ_debit_ac` varchar(20) NOT NULL,
  `acJ_amount` decimal(11,2) NOT NULL,
  `acJ_date` date NOT NULL,
  `acJ_narration` varchar(20) NOT NULL,
  `acJ_request_by` varchar(20) NOT NULL,
  `acJ_approval_by` varchar(20) NOT NULL,
  `acJ_company_id` int(11) NOT NULL,
  `acJ_added_by` int(11) NOT NULL,
  `acJ_added_on` datetime NOT NULL,
  `acJ_added_ip` varchar(20) NOT NULL,
  `acJ_modified_by` int(11) NOT NULL,
  `acJ_modified_on` datetime NOT NULL,
  `acJ_modified_ip` varchar(20) NOT NULL,
  `acJ_deleted_by` int(11) NOT NULL,
  `acJ_deleted_on` datetime NOT NULL,
  `acJ_deleted_ip` varchar(20) NOT NULL,
  `acJ_deleted_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `account_manufacturing_costmaster`
--

CREATE TABLE `account_manufacturing_costmaster` (
  `acManuCostId` int(11) NOT NULL,
  `acMC_group_name` varchar(100) NOT NULL,
  `acMC_date` date NOT NULL,
  `acMC_company_id` int(11) NOT NULL,
  `acMC_fnancial_year` int(11) NOT NULL,
  `acMC_added_by` int(11) NOT NULL,
  `acMC_added_on` datetime NOT NULL,
  `acMC_added_ip` varchar(20) NOT NULL,
  `acMC_modified_by` int(11) NOT NULL,
  `acMC_modified_on` datetime NOT NULL,
  `acMC_modified_ip` varchar(20) NOT NULL,
  `acMC_deleted_by` int(11) NOT NULL,
  `acMC_deleted_on` datetime NOT NULL,
  `acMC_deleted_ip` varchar(20) NOT NULL,
  `acMC_deleted_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `account_manufacturing_costmaster_acs`
--

CREATE TABLE `account_manufacturing_costmaster_acs` (
  `idMcAcdetailsId` int(11) NOT NULL,
  `mcA_acManuCostId` int(11) NOT NULL,
  `mcA_account_head_id` int(11) NOT NULL,
  `mcA_account_sub_id` int(11) NOT NULL,
  `mcA_debit_amount` decimal(10,0) NOT NULL,
  `mcA_credit_amount` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `account_manu_cost_entry`
--

CREATE TABLE `account_manu_cost_entry` (
  `manuCostEntryeId` int(11) NOT NULL,
  `ce_idMcAcdetailsId` int(11) NOT NULL,
  `ce_account_sub_id` int(11) NOT NULL,
  `ce_debit_amnt` decimal(11,2) NOT NULL,
  `ce_credit_amnt` decimal(11,2) NOT NULL,
  `ce_company_id` int(11) NOT NULL,
  `ce_financial_year` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `account_opening_balance`
--

CREATE TABLE `account_opening_balance` (
  `openingBalanceId` int(11) NOT NULL,
  `oP_account_sub_id` int(11) NOT NULL,
  `oP_debit_amnt` decimal(11,2) NOT NULL,
  `oP_credit_amnt` decimal(11,2) NOT NULL,
  `oP_company_id` int(11) NOT NULL,
  `oP_financial_year` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `account_payable`
--

CREATE TABLE `account_payable` (
  `acpayableId` int(11) NOT NULL,
  `aeA_branchid` int(11) NOT NULL,
  `aeA_payable_typ` int(1) NOT NULL,
  `aeA_payment_mode` int(1) NOT NULL,
  `aeA_employee_id` int(11) NOT NULL,
  `aeA_credit_ac` varchar(20) NOT NULL,
  `aeA_debit_ac` varchar(20) NOT NULL,
  `aeA_amount` decimal(11,2) NOT NULL,
  `aeA_advance_date` date NOT NULL,
  `aeA_ref_details` varchar(25) NOT NULL,
  `aeA_narration` varchar(20) NOT NULL,
  `aeA_request_by` int(11) NOT NULL,
  `aeA_approval_by` int(11) NOT NULL,
  `aeA_company_id` int(11) NOT NULL,
  `aeA_added_by` int(11) NOT NULL,
  `aeA_added_on` datetime NOT NULL,
  `aeA_added_ip` varchar(20) NOT NULL,
  `aeA_modified_by` int(11) NOT NULL,
  `aeA_modified_on` datetime NOT NULL,
  `aeA_modified_ip` varchar(20) NOT NULL,
  `aeA_deleted_by` int(11) NOT NULL,
  `aeA_deleted_on` datetime NOT NULL,
  `aeA_deleted_ip` varchar(20) NOT NULL,
  `aeA_deleted_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `account_receivable`
--

CREATE TABLE `account_receivable` (
  `acReceivableId` int(11) NOT NULL,
  `acR_branchid` int(11) NOT NULL,
  `acR_payable_typ` varchar(20) NOT NULL,
  `acR_payment_mode` varchar(20) NOT NULL,
  `acR_credit_ac` varchar(20) NOT NULL,
  `acR_debit_ac` varchar(20) NOT NULL,
  `acR_amount` decimal(11,2) NOT NULL,
  `acR_date` date NOT NULL,
  `acR_ref_details` varchar(25) NOT NULL,
  `acR_narration` varchar(20) NOT NULL,
  `acR_request_by` varchar(20) NOT NULL,
  `acR_approval_by` varchar(20) NOT NULL,
  `acR_company_id` int(11) NOT NULL,
  `acR_added_by` int(11) NOT NULL,
  `acR_added_on` datetime NOT NULL,
  `acR_added_ip` varchar(20) NOT NULL,
  `acR_modified_by` int(11) NOT NULL,
  `acR_modified_on` datetime NOT NULL,
  `acR_modified_ip` varchar(20) NOT NULL,
  `acR_deleted_by` int(11) NOT NULL,
  `acR_deleted_on` datetime NOT NULL,
  `acR_deleted_ip` varchar(20) NOT NULL,
  `acR_deleted_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account_receivable`
--

INSERT INTO `account_receivable` (`acReceivableId`, `acR_branchid`, `acR_payable_typ`, `acR_payment_mode`, `acR_credit_ac`, `acR_debit_ac`, `acR_amount`, `acR_date`, `acR_ref_details`, `acR_narration`, `acR_request_by`, `acR_approval_by`, `acR_company_id`, `acR_added_by`, `acR_added_on`, `acR_added_ip`, `acR_modified_by`, `acR_modified_on`, `acR_modified_ip`, `acR_deleted_by`, `acR_deleted_on`, `acR_deleted_ip`, `acR_deleted_status`) VALUES
(1, 1, '1', '2', '', '', '1000.00', '2017-12-20', '', '', '', '', 1, 1, '2017-12-20 10:17:12', '103.197.196.6', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `account_setup`
--

CREATE TABLE `account_setup` (
  `acountSetupId` int(11) NOT NULL,
  `acS_branchid` int(11) NOT NULL,
  `acS_sales` varchar(255) NOT NULL,
  `acS_sales_return` varchar(255) NOT NULL,
  `acS_sales_ac1` varchar(255) NOT NULL,
  `acS_sales_ac2` varchar(255) NOT NULL,
  `acS_sales_ac3` varchar(255) NOT NULL,
  `acS_ac_date` date NOT NULL,
  `acS_purchase` varchar(255) NOT NULL,
  `acS_purchase_return` varchar(255) NOT NULL,
  `acS_purchase_ac1` varchar(255) NOT NULL,
  `acS_purchase_ac2` varchar(255) NOT NULL,
  `acS_purchase_ac3` varchar(255) NOT NULL,
  `acS_company_id` int(11) NOT NULL,
  `acS_added_by` int(11) NOT NULL,
  `acS_added_on` datetime NOT NULL,
  `acS_added_ip` varchar(20) NOT NULL,
  `acS_modified_by` int(11) NOT NULL,
  `acS_gp_modified_on` datetime NOT NULL,
  `acS_modified_ip` varchar(20) NOT NULL,
  `acS_deleted_by` int(11) NOT NULL,
  `acS_deleted_on` datetime NOT NULL,
  `acS_deleted_ip` varchar(20) NOT NULL,
  `acS_deleted_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `account_sub`
--

CREATE TABLE `account_sub` (
  `account_sub_id` int(11) NOT NULL,
  `account_sub_code` varchar(100) NOT NULL,
  `account_sub_name` varchar(100) NOT NULL,
  `account_sub_head_id` int(11) NOT NULL,
  `account_sub_code_type` varchar(30) NOT NULL,
  `account_sub_type_id` varchar(30) NOT NULL,
  `account_sub_currency_id` int(11) NOT NULL,
  `account_sub_debit_amount` decimal(20,4) NOT NULL,
  `account_sub_credit_amount` decimal(20,4) NOT NULL,
  `account_sub_track` varchar(20) NOT NULL,
  `account_sub_master_id` int(11) NOT NULL,
  `account_sub_monetry_type_id` int(11) NOT NULL,
  `account_sub_company_id` int(11) NOT NULL,
  `account_sub_branch_id` int(11) NOT NULL,
  `account_sub_financial_year` varchar(20) NOT NULL,
  `account_sub_added_by` int(11) NOT NULL,
  `account_sub_added_on` int(11) NOT NULL,
  `account_sub_added_ip` varchar(20) NOT NULL,
  `account_sub_modified_by` int(11) NOT NULL,
  `account_sub_modified_on` int(11) NOT NULL,
  `account_sub_modified_ip` varchar(20) NOT NULL,
  `account_sub_deleted_by` int(11) NOT NULL,
  `account_sub_deleted_on` int(11) NOT NULL,
  `account_sub_deleted_ip` varchar(20) NOT NULL,
  `account_sub_active_status` varchar(20) NOT NULL DEFAULT 'active',
  `account_sub_deleted_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account_sub`
--

INSERT INTO `account_sub` (`account_sub_id`, `account_sub_code`, `account_sub_name`, `account_sub_head_id`, `account_sub_code_type`, `account_sub_type_id`, `account_sub_currency_id`, `account_sub_debit_amount`, `account_sub_credit_amount`, `account_sub_track`, `account_sub_master_id`, `account_sub_monetry_type_id`, `account_sub_company_id`, `account_sub_branch_id`, `account_sub_financial_year`, `account_sub_added_by`, `account_sub_added_on`, `account_sub_added_ip`, `account_sub_modified_by`, `account_sub_modified_on`, `account_sub_modified_ip`, `account_sub_deleted_by`, `account_sub_deleted_on`, `account_sub_deleted_ip`, `account_sub_active_status`, `account_sub_deleted_status`) VALUES
(1, '', 'Supplier Test', 0, 'supplier', '', 0, '0.0000', '0.0000', '', 3, 0, 1, 0, '', 1, 1512714879, '103.197.196.19', 0, 0, '', 0, 0, '', 'active', 0),
(2, '', 'Test Customer', 0, 'customer', '', 0, '0.0000', '0.0000', '', 5, 0, 1, 0, '', 1, 1512727876, '103.197.196.19', 0, 0, '', 0, 0, '', 'active', 1),
(3, '', 'Insurance Income', 2, '', '5', 0, '0.0000', '0.0000', '', 0, 0, 1, 0, '', 1, 2147483647, '103.197.196.14', 0, 0, '', 0, 0, '', 'active', 1),
(4, '', 'Electricity Charges', 3, '', '5', 0, '0.0000', '0.0000', '', 0, 0, 1, 0, '', 1, 2147483647, '103.197.196.14', 0, 0, '', 0, 0, '', 'active', 1),
(5, '', 'Factory Supply Exp', 3, '', '5', 0, '0.0000', '0.0000', '', 0, 0, 1, 0, '', 1, 2147483647, '103.197.196.14', 0, 0, '', 0, 0, '', 'active', 1),
(6, '', 'Forming charges', 3, '', '5', 0, '0.0000', '0.0000', '', 0, 0, 1, 0, '', 1, 2147483647, '103.197.196.14', 0, 0, '', 0, 0, '', 'active', 1),
(7, '', 'Container Expense', 3, '', '5', 0, '0.0000', '0.0000', '', 0, 0, 1, 0, '', 1, 2147483647, '103.197.196.14', 0, 0, '', 0, 0, '', 'active', 1),
(8, '', 'Thai Supplier', 0, 'supplier', '', 0, '0.0000', '0.0000', '', 4, 0, 1, 0, '', 1, 1513142894, '103.197.196.27', 0, 0, '', 0, 0, '', 'active', 1),
(9, '', 'Local Customer', 0, 'customer', '', 0, '0.0000', '0.0000', '', 6, 0, 1, 0, '', 1, 1513142983, '103.197.196.27', 0, 0, '', 0, 0, '', 'active', 1),
(10, '', '0000001', 0, 'supplier', '', 0, '0.0000', '0.0000', '', 5, 0, 1, 0, '', 1, 1513312958, '203.81.163.231', 0, 0, '', 0, 0, '', 'active', 1),
(11, '', '1000000', 0, 'customer', '', 0, '0.0000', '0.0000', '', 7, 0, 1, 0, '', 1, 1513313069, '203.81.163.231', 0, 0, '', 0, 0, '', 'active', 1),
(12, '', 'Payable Oversea  Supplier ( For Machines )', 11, '', '1', 2, '0.0000', '0.0000', '', 0, 0, 1, 0, '', 1, 2147483647, '103.197.196.6', 0, 0, '', 0, 0, '', 'active', 0),
(13, '', 'Global', 0, 'supplier', '', 0, '0.0000', '0.0000', '', 6, 0, 1, 0, '', 1, 1513746193, '103.197.196.6', 0, 0, '', 0, 0, '', 'active', 0),
(14, '', 'Global', 0, 'customer', '', 0, '0.0000', '0.0000', '', 8, 0, 1, 0, '', 1, 1513746488, '103.197.196.6', 0, 0, '', 0, 0, '', 'active', 0),
(15, '', 'Maung Phyu', 0, 'supplier', '', 0, '0.0000', '0.0000', '', 7, 0, 1, 0, '', 1, 1514866902, '103.197.196.14', 0, 0, '', 0, 0, '', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `account_types`
--

CREATE TABLE `account_types` (
  `account_type_id` int(11) NOT NULL,
  `account_type_name` varchar(60) NOT NULL,
  `account_type_type1` varchar(30) NOT NULL,
  `account_type_type2` varchar(30) NOT NULL,
  `account_type_company_id` int(11) NOT NULL,
  `account_type_branch_id` int(11) NOT NULL,
  `account_type_financial_year` varchar(20) NOT NULL,
  `account_type_added_by` int(11) NOT NULL,
  `account_type_added_on` int(11) NOT NULL,
  `account_type_added_ip` varchar(20) NOT NULL,
  `account_type_modified_by` int(11) NOT NULL,
  `account_type_modified_on` int(11) NOT NULL,
  `account_type_modified_ip` varchar(20) NOT NULL,
  `account_type_deleted_by` int(11) NOT NULL,
  `account_type_deleted_on` int(11) NOT NULL,
  `account_type_deleted_ip` varchar(20) NOT NULL,
  `account_type_active_status` varchar(20) NOT NULL,
  `account_type_deleted_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account_types`
--

INSERT INTO `account_types` (`account_type_id`, `account_type_name`, `account_type_type1`, `account_type_type2`, `account_type_company_id`, `account_type_branch_id`, `account_type_financial_year`, `account_type_added_by`, `account_type_added_on`, `account_type_added_ip`, `account_type_modified_by`, `account_type_modified_on`, `account_type_modified_ip`, `account_type_deleted_by`, `account_type_deleted_on`, `account_type_deleted_ip`, `account_type_active_status`, `account_type_deleted_status`) VALUES
(2, 'Current income tax liabilities', 'bs', 'l', 0, 0, '', 1, 1476942152, '103.25.77.175', 0, 0, '', 0, 0, '', '', 0),
(3, 'Other current liabilities', 'bs', 'l', 0, 0, '', 1, 1476942194, '103.25.77.175', 0, 0, '', 0, 0, '', '', 0),
(4, 'Property, Plant And Equipment', 'bs', 'l', 0, 0, '', 1, 1476942224, '103.25.77.175', 1, 1476942802, '103.25.77.175', 0, 0, '', '', 0),
(5, 'Other current assets', 'bs', 'a', 0, 0, '', 1, 1476942235, '103.25.77.175', 0, 0, '', 0, 0, '', '', 0),
(6, 'Current tax assets', 'bs', 'a', 0, 0, '', 1, 1476942398, '103.25.77.175', 0, 0, '', 0, 0, '', '', 0),
(7, 'Other non-current assets', 'bs', 'a', 0, 0, '', 1, 1476942417, '103.25.77.175', 0, 0, '', 0, 0, '', '', 0),
(8, 'Cash And Cash Equivalents', 'bs', 'a', 0, 0, '', 1, 1476942482, '103.25.77.175', 1, 1487929028, '103.25.77.162', 0, 0, '', '', 0),
(9, 'Imprest Account', 'bs', 'l', 0, 0, '', 1, 1476942513, '103.25.77.175', 0, 0, '', 0, 0, '', '', 0),
(10, 'Finance income', 'pl', 'in', 0, 0, '', 1, 1476942539, '103.25.77.175', 0, 0, '', 0, 0, '', '', 0),
(11, 'Selling, general and administrative expenses', 'pl', 'ex', 0, 0, '', 1, 1476942551, '103.25.77.175', 0, 0, '', 0, 0, '', '', 0),
(12, 'Finance expense', 'pl', 'ex', 0, 0, '', 1, 1476942577, '103.25.77.175', 0, 0, '', 0, 0, '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `advance_entry`
--

CREATE TABLE `advance_entry` (
  `advance_entry_id` int(11) NOT NULL,
  `advance_entry_uniq_id` varchar(255) NOT NULL,
  `advance_entry_no` varchar(30) NOT NULL,
  `advance_entry_date` date NOT NULL,
  `advance_entry_customer_id` int(11) NOT NULL,
  `advance_entry_validity_date` date NOT NULL,
  `advance_entry_type_id` int(11) NOT NULL,
  `advance_entry_gross_amount` decimal(20,4) NOT NULL,
  `advance_entry_transport_amount` decimal(20,4) NOT NULL,
  `advance_entry_tax_per` decimal(20,4) NOT NULL,
  `advance_entry_tax_amount` decimal(20,4) NOT NULL,
  `advance_entry_advance_amount` decimal(20,4) NOT NULL,
  `advance_entry_net_amount` decimal(20,4) NOT NULL,
  `advance_entry_company_id` int(11) NOT NULL,
  `advance_entry_branch_id` int(11) NOT NULL,
  `advance_entry_financial_year` int(11) NOT NULL,
  `advance_entry_added_by` int(11) NOT NULL,
  `advance_entry_added_on` int(11) NOT NULL,
  `advance_entry_added_ip` varchar(20) NOT NULL,
  `advance_entry_modified_by` int(11) NOT NULL,
  `advance_entry_modified_on` int(11) NOT NULL,
  `advance_entry_modified_ip` varchar(20) NOT NULL,
  `advance_entry_deleted_by` int(11) NOT NULL,
  `advance_entry_deleted_on` int(11) NOT NULL,
  `advance_entry_deleted_ip` varchar(20) NOT NULL,
  `advance_entry_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `advance_entry`
--

INSERT INTO `advance_entry` (`advance_entry_id`, `advance_entry_uniq_id`, `advance_entry_no`, `advance_entry_date`, `advance_entry_customer_id`, `advance_entry_validity_date`, `advance_entry_type_id`, `advance_entry_gross_amount`, `advance_entry_transport_amount`, `advance_entry_tax_per`, `advance_entry_tax_amount`, `advance_entry_advance_amount`, `advance_entry_net_amount`, `advance_entry_company_id`, `advance_entry_branch_id`, `advance_entry_financial_year`, `advance_entry_added_by`, `advance_entry_added_on`, `advance_entry_added_ip`, `advance_entry_modified_by`, `advance_entry_modified_on`, `advance_entry_modified_ip`, `advance_entry_deleted_by`, `advance_entry_deleted_on`, `advance_entry_deleted_ip`, `advance_entry_deleted_status`) VALUES
(1, '5e0ede83n76790agy7nc4482c2d41c0149d106f9', 'asf', '2018-01-06', 7, '2018-01-06', 1, '20000.0000', '0.0000', '0.0000', '0.0000', '0.0000', '20000.0000', 1, 4, 1, 1, 1515212315, '103.197.196.11', 0, 0, '', 0, 0, '', 0),
(2, 'ded2f76b1d4704s7kchebc59fa3cc2e1ac4c28d1', 'A00001', '2018-01-06', 1, '2018-01-13', 1, '84000.0000', '100.0000', '10.0000', '8400.0000', '100.0000', '92400.0000', 1, 2, 1, 1, 1515224502, '122.174.33.217', 0, 0, '', 0, 0, '', 0),
(3, '566d755nu4b0e643t6cda640e5bd5ed27151482b', '11', '2018-01-06', 7, '2018-01-06', 1, '1000.0000', '0.0000', '0.0000', '0.0000', '0.0000', '1000.0000', 1, 4, 1, 1, 1515226286, '103.197.196.11', 0, 0, '', 0, 0, '', 0),
(4, '4982dc2culca4e2xpm06f1e0ae1c8e6f3d4a6e41', 'AD902', '2018-01-06', 3, '2018-01-13', 1, '10000.0000', '0.0000', '0.0000', '0.0000', '0.0000', '10000.0000', 1, 3, 1, 1, 1515230777, '103.197.196.11', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `advance_entry_product_details`
--

CREATE TABLE `advance_entry_product_details` (
  `advance_entry_product_detail_id` int(11) NOT NULL,
  `advance_entry_product_detail_uniq_id` varchar(255) NOT NULL,
  `advance_entry_product_detail_advance_entry_id` int(11) NOT NULL,
  `advance_entry_product_detail_product_id` int(11) NOT NULL,
  `advance_entry_product_detail_product_uom_id` int(11) NOT NULL,
  `advance_entry_product_detail_product_brand_id` int(11) NOT NULL,
  `advance_entry_product_detail_product_color_id` int(11) NOT NULL,
  `advance_entry_product_detail_product_type` int(11) NOT NULL,
  `advance_entry_product_detail_product_thick` decimal(20,4) NOT NULL,
  `advance_entry_product_detail_width_inches` decimal(20,4) NOT NULL,
  `advance_entry_product_detail_width_mm` decimal(20,4) NOT NULL,
  `advance_entry_product_detail_s_width_inches` decimal(20,4) NOT NULL,
  `advance_entry_product_detail_s_width_mm` decimal(20,4) NOT NULL,
  `advance_entry_product_detail_sl_feet` decimal(20,4) NOT NULL,
  `advance_entry_product_detail_sl_feet_in` decimal(20,4) NOT NULL,
  `advance_entry_product_detail_sl_feet_mm` decimal(20,4) NOT NULL,
  `advance_entry_product_detail_s_weight_inches` decimal(20,4) NOT NULL,
  `advance_entry_product_detail_s_weight_mm` decimal(20,4) NOT NULL,
  `advance_entry_product_detail_tot_length` decimal(20,4) NOT NULL,
  `advance_entry_product_detail_rate` decimal(20,4) NOT NULL,
  `advance_entry_product_detail_total` decimal(20,4) NOT NULL,
  `advance_entry_product_detail_qty` decimal(20,4) NOT NULL,
  `advance_entry_product_detail_added_by` int(11) NOT NULL,
  `advance_entry_product_detail_added_on` int(11) NOT NULL,
  `advance_entry_product_detail_added_ip` varchar(20) NOT NULL,
  `advance_entry_product_detail_modified_by` int(11) NOT NULL,
  `advance_entry_product_detail_modified_on` int(11) NOT NULL,
  `advance_entry_product_detail_modified_ip` varchar(20) NOT NULL,
  `advance_entry_product_detail_deleted_by` int(11) NOT NULL,
  `advance_entry_product_detail_deleted_on` int(11) NOT NULL,
  `advance_entry_product_detail_deleted_ip` varchar(20) NOT NULL,
  `advance_entry_product_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `advance_entry_product_details`
--

INSERT INTO `advance_entry_product_details` (`advance_entry_product_detail_id`, `advance_entry_product_detail_uniq_id`, `advance_entry_product_detail_advance_entry_id`, `advance_entry_product_detail_product_id`, `advance_entry_product_detail_product_uom_id`, `advance_entry_product_detail_product_brand_id`, `advance_entry_product_detail_product_color_id`, `advance_entry_product_detail_product_type`, `advance_entry_product_detail_product_thick`, `advance_entry_product_detail_width_inches`, `advance_entry_product_detail_width_mm`, `advance_entry_product_detail_s_width_inches`, `advance_entry_product_detail_s_width_mm`, `advance_entry_product_detail_sl_feet`, `advance_entry_product_detail_sl_feet_in`, `advance_entry_product_detail_sl_feet_mm`, `advance_entry_product_detail_s_weight_inches`, `advance_entry_product_detail_s_weight_mm`, `advance_entry_product_detail_tot_length`, `advance_entry_product_detail_rate`, `advance_entry_product_detail_total`, `advance_entry_product_detail_qty`, `advance_entry_product_detail_added_by`, `advance_entry_product_detail_added_on`, `advance_entry_product_detail_added_ip`, `advance_entry_product_detail_modified_by`, `advance_entry_product_detail_modified_on`, `advance_entry_product_detail_modified_ip`, `advance_entry_product_detail_deleted_by`, `advance_entry_product_detail_deleted_on`, `advance_entry_product_detail_deleted_ip`, `advance_entry_product_detail_deleted_status`) VALUES
(1, '01c8a9bma70884smm4q292468c75e473023f902f', 1, 7, 3, 4, 6, 2, '1.0000', '36.0000', '914.4000', '0.0000', '457.2000', '100.0000', '1200.0000', '30480.0000', '0.0000', '0.0000', '0.0000', '1000.0000', '10000.0000', '10.0000', 1, 1515212316, '103.197.196.11', 0, 0, '', 0, 0, '', 0),
(2, 'f70b90dyky5554sf74p32c3e27aa57b15e0103ea', 1, 6, 5, 4, 7, 2, '2.0000', '20.0000', '508.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '100.0000', '10000.0000', '100.0000', 1, 1515212316, '103.197.196.11', 0, 0, '', 0, 0, '', 0),
(3, 'b01f3d4aei70d35yaum1e60177f665e7b312f788', 2, 7, 3, 4, 6, 2, '1.0000', '36.0000', '914.4000', '3.0000', '914.4000', '100.0000', '1200.0000', '30480.0000', '0.0000', '0.0000', '2083.3300', '300.0000', '75000.0000', '250.0000', 1, 1515224502, '122.174.33.217', 0, 0, '', 0, 0, '', 0),
(4, '8b2c120loce338xuz1k64ffa7a84ef6bbdf64da3', 2, 8, 3, 4, 6, 2, '2.0000', '48.0000', '1219.2000', '3.0000', '914.4000', '200.0000', '2400.0000', '60960.0000', '0.0000', '0.0000', '3750.0000', '30.0000', '9000.0000', '300.0000', 1, 1515224502, '122.174.33.217', 0, 0, '', 0, 0, '', 0),
(5, '8f4ddc2x2sa338pm5kr64568ea19a00cafe7d7d3', 3, 7, 3, 4, 6, 2, '1.0000', '36.0000', '914.4000', '2.0000', '508.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '100.0000', '1000.0000', '10.0000', 1, 1515226286, '103.197.196.11', 0, 0, '', 0, 0, '', 0),
(6, 'dd2b485k9p5a1eg25jg53af649e8ddcdb037c988', 4, 6, 5, 4, 7, 2, '2.0000', '20.0000', '508.0000', '0.0000', '914.4000', '10.0000', '120.0000', '3048.0000', '0.0000', '0.0000', '0.0000', '10000.0000', '10000.0000', '1.0000', 1, 1515230777, '103.197.196.11', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `banks`
--

CREATE TABLE `banks` (
  `bank_id` int(11) NOT NULL,
  `bank_uniq_id` varchar(100) NOT NULL,
  `bank_code` varchar(10) NOT NULL,
  `bank_name` varchar(80) NOT NULL,
  `bank_company_name` varchar(100) NOT NULL,
  `bank_address` text NOT NULL,
  `bank_country_id` int(11) NOT NULL,
  `bank_state_id` int(11) NOT NULL,
  `bank_city_id` int(11) NOT NULL,
  `bank_email` varchar(40) NOT NULL,
  `bank_zip_code` varchar(40) NOT NULL,
  `bank_fax_no` varchar(40) NOT NULL,
  `bank_company_id` int(11) NOT NULL,
  `bank_added_by` int(11) NOT NULL,
  `bank_added_on` int(11) NOT NULL,
  `bank_added_ip` varchar(20) NOT NULL,
  `bank_modified_by` int(11) NOT NULL,
  `bank_modified_on` int(11) NOT NULL,
  `bank_modified_ip` varchar(20) NOT NULL,
  `bank_deleted_by` int(11) NOT NULL,
  `bank_deleted_on` int(11) NOT NULL,
  `bank_deleted_ip` varchar(20) NOT NULL,
  `bank_active_status` varchar(20) NOT NULL DEFAULT 'active',
  `bank_deleted_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `banks`
--

INSERT INTO `banks` (`bank_id`, `bank_uniq_id`, `bank_code`, `bank_name`, `bank_company_name`, `bank_address`, `bank_country_id`, `bank_state_id`, `bank_city_id`, `bank_email`, `bank_zip_code`, `bank_fax_no`, `bank_company_id`, `bank_added_by`, `bank_added_on`, `bank_added_ip`, `bank_modified_by`, `bank_modified_on`, `bank_modified_ip`, `bank_deleted_by`, `bank_deleted_on`, `bank_deleted_ip`, `bank_active_status`, `bank_deleted_status`) VALUES
(1, '740683dov14121en8577e3d78d547c7574988313', '', 'HDFC', '', 'fsfdg', 2, 0, 0, 'mohana_k5@yahoo.com', '614001', '123', 1, 1, 1510309913, '192', 0, 0, '', 0, 0, '', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `bank_multi_contacts`
--

CREATE TABLE `bank_multi_contacts` (
  `bank_multi_contact_id` int(11) NOT NULL,
  `bank_multi_contact_bank_id` int(11) NOT NULL,
  `bank_multi_contact_title` varchar(80) NOT NULL,
  `bank_multi_contact_name` varchar(80) NOT NULL,
  `bank_multi_contact_department` varchar(80) NOT NULL,
  `bank_multi_contact_mobile_no` varchar(40) NOT NULL,
  `bank_multi_contact_email` varchar(80) NOT NULL,
  `bank_multi_contact_extn_no` int(5) NOT NULL,
  `bank_multi_contact_added_by` int(11) NOT NULL,
  `bank_multi_contact_added_on` int(11) NOT NULL,
  `bank_multi_contact_added_ip` varchar(20) NOT NULL,
  `bank_multi_contact_modified_by` int(11) NOT NULL,
  `bank_multi_contact_modified_on` int(11) NOT NULL,
  `bank_multi_contact_modified_ip` varchar(20) NOT NULL,
  `bank_multi_contact_deleted_by` int(11) NOT NULL,
  `bank_multi_contact_deleted_on` int(11) NOT NULL,
  `bank_multi_contact_deleted_ip` int(20) NOT NULL,
  `bank_multi_contact_deleted_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bank_multi_contacts`
--

INSERT INTO `bank_multi_contacts` (`bank_multi_contact_id`, `bank_multi_contact_bank_id`, `bank_multi_contact_title`, `bank_multi_contact_name`, `bank_multi_contact_department`, `bank_multi_contact_mobile_no`, `bank_multi_contact_email`, `bank_multi_contact_extn_no`, `bank_multi_contact_added_by`, `bank_multi_contact_added_on`, `bank_multi_contact_added_ip`, `bank_multi_contact_modified_by`, `bank_multi_contact_modified_on`, `bank_multi_contact_modified_ip`, `bank_multi_contact_deleted_by`, `bank_multi_contact_deleted_on`, `bank_multi_contact_deleted_ip`, `bank_multi_contact_deleted_status`) VALUES
(1, 1, 'Mr.', 'Menaka', 'dsf', '09942506518', '', 0, 1, 1510309913, '192.168.1.3', 0, 0, '', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `branch_id` int(11) NOT NULL,
  `branch_uniq_id` varchar(100) NOT NULL,
  `branch_code` varchar(10) NOT NULL,
  `branch_name` varchar(80) NOT NULL,
  `branch_address` text NOT NULL,
  `branch_country_id` int(11) NOT NULL,
  `branch_state_id` int(11) NOT NULL,
  `branch_city_id` int(11) NOT NULL,
  `branch_office_no` varchar(40) NOT NULL,
  `branch_line_phone` varchar(40) NOT NULL,
  `branch_email` varchar(40) NOT NULL,
  `branch_zip_code` varchar(40) NOT NULL,
  `branch_fax_no` varchar(40) NOT NULL,
  `branch_company_id` int(11) NOT NULL,
  `branch_added_by` int(11) NOT NULL,
  `branch_added_on` int(11) NOT NULL,
  `branch_added_ip` varchar(20) NOT NULL,
  `branch_modified_by` int(11) NOT NULL,
  `branch_modified_on` int(11) NOT NULL,
  `branch_modified_ip` varchar(20) NOT NULL,
  `branch_deleted_by` int(11) NOT NULL,
  `branch_deleted_on` int(11) NOT NULL,
  `branch_deleted_ip` varchar(20) NOT NULL,
  `branch_active_status` varchar(20) NOT NULL DEFAULT 'active',
  `branch_deleted_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branches`
--

INSERT INTO `branches` (`branch_id`, `branch_uniq_id`, `branch_code`, `branch_name`, `branch_address`, `branch_country_id`, `branch_state_id`, `branch_city_id`, `branch_office_no`, `branch_line_phone`, `branch_email`, `branch_zip_code`, `branch_fax_no`, `branch_company_id`, `branch_added_by`, `branch_added_on`, `branch_added_ip`, `branch_modified_by`, `branch_modified_on`, `branch_modified_ip`, `branch_deleted_by`, `branch_deleted_on`, `branch_deleted_ip`, `branch_active_status`, `branch_deleted_status`) VALUES
(1, 'ced4a34gt5110f33ovr9aeaaede46329b7a438e0', '00001', 'Yangon', 'ch', 0, 0, 0, '', '', '', '', '', 0, 1, 1502102167, '103.25.77.135', 0, 0, '', 0, 0, '', 'active', 0),
(2, 'a9dda25e7b8da0gdbtz2afd8d7c4dfe1b058be2a', 'AT000001', 'Test', 'Sddffrree', 1, 1, 6, 'Office no', '9876uiuiu', 'Dfgghhhj', 'Sdr', '56565hggggh', 0, 1, 1502171302, '157.50.11.249', 0, 0, '', 0, 0, '', 'active', 0),
(3, '91963479jw9832stjxpdbd286114d2a68fd99820', 'AT000001', 'Sawbwagyigon I', 'Sawbwagyigon', 1, 1, 3, '014678', '026633', 'eva@gmail.com', '1', '1', 1, 1, 1513745824, '103.197.196.6', 0, 0, '', 0, 0, '', 'active', 0),
(4, '6f11b4b5mqf834fzftr375419f0d17ef3a9a34d3', 'AT000001', 'EVA Head Office', 'Yangon', 1, 1, 6, '112112', '', 'evaheadoffice@gmail.com', '', '', 1, 1, 1514866492, '103.197.196.14', 0, 0, '', 0, 0, '', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_id` int(11) NOT NULL,
  `brand_uniq_id` varchar(100) NOT NULL,
  `brand_name` varchar(80) NOT NULL,
  `brand_company_id` int(11) NOT NULL,
  `brand_added_by` int(11) NOT NULL,
  `brand_added_on` int(11) NOT NULL,
  `brand_added_ip` varchar(20) NOT NULL,
  `brand_modified_by` int(11) NOT NULL,
  `brand_modified_on` int(11) NOT NULL,
  `brand_modified_ip` varchar(20) NOT NULL,
  `brand_deleted_by` int(11) NOT NULL,
  `brand_deleted_on` int(11) NOT NULL,
  `brand_deleted_ip` varchar(20) NOT NULL,
  `brand_active_status` varchar(20) NOT NULL DEFAULT 'active',
  `brand_deleted_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_uniq_id`, `brand_name`, `brand_company_id`, `brand_added_by`, `brand_added_on`, `brand_added_ip`, `brand_modified_by`, `brand_modified_on`, `brand_modified_ip`, `brand_deleted_by`, `brand_deleted_on`, `brand_deleted_ip`, `brand_active_status`, `brand_deleted_status`) VALUES
(1, '7f18af4uc5d1fb41x4ed7d05f54e4b6d6aff54f7', 'Sum song', 0, 1, 1504505031, '::1', 0, 0, '', 0, 0, '', 'active', 0),
(2, 'a16b957l021b7fm5bc86c9c9ba5b934128a96048', 'Honor', 0, 1, 1504505038, '::1', 0, 0, '', 0, 0, '', 'active', 0),
(3, '8890d63y59d8c4x1kh75b1cbf2e5913306d5f15c', 'RUM', 0, 1, 1506497407, '103.25.77.145', 0, 0, '', 0, 0, '', 'active', 0),
(4, 'fe08e0ee885297wsxz8272914b1dcdccc2cda978', 'China', 1, 1, 1510374250, '103.197.196.17', 0, 0, '', 0, 0, '', 'active', 0),
(5, '8a029a4o6r3773rb98q8e4e52ae6727076138ef5', 'korea', 1, 1, 1510374344, '103.197.196.17', 1, 1510374394, '', 0, 0, '', 'active', 0),
(6, '946a8df8qg55e4cuk4y124441646fa9e2b75614a', 'PPGI', 1, 1, 1510387314, '103.197.196.17', 0, 0, '', 0, 0, '', 'active', 0),
(7, 'aae44ffsbp4b8efoj9xca738764f4931e2df9a00', 'PPGL', 1, 1, 1512557944, '103.197.196.15', 0, 0, '', 0, 0, '', 'active', 0),
(8, 'db8fa69yqe5691qww7m9c4c3b2735a975af9e30f', 'GIPP', 1, 1, 1513143034, '103.197.196.27', 0, 0, '', 0, 0, '', 'active', 0),
(9, '984e60cnqhb653xfroeabd601f1e1e5d79a6dbb5', 'PPGI Thailand', 1, 1, 1513225565, '103.197.196.20', 0, 0, '', 0, 0, '', 'active', 0),
(10, 'c338f358478d50m2ad233a960f6063bc0c2c467a', 'GI', 1, 1, 1513313182, '203.81.163.231', 0, 0, '', 0, 0, '', 'active', 0),
(11, '1f92da9x7x317c6c4fd843238b22539d0fd9d0c4', 'Other', 1, 1, 1513326093, '203.81.163.246', 0, 0, '', 0, 0, '', 'active', 0),
(12, '1f34b57ziq86cahvdk8a340625d8b4e968ad4ded', 'GL', 1, 1, 1513746820, '103.197.196.6', 0, 0, '', 0, 0, '', 'active', 0),
(13, 'a74fd4ea0036087njykb6b54d7d2b4a117d89f16', 'other', 1, 1, 1514865551, '103.197.196.14', 0, 0, '', 0, 0, '', 'active', 0),
(14, '66417c6alf5b492ygcrc68dc321d0e03bceceb41', 'Test name', 1, 1, 1514867167, '103.197.196.14', 0, 0, '', 0, 0, '', 'active', 0),
(15, 'b17fd54cxk2243v3imb6801fdb55088611bf655d', 'PPGI (test)', 1, 1, 1514867293, '103.197.196.14', 0, 0, '', 0, 0, '', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `city_id` int(11) NOT NULL,
  `city_name` varchar(255) NOT NULL,
  `city_zone_id` int(11) NOT NULL,
  `city_state_id` int(11) NOT NULL,
  `city_country_id` int(11) NOT NULL,
  `city_company_id` int(11) NOT NULL,
  `city_added_by` int(11) NOT NULL,
  `city_added_on` int(11) NOT NULL,
  `city_added_ip` varchar(20) NOT NULL,
  `city_modified_by` int(11) NOT NULL,
  `city_modified_on` int(11) NOT NULL,
  `city_modified_ip` varchar(20) NOT NULL,
  `city_deleted_by` int(11) NOT NULL,
  `city_deleted_on` int(11) NOT NULL,
  `city_deleted_ip` varchar(20) NOT NULL,
  `city_active_status` varchar(20) NOT NULL,
  `city_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`city_id`, `city_name`, `city_zone_id`, `city_state_id`, `city_country_id`, `city_company_id`, `city_added_by`, `city_added_on`, `city_added_ip`, `city_modified_by`, `city_modified_on`, `city_modified_ip`, `city_deleted_by`, `city_deleted_on`, `city_deleted_ip`, `city_active_status`, `city_deleted_status`) VALUES
(1, 'á€±á€á€¬á€„á€¹á€¥á€€á á€œá€¬', 1, 1, 1, 0, 0, 0, '', 0, 0, '', 0, 0, '', 'active', 0),
(2, 'á€•á€²á€á€°á€¸', 1, 2, 1, 0, 0, 0, '', 0, 0, '', 0, 0, '', 'active', 0),
(3, 'á‰á€™á€­á€¯á€„á€¹', 1, 1, 1, 0, 0, 0, '', 0, 0, '', 0, 0, '', 'active', 0),
(4, 'á€±á€»á€™á€¬á€€á€¹á€¥á€€á á€œá€¬', 1, 1, 1, 0, 0, 0, '', 0, 0, '', 0, 0, '', 'active', 0),
(5, 'á€±á€›á‚Šá€»á€•á€Šá€¹á€žá€¬', 1, 1, 1, 0, 0, 0, '', 0, 0, '', 0, 0, '', 'active', 0),
(6, 'á€™á€‚á¤á€œá€¬á€’á€¶á€¯', 1, 1, 1, 0, 0, 0, '', 0, 0, '', 0, 0, '', 'active', 0),
(7, 'Chennai', 0, 3, 2, 0, 1, 1506311597, '::1', 0, 0, '', 0, 0, '', 'active', 0),
(8, 'Chennai', 0, 3, 2, 0, 1, 1510309900, '192.168.1.3', 0, 0, '', 0, 0, '', 'active', 0),
(9, 'Hong Kong', 0, 6, 3, 0, 1, 1512558340, '103.197.196.15', 0, 0, '', 0, 0, '', 'active', 0),
(10, 'Bangkok', 0, 7, 4, 0, 1, 1513142738, '103.197.196.27', 0, 0, '', 0, 0, '', 'active', 0),
(11, 'Shwebo', 0, 8, 1, 0, 1, 1513745920, '103.197.196.6', 0, 0, '', 0, 0, '', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `collection_entry`
--

CREATE TABLE `collection_entry` (
  `collection_entry_id` int(11) NOT NULL,
  `collection_entry_uniq_id` varchar(255) NOT NULL,
  `collection_entry_no` varchar(30) NOT NULL,
  `collection_entry_date` date NOT NULL,
  `collection_entry_payment_mode` int(11) NOT NULL,
  `collection_entry_salesman_id` int(11) NOT NULL,
  `collection_entry_total_amount` decimal(12,2) NOT NULL,
  `collection_entry_company_id` int(11) NOT NULL,
  `collection_entry_branch_id` int(11) NOT NULL,
  `collection_entry_financial_year` int(11) NOT NULL,
  `collection_entry_added_by` int(11) NOT NULL,
  `collection_entry_added_on` int(11) NOT NULL,
  `collection_entry_added_ip` varchar(20) NOT NULL,
  `collection_entry_modified_by` int(11) NOT NULL,
  `collection_entry_modified_on` int(11) NOT NULL,
  `collection_entry_modified_ip` varchar(20) NOT NULL,
  `collection_entry_deleted_by` int(11) NOT NULL,
  `collection_entry_deleted_on` int(11) NOT NULL,
  `collection_entry_deleted_ip` varchar(20) NOT NULL,
  `collection_entry_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `collection_entry`
--

INSERT INTO `collection_entry` (`collection_entry_id`, `collection_entry_uniq_id`, `collection_entry_no`, `collection_entry_date`, `collection_entry_payment_mode`, `collection_entry_salesman_id`, `collection_entry_total_amount`, `collection_entry_company_id`, `collection_entry_branch_id`, `collection_entry_financial_year`, `collection_entry_added_by`, `collection_entry_added_on`, `collection_entry_added_ip`, `collection_entry_modified_by`, `collection_entry_modified_on`, `collection_entry_modified_ip`, `collection_entry_deleted_by`, `collection_entry_deleted_on`, `collection_entry_deleted_ip`, `collection_entry_deleted_status`) VALUES
(1, 'ef90e2dvoe76f4fw3rxc245517bc563f2cffcff0', '00001', '2018-01-06', 0, 0, '500.00', 1, 4, 1, 1, 1515226950, '103.197.196.11', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `collection_entry_details`
--

CREATE TABLE `collection_entry_details` (
  `collection_entry_detail_id` int(11) NOT NULL,
  `collection_entry_detail_uniq_id` varchar(255) NOT NULL,
  `collection_entry_detail_collection_entry_id` int(11) NOT NULL,
  `collection_entry_detail_payment_mode` int(11) NOT NULL,
  `collection_entry_detail_bank_id` int(11) NOT NULL,
  `collection_entry_detail_amount` decimal(12,2) NOT NULL,
  `collection_entry_detail_invoice_amount` decimal(12,2) NOT NULL,
  `collection_entry_detail_disc_amount` decimal(12,2) NOT NULL,
  `collection_entry_detail_balance_amount` decimal(12,2) NOT NULL,
  `collection_entry_detail_remarks` varchar(255) NOT NULL,
  `collection_entry_detail_invoice_entry_id` int(11) NOT NULL,
  `collection_entry_detail_company_id` int(11) NOT NULL,
  `collection_entry_detail_branch_id` int(11) NOT NULL,
  `collection_entry_detail_financial_year` varchar(20) NOT NULL,
  `collection_entry_detail_added_by` int(11) NOT NULL,
  `collection_entry_detail_added_on` int(11) NOT NULL,
  `collection_entry_detail_added_ip` varchar(20) NOT NULL,
  `collection_entry_detail_modified_by` int(11) NOT NULL,
  `collection_entry_detail_modified_on` int(11) NOT NULL,
  `collection_entry_detail_modified_ip` varchar(20) NOT NULL,
  `collection_entry_detail_deleted_by` int(11) NOT NULL,
  `collection_entry_detail_deleted_on` int(11) NOT NULL,
  `collection_entry_detail_deleted_ip` varchar(20) NOT NULL,
  `collection_entry_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `collection_entry_details`
--

INSERT INTO `collection_entry_details` (`collection_entry_detail_id`, `collection_entry_detail_uniq_id`, `collection_entry_detail_collection_entry_id`, `collection_entry_detail_payment_mode`, `collection_entry_detail_bank_id`, `collection_entry_detail_amount`, `collection_entry_detail_invoice_amount`, `collection_entry_detail_disc_amount`, `collection_entry_detail_balance_amount`, `collection_entry_detail_remarks`, `collection_entry_detail_invoice_entry_id`, `collection_entry_detail_company_id`, `collection_entry_detail_branch_id`, `collection_entry_detail_financial_year`, `collection_entry_detail_added_by`, `collection_entry_detail_added_on`, `collection_entry_detail_added_ip`, `collection_entry_detail_modified_by`, `collection_entry_detail_modified_on`, `collection_entry_detail_modified_ip`, `collection_entry_detail_deleted_by`, `collection_entry_detail_deleted_on`, `collection_entry_detail_deleted_ip`, `collection_entry_detail_deleted_status`) VALUES
(1, '8b4b081ogoaeb6xc95ceb3534d385fa19d159e34', 1, 2, 1, '500.00', '1000.00', '10.00', '490.00', 'fcfhgghv', 3, 0, 0, '', 1, 1515226950, '103.197.196.11', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `company_id` int(11) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `company_logo` varchar(255) NOT NULL,
  `company_text` varchar(255) NOT NULL,
  `company_address` text NOT NULL,
  `company_contact_number` varchar(80) NOT NULL,
  `company_fax_number` varchar(80) NOT NULL,
  `company_email` varchar(80) NOT NULL,
  `company_tin_no` int(11) NOT NULL,
  `company_cst_no` varchar(20) NOT NULL,
  `company_ecc_no` varchar(20) NOT NULL,
  `company_service_tax_no` varchar(20) NOT NULL,
  `company_iec_no` varchar(20) NOT NULL,
  `company_pan_no` varchar(40) NOT NULL,
  `company_division` varchar(80) NOT NULL,
  `company_range` varchar(80) NOT NULL,
  `company_commisonerate` varchar(80) NOT NULL,
  `company_remarks` text NOT NULL,
  `company_bank_detail` text NOT NULL,
  `company_active_status` varchar(20) NOT NULL DEFAULT 'active',
  `company_deleted_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`company_id`, `company_name`, `company_logo`, `company_text`, `company_address`, `company_contact_number`, `company_fax_number`, `company_email`, `company_tin_no`, `company_cst_no`, `company_ecc_no`, `company_service_tax_no`, `company_iec_no`, `company_pan_no`, `company_division`, `company_range`, `company_commisonerate`, `company_remarks`, `company_bank_detail`, `company_active_status`, `company_deleted_status`) VALUES
(1, 'EVA', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `costing_entry`
--

CREATE TABLE `costing_entry` (
  `costingId` int(11) NOT NULL,
  `cs_invoiceId` int(11) NOT NULL,
  `cs_branchid` int(11) NOT NULL,
  `cs_port_location` varchar(100) NOT NULL,
  `cs_port_name` varchar(100) NOT NULL,
  `cs_costingdate` date NOT NULL,
  `cs_total_rate` decimal(10,0) NOT NULL,
  `cs_total_frgnrate` decimal(10,0) NOT NULL,
  `cs_company_id` int(11) NOT NULL,
  `cs_added_by` int(11) NOT NULL,
  `cs_added_on` datetime NOT NULL,
  `cs_added_ip` varchar(20) NOT NULL,
  `cs_modified_by` int(11) NOT NULL,
  `cs_modified_on` datetime NOT NULL,
  `cs_modified_ip` varchar(20) NOT NULL,
  `cs_deleted_by` int(11) NOT NULL,
  `cs_deleted_on` datetime NOT NULL,
  `cs_deleted_ip` varchar(20) NOT NULL,
  `cs_deleted_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `costing_entry`
--

INSERT INTO `costing_entry` (`costingId`, `cs_invoiceId`, `cs_branchid`, `cs_port_location`, `cs_port_name`, `cs_costingdate`, `cs_total_rate`, `cs_total_frgnrate`, `cs_company_id`, `cs_added_by`, `cs_added_on`, `cs_added_ip`, `cs_modified_by`, `cs_modified_on`, `cs_modified_ip`, `cs_deleted_by`, `cs_deleted_on`, `cs_deleted_ip`, `cs_deleted_status`) VALUES
(1, 4, 1, 'Yangon', '9', '2017-12-14', '1', '0', 0, 1, '2017-12-14 13:35:18', '103.197.196.20', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(2, 16, 3, 'Yangon', 'thilaewa', '2018-01-02', '14', '0', 0, 1, '2018-01-02 09:59:10', '103.197.196.14', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(3, 3, 4, 'Yangon', 'yahbhknk', '2018-01-04', '1', '0', 0, 1, '2018-01-04 10:26:06', '103.197.196.14', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(4, 6, 4, 'Yangon', 'vgbhh', '2018-01-05', '22', '0', 0, 1, '2018-01-05 10:03:00', '103.197.196.24', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `costing_entry_details`
--

CREATE TABLE `costing_entry_details` (
  `costId` int(11) NOT NULL,
  `c_costingId` int(11) NOT NULL,
  `c_costingname` text NOT NULL,
  `c_cost_id` int(11) NOT NULL,
  `c_currencyId` int(11) NOT NULL,
  `c_rate` decimal(11,2) NOT NULL,
  `c_frgnrate` decimal(11,2) NOT NULL,
  `c_amount` decimal(11,2) NOT NULL,
  `c_remarks` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `costing_entry_details`
--

INSERT INTO `costing_entry_details` (`costId`, `c_costingId`, `c_costingname`, `c_cost_id`, `c_currencyId`, `c_rate`, `c_frgnrate`, `c_amount`, `c_remarks`) VALUES
(1, 1, 'Agent fees', 0, 2, '1300.00', '100.00', '1.00', 'hjbnkjn'),
(2, 1, 'Custom duty', 0, 0, '5000.00', '1.00', '5.00', 'KJKNKJNJN'),
(3, 2, 'agent', 0, 3, '1000.00', '1.00', '1.00', ''),
(4, 3, 'agent', 0, 3, '1000.00', '1.00', '1.00', ''),
(5, 4, 'agent fees', 0, 0, '20000.00', '1.00', '20.00', ''),
(6, 4, 'kjknkjnkj', 0, 2, '1300.00', '2.00', '2.00', '');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `country_id` int(11) NOT NULL,
  `country_code` varchar(50) NOT NULL,
  `country_name` varchar(255) NOT NULL,
  `country_added_by` int(11) NOT NULL,
  `country_added_on` int(11) NOT NULL,
  `country_added_ip` varchar(20) NOT NULL,
  `country_modified_by` int(11) NOT NULL,
  `country_modified_on` int(11) NOT NULL,
  `country_modified_ip` varchar(20) NOT NULL,
  `country_deleted_by` int(11) NOT NULL,
  `country_deleted_on` int(11) NOT NULL,
  `country_deleted_ip` varchar(20) NOT NULL,
  `country_active_status` varchar(20) NOT NULL,
  `country_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`country_id`, `country_code`, `country_name`, `country_added_by`, `country_added_on`, `country_added_ip`, `country_modified_by`, `country_modified_on`, `country_modified_ip`, `country_deleted_by`, `country_deleted_on`, `country_deleted_ip`, `country_active_status`, `country_deleted_status`) VALUES
(1, '', 'Myanmar', 0, 0, '', 0, 0, '', 0, 0, '', 'active', 0),
(2, '', 'India', 1, 1506310296, '::1', 0, 0, '', 0, 0, '', 'active', 0),
(3, '', 'China', 1, 1512558294, '103.197.196.15', 0, 0, '', 0, 0, '', 'active', 0),
(4, '', 'Thailand', 1, 1513142667, '103.197.196.27', 0, 0, '', 0, 0, '', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `credit_note_entry`
--

CREATE TABLE `credit_note_entry` (
  `credit_note_entry_id` int(11) NOT NULL,
  `credit_note_entry_uniq_id` varchar(255) NOT NULL,
  `credit_note_entry_no` varchar(30) NOT NULL,
  `credit_note_entry_date` date NOT NULL,
  `credit_note_entry_customer_id` int(11) NOT NULL,
  `credit_note_entry_address` varchar(230) NOT NULL,
  `credit_note_entry_godown_id` int(11) NOT NULL,
  `credit_note_entry_remarks` varchar(550) NOT NULL,
  `credit_note_entry_type` int(11) NOT NULL,
  `credit_note_entry_amount` decimal(20,4) NOT NULL,
  `credit_note_entry_invoice_entry_id` int(11) NOT NULL,
  `credit_note_entry_company_id` int(11) NOT NULL,
  `credit_note_entry_branch_id` int(11) NOT NULL,
  `credit_note_entry_financial_year` int(11) NOT NULL,
  `credit_note_entry_added_by` int(11) NOT NULL,
  `credit_note_entry_added_on` int(11) NOT NULL,
  `credit_note_entry_added_ip` varchar(20) NOT NULL,
  `credit_note_entry_modified_by` int(11) NOT NULL,
  `credit_note_entry_modified_on` int(11) NOT NULL,
  `credit_note_entry_modified_ip` varchar(20) NOT NULL,
  `credit_note_entry_deleted_by` int(11) NOT NULL,
  `credit_note_entry_deleted_on` int(11) NOT NULL,
  `credit_note_entry_deleted_ip` varchar(20) NOT NULL,
  `credit_note_entry_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `credit_note_entry_product_details`
--

CREATE TABLE `credit_note_entry_product_details` (
  `credit_note_entry_product_detail_id` int(11) NOT NULL,
  `credit_note_entry_product_detail_uniq_id` varchar(255) NOT NULL,
  `credit_note_entry_product_detail_credit_note_entry_id` int(11) NOT NULL,
  `credit_note_entry_product_detail_product_id` int(11) NOT NULL,
  `credit_note_entry_product_detail_length_feet` decimal(20,4) NOT NULL,
  `credit_note_entry_product_detail_length_inches` decimal(20,4) NOT NULL,
  `credit_note_entry_product_detail_length_mm` decimal(20,4) NOT NULL,
  `credit_note_entry_product_detail_length_meter` decimal(20,4) NOT NULL,
  `credit_note_entry_product_detail_remarks` varchar(300) NOT NULL,
  `credit_note_entry_product_detail_qty` decimal(20,4) NOT NULL,
  `credit_note_entry_product_detail_invoice_entry_id` int(11) NOT NULL,
  `credit_note_entry_product_detail_invoice_detail_id` int(11) NOT NULL,
  `credit_note_entry_product_detail_type` int(11) NOT NULL,
  `credit_note_entry_product_detail_company_id` int(11) NOT NULL,
  `credit_note_entry_product_detail_branch_id` int(11) NOT NULL,
  `credit_note_entry_product_detail_financial_year` varchar(20) NOT NULL,
  `credit_note_entry_product_detail_added_by` int(11) NOT NULL,
  `credit_note_entry_product_detail_added_on` int(11) NOT NULL,
  `credit_note_entry_product_detail_added_ip` varchar(20) NOT NULL,
  `credit_note_entry_product_detail_modified_by` int(11) NOT NULL,
  `credit_note_entry_product_detail_modified_on` int(11) NOT NULL,
  `credit_note_entry_product_detail_modified_ip` varchar(20) NOT NULL,
  `credit_note_entry_product_detail_deleted_by` int(11) NOT NULL,
  `credit_note_entry_product_detail_deleted_on` int(11) NOT NULL,
  `credit_note_entry_product_detail_deleted_ip` varchar(20) NOT NULL,
  `credit_note_entry_product_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `currencies`
--

CREATE TABLE `currencies` (
  `currency_id` int(11) NOT NULL,
  `currency_uniq_id` varchar(100) NOT NULL,
  `currency_code` varchar(100) NOT NULL,
  `currency_name` varchar(255) NOT NULL,
  `currency_default` tinyint(11) NOT NULL,
  `currency_added_by` int(11) NOT NULL,
  `currency_added_on` int(11) NOT NULL,
  `currency_added_ip` varchar(20) NOT NULL,
  `currency_modified_by` int(11) NOT NULL,
  `currency_modified_on` int(11) NOT NULL,
  `currency_modified_ip` varchar(20) NOT NULL,
  `currency_deleted_by` int(11) NOT NULL,
  `currency_deleted_on` int(11) NOT NULL,
  `currency_deleted_ip` varchar(20) NOT NULL,
  `currency_active_status` varchar(20) NOT NULL DEFAULT 'active',
  `currency_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `currencies`
--

INSERT INTO `currencies` (`currency_id`, `currency_uniq_id`, `currency_code`, `currency_name`, `currency_default`, `currency_added_by`, `currency_added_on`, `currency_added_ip`, `currency_modified_by`, `currency_modified_on`, `currency_modified_ip`, `currency_deleted_by`, `currency_deleted_on`, `currency_deleted_ip`, `currency_active_status`, `currency_deleted_status`) VALUES
(1, '261beb57qba91aqf6h63773ea72a279d75c4f548', 'RS', 'Rupees', 0, 1, 1506320946, '::1', 1, 1506321014, '', 0, 0, '', 'active', 0),
(2, '510ec407r12f15fk75ndce551cda098a260d7532', '$', 'Dollar', 0, 1, 1506494995, '103.25.77.145', 0, 0, '', 0, 0, '', 'active', 0),
(3, 'fef5d80jlmb8f6m9zoja0d829144a3bf33c99551', 'MMK', 'Kyat', 0, 1, 1513743536, '103.197.196.6', 0, 0, '', 0, 0, '', 'active', 0),
(4, 'dbc322erep4ed6rblcide5b32d9d1b95e249a7c5', '$', 'United State Dollar', 0, 1, 1514866632, '103.197.196.14', 0, 0, '', 0, 0, '', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL,
  `customer_uniq_id` varchar(100) NOT NULL,
  `customer_code` varchar(10) NOT NULL,
  `customer_name` varchar(80) NOT NULL,
  `customer_company_name` varchar(100) NOT NULL,
  `customer_billing_address` text NOT NULL,
  `customer_shipping_address` text NOT NULL,
  `customer_country_id` int(11) NOT NULL,
  `customer_state_id` int(11) NOT NULL,
  `customer_city_id` int(11) NOT NULL,
  `customer_mobile_no` varchar(40) NOT NULL,
  `customer_line_phone` varchar(40) NOT NULL,
  `customer_contact_no` varchar(40) NOT NULL,
  `customer_email` varchar(40) NOT NULL,
  `customer_zip_code` varchar(40) NOT NULL,
  `customer_fax_no` varchar(40) NOT NULL,
  `customer_currency_id` int(11) NOT NULL,
  `customer_minimum_credit_per_day` decimal(12,3) NOT NULL,
  `customer_block_status` int(11) NOT NULL,
  `customer_location` int(11) NOT NULL,
  `customer_minimum_sales_limit` decimal(12,3) NOT NULL,
  `customer_customer_type_id` int(11) NOT NULL,
  `customer_total_credit_limit` decimal(12,3) NOT NULL,
  `customer_payment_days` int(11) NOT NULL,
  `customer_company_id` int(11) NOT NULL,
  `customer_added_by` int(11) NOT NULL,
  `customer_added_on` int(11) NOT NULL,
  `customer_added_ip` varchar(20) NOT NULL,
  `customer_modified_by` int(11) NOT NULL,
  `customer_modified_on` int(11) NOT NULL,
  `customer_modified_ip` varchar(20) NOT NULL,
  `customer_deleted_by` int(11) NOT NULL,
  `customer_deleted_on` int(11) NOT NULL,
  `customer_deleted_ip` varchar(20) NOT NULL,
  `customer_active_status` varchar(20) NOT NULL DEFAULT 'active',
  `customer_deleted_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `customer_uniq_id`, `customer_code`, `customer_name`, `customer_company_name`, `customer_billing_address`, `customer_shipping_address`, `customer_country_id`, `customer_state_id`, `customer_city_id`, `customer_mobile_no`, `customer_line_phone`, `customer_contact_no`, `customer_email`, `customer_zip_code`, `customer_fax_no`, `customer_currency_id`, `customer_minimum_credit_per_day`, `customer_block_status`, `customer_location`, `customer_minimum_sales_limit`, `customer_customer_type_id`, `customer_total_credit_limit`, `customer_payment_days`, `customer_company_id`, `customer_added_by`, `customer_added_on`, `customer_added_ip`, `customer_modified_by`, `customer_modified_on`, `customer_modified_ip`, `customer_deleted_by`, `customer_deleted_on`, `customer_deleted_ip`, `customer_active_status`, `customer_deleted_status`) VALUES
(1, '5bb6a9d2kme15ewskaq5da117775807e52bd3e4e', 'C00001', 'Karthik', 'Ponnai LTD', 'Chennai', 'Ponnai', 1, 1, 6, '8870772347', '04212354', '9884689004', 'karsho@gmail.com', '632514', '415236', 0, '10.000', 2, 1, '15.000', 2, '1000000.000', 5, 0, 1, 1504504619, '0', 0, 0, '', 0, 0, '', 'active', 0),
(2, '0edd24dm158f94n7j0m766326071c15d1706e1d6', 'C00002', 'Shankar', 'WIPRO', 'Andhra', 'Vellore', 1, 2, 2, '7884691002', '456987', '8554859004', 'shankar@gmail.com', '965415', '', 0, '4.000', 2, 2, '50000.000', 1, '100000.000', 10, 0, 1, 1504504817, '0', 0, 0, '', 0, 0, '', 'active', 0),
(3, '02c7cf0kgrdd6e1023t41c2a50d2275747370f61', 'C00001', 'Aung Tun', 'Aung', 'Yangon', 'Yangon', 1, 1, 1, '0930048110', '', '', '', '', '', 0, '0.000', 2, 1, '0.000', 0, '0.000', 0, 1, 1, 1510373791, '103', 0, 0, '', 0, 0, '', 'active', 0),
(4, '85eab82sf0c930eioslce335e8799b9dcee3523c', 'CU03', 'Customer_03', 'Com2', 'Address', 'Address', 1, 1, 5, '01', '', '', '', '', '', 0, '0.000', 2, 1, '0.000', 1, '0.000', 0, 1, 1, 1510729719, '103', 0, 0, '', 0, 0, '', 'active', 0),
(5, 'f0569acmor2819c34tsbcb2b934dcecad01990f4', 'Cus009988', 'Test Customer', 'Test Company Limited', 'Test', 'Yangon', 1, 1, 6, '097878987', '', '', 'testcustomer@gmail.com', '', '', 0, '0.000', 2, 1, '0.000', 2, '0.000', 0, 1, 1, 1512727876, '103', 0, 0, '', 0, 0, '', 'active', 0),
(6, '59befb6ktoc427ca9ko7fdb9219c14954c483f94', 'localcus99', 'Local Customer', 'Local Company Limited', 'Myanmar', 'Myanmar', 1, 1, 3, '09876543211', '121212', '1231212', 'lcoalcustomer@gmail.com', '', '', 0, '0.000', 2, 1, '0.000', 0, '0.000', 0, 1, 1, 1513142983, '103', 0, 0, '', 0, 0, '', 'active', 0),
(7, 'b579bcec6eb13cpkjs19c14db89589c9be20bd5d', '1000000', '1000000', 'other', 'Other', 'Other', 1, 1, 6, '09877654423', '1244432', '13231241', '1000000@gmail.com', '', '', 0, '0.000', 2, 1, '0.000', 0, '0.000', 0, 1, 1, 1513313069, '203', 0, 0, '', 0, 0, '', 'active', 0),
(8, '9e32f7ebpbd9b2c5asx264abb2618bc44e9f7a4b', 'GL001', 'Global', 'Global', 'MLM', 'MLM', 1, 8, 11, '1232', '134', '1324', 'global@gmail.com', '1', '1', 3, '14325.000', 2, 1, '4535.000', 3, '14235.000', 234, 1, 1, 1513746488, '103', 0, 0, '', 0, 0, '', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `customer_multi_contacts`
--

CREATE TABLE `customer_multi_contacts` (
  `customer_multi_contact_id` int(11) NOT NULL,
  `customer_multi_contact_customer_id` int(11) NOT NULL,
  `customer_multi_contact_title` varchar(80) NOT NULL,
  `customer_multi_contact_name` varchar(80) NOT NULL,
  `customer_multi_contact_department` varchar(80) NOT NULL,
  `customer_multi_contact_mobile_no` varchar(40) NOT NULL,
  `customer_multi_contact_email` varchar(80) NOT NULL,
  `customer_multi_contact_extn_no` int(5) NOT NULL,
  `customer_multi_contact_added_by` int(11) NOT NULL,
  `customer_multi_contact_added_on` int(11) NOT NULL,
  `customer_multi_contact_added_ip` varchar(20) NOT NULL,
  `customer_multi_contact_modified_by` int(11) NOT NULL,
  `customer_multi_contact_modified_on` int(11) NOT NULL,
  `customer_multi_contact_modified_ip` varchar(20) NOT NULL,
  `customer_multi_contact_deleted_by` int(11) NOT NULL,
  `customer_multi_contact_deleted_on` int(11) NOT NULL,
  `customer_multi_contact_deleted_ip` int(20) NOT NULL,
  `customer_multi_contact_deleted_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_multi_contacts`
--

INSERT INTO `customer_multi_contacts` (`customer_multi_contact_id`, `customer_multi_contact_customer_id`, `customer_multi_contact_title`, `customer_multi_contact_name`, `customer_multi_contact_department`, `customer_multi_contact_mobile_no`, `customer_multi_contact_email`, `customer_multi_contact_extn_no`, `customer_multi_contact_added_by`, `customer_multi_contact_added_on`, `customer_multi_contact_added_ip`, `customer_multi_contact_modified_by`, `customer_multi_contact_modified_on`, `customer_multi_contact_modified_ip`, `customer_multi_contact_deleted_by`, `customer_multi_contact_deleted_on`, `customer_multi_contact_deleted_ip`, `customer_multi_contact_deleted_status`) VALUES
(1, 1, 'Mr.', 'Rajkumar', 'Developer', '7788604423', 'raj@gmail.com', 987456, 1, 1504504619, '::1', 0, 0, '', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `customer_types`
--

CREATE TABLE `customer_types` (
  `customer_type_id` int(11) NOT NULL,
  `customer_type_uniq_id` varchar(100) NOT NULL,
  `customer_type_name` varchar(80) NOT NULL,
  `customer_type_company_id` int(11) NOT NULL,
  `customer_type_added_by` int(11) NOT NULL,
  `customer_type_added_on` int(11) NOT NULL,
  `customer_type_added_ip` varchar(20) NOT NULL,
  `customer_type_modified_by` int(11) NOT NULL,
  `customer_type_modified_on` int(11) NOT NULL,
  `customer_type_modified_ip` varchar(20) NOT NULL,
  `customer_type_deleted_by` int(11) NOT NULL,
  `customer_type_deleted_on` int(11) NOT NULL,
  `customer_type_deleted_ip` varchar(20) NOT NULL,
  `customer_type_active_status` varchar(20) NOT NULL DEFAULT 'active',
  `customer_type_deleted_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_types`
--

INSERT INTO `customer_types` (`customer_type_id`, `customer_type_uniq_id`, `customer_type_name`, `customer_type_company_id`, `customer_type_added_by`, `customer_type_added_on`, `customer_type_added_ip`, `customer_type_modified_by`, `customer_type_modified_on`, `customer_type_modified_ip`, `customer_type_deleted_by`, `customer_type_deleted_on`, `customer_type_deleted_ip`, `customer_type_active_status`, `customer_type_deleted_status`) VALUES
(1, '0d95cbezwc99824pu039bbb937e9b71686102ab8', 'Wholesale', 0, 1, 1504504363, '::1', 0, 0, '', 0, 0, '', 'active', 0),
(2, 'e0f0598966a947r48exb8fab711cac0a5127593c', 'Retail', 0, 1, 1504504381, '::1', 0, 0, '', 0, 0, '', 'active', 0),
(3, 'f185506ysdc3b7f0k3j1e27e11bfda7930a784cc', 'Door to Door', 1, 1, 1513746385, '103.197.196.6', 0, 0, '', 0, 0, '', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `damg_missing_scrp_details`
--

CREATE TABLE `damg_missing_scrp_details` (
  `dmgMsgScrpId` int(11) NOT NULL,
  `dms_select_type` int(1) NOT NULL,
  `dms_branchid` int(11) NOT NULL,
  `dms_warehouseid` int(11) NOT NULL,
  `dms_brandid` int(11) NOT NULL,
  `dms_product_status` int(11) NOT NULL,
  `dms_type` int(11) NOT NULL,
  `dms_productid` int(11) NOT NULL,
  `dms_date` date NOT NULL,
  `dms_colorid` int(11) NOT NULL,
  `dms_thick` decimal(11,2) NOT NULL,
  `dms_width` decimal(11,2) NOT NULL,
  `dms_po_entrytype` int(11) NOT NULL,
  `dms_production_order_id` int(11) NOT NULL,
  `dms_company_id` int(11) NOT NULL,
  `dms_added_by` int(11) NOT NULL,
  `dms_added_on` datetime NOT NULL,
  `dms_added_ip` varchar(20) NOT NULL,
  `dms_modified_by` int(11) NOT NULL,
  `dms_modified_on` datetime NOT NULL,
  `dms_modified_ip` varchar(20) NOT NULL,
  `dms_deleted_by` int(11) NOT NULL,
  `dms_deleted_on` datetime NOT NULL,
  `dms_deleted_ip` varchar(20) NOT NULL,
  `dms_deleted_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `damg_missing_scrp_details`
--

INSERT INTO `damg_missing_scrp_details` (`dmgMsgScrpId`, `dms_select_type`, `dms_branchid`, `dms_warehouseid`, `dms_brandid`, `dms_product_status`, `dms_type`, `dms_productid`, `dms_date`, `dms_colorid`, `dms_thick`, `dms_width`, `dms_po_entrytype`, `dms_production_order_id`, `dms_company_id`, `dms_added_by`, `dms_added_on`, `dms_added_ip`, `dms_modified_by`, `dms_modified_on`, `dms_modified_ip`, `dms_deleted_by`, `dms_deleted_on`, `dms_deleted_ip`, `dms_deleted_status`) VALUES
(1, 1, 1, 1, 10, 1, 1, 0, '2017-12-15', 1, '0.00', '0.00', 1, 0, 1, 1, '2017-12-15 15:56:51', '203.81.163.246', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(2, 1, 1, 2, 0, 0, 0, 0, '2017-12-16', 0, '0.00', '0.00', 0, 0, 1, 1, '2017-12-16 07:48:20', '103.242.98.230', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(3, 1, 1, 1, 0, 0, 0, 0, '2017-12-16', 0, '0.00', '0.00', 1, 0, 1, 1, '2017-12-16 12:08:52', '203.81.163.238', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `damg_missing_scrp_details_products`
--

CREATE TABLE `damg_missing_scrp_details_products` (
  `dmsProductId` int(11) NOT NULL,
  `dmsP_dmgMsgScrpId` int(11) NOT NULL,
  `dmsP_production_order_product_detail_id` int(11) NOT NULL,
  `dmsP_product_id` int(11) NOT NULL,
  `dmsP_qty` int(11) NOT NULL,
  `dmsP_rate` decimal(11,2) NOT NULL,
  `dmsP_amount` decimal(11,2) NOT NULL,
  `dmsP_deleted_status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `damg_missing_scrp_details_products`
--

INSERT INTO `damg_missing_scrp_details_products` (`dmsProductId`, `dmsP_dmgMsgScrpId`, `dmsP_production_order_product_detail_id`, `dmsP_product_id`, `dmsP_qty`, `dmsP_rate`, `dmsP_amount`, `dmsP_deleted_status`) VALUES
(1, 1, 0, 6, 1, '0.00', '0.00', 0),
(2, 2, 0, 5, 1020, '0.00', '0.00', 0),
(3, 2, 0, 12, 0, '0.00', '0.00', 0),
(4, 3, 0, 22, 10, '0.00', '0.00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `delivery_entry`
--

CREATE TABLE `delivery_entry` (
  `delivery_entry_id` int(11) NOT NULL,
  `delivery_entry_uniq_id` varchar(255) NOT NULL,
  `delivery_entry_no` varchar(30) NOT NULL,
  `delivery_entry_date` date NOT NULL,
  `delivery_entry_customer_id` int(11) NOT NULL,
  `delivery_entry_address` varchar(230) NOT NULL,
  `delivery_entry_vehicle_no` varchar(230) NOT NULL,
  `delivery_entry_person_name` varchar(230) NOT NULL,
  `delivery_entry_godown_id` int(11) NOT NULL,
  `delivery_entry_driver_name` varchar(230) NOT NULL,
  `delivery_entry_time` time NOT NULL,
  `delivery_entry_invoice_entry_id` int(11) NOT NULL,
  `delivery_entry_type_id` int(11) NOT NULL,
  `delivery_entry_company_id` int(11) NOT NULL,
  `delivery_entry_branch_id` int(11) NOT NULL,
  `delivery_entry_financial_year` int(11) NOT NULL,
  `delivery_entry_added_by` int(11) NOT NULL,
  `delivery_entry_added_on` int(11) NOT NULL,
  `delivery_entry_added_ip` varchar(20) NOT NULL,
  `delivery_entry_modified_by` int(11) NOT NULL,
  `delivery_entry_modified_on` int(11) NOT NULL,
  `delivery_entry_modified_ip` varchar(20) NOT NULL,
  `delivery_entry_deleted_by` int(11) NOT NULL,
  `delivery_entry_deleted_on` int(11) NOT NULL,
  `delivery_entry_deleted_ip` varchar(20) NOT NULL,
  `delivery_entry_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `delivery_entry`
--

INSERT INTO `delivery_entry` (`delivery_entry_id`, `delivery_entry_uniq_id`, `delivery_entry_no`, `delivery_entry_date`, `delivery_entry_customer_id`, `delivery_entry_address`, `delivery_entry_vehicle_no`, `delivery_entry_person_name`, `delivery_entry_godown_id`, `delivery_entry_driver_name`, `delivery_entry_time`, `delivery_entry_invoice_entry_id`, `delivery_entry_type_id`, `delivery_entry_company_id`, `delivery_entry_branch_id`, `delivery_entry_financial_year`, `delivery_entry_added_by`, `delivery_entry_added_on`, `delivery_entry_added_ip`, `delivery_entry_modified_by`, `delivery_entry_modified_on`, `delivery_entry_modified_ip`, `delivery_entry_deleted_by`, `delivery_entry_deleted_on`, `delivery_entry_deleted_ip`, `delivery_entry_deleted_status`) VALUES
(1, 'b270330j9k0504p91227b84007b0287ba7c31229', 'D00001', '2018-01-06', 1, '', 'TN 03 2145', 'AAA', 2, 'Ubenthiran', '10:01:00', 2, 1, 1, 2, 1, 1, 1515224844, '122.174.33.217', 0, 0, '', 0, 0, '', 0),
(2, 'fe45e5dn8pff8frabyyae9e4f9b07e3187cd12dd', 'DC903', '2018-01-06', 3, '', '', '', 2, '', '00:00:00', 7, 2, 1, 3, 1, 1, 1515231690, '103.197.196.11', 0, 0, '', 0, 0, '', 0),
(3, '1788bfbzwobe94e5ojm37bff486a663326257047', 'DE901', '2018-01-06', 3, '', '', '', 2, '', '00:00:00', 4, 1, 1, 3, 1, 1, 1515232368, '103.197.196.11', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `delivery_entry_product_details`
--

CREATE TABLE `delivery_entry_product_details` (
  `delivery_entry_product_detail_id` int(11) NOT NULL,
  `delivery_entry_product_detail_uniq_id` varchar(255) NOT NULL,
  `delivery_entry_product_detail_delivery_entry_id` int(11) NOT NULL,
  `delivery_entry_product_detail_invoice_detail_id` int(11) NOT NULL,
  `delivery_entry_product_detail_invoice_entry_id` int(11) NOT NULL,
  `delivery_entry_product_detail_product_id` int(11) NOT NULL,
  `delivery_entry_product_detail_product_type` int(11) NOT NULL,
  `delivery_entry_product_detail_product_thick` decimal(20,4) NOT NULL,
  `delivery_entry_product_detail_width_inches` decimal(20,4) NOT NULL,
  `delivery_entry_product_detail_width_mm` decimal(20,4) NOT NULL,
  `delivery_entry_product_detail_s_width_inches` decimal(20,4) NOT NULL,
  `delivery_entry_product_detail_s_width_mm` decimal(20,4) NOT NULL,
  `delivery_entry_product_detail_sl_feet` decimal(20,4) NOT NULL,
  `delivery_entry_product_detail_sl_feet_in` decimal(20,4) NOT NULL,
  `delivery_entry_product_detail_sl_feet_mm` decimal(20,4) NOT NULL,
  `delivery_entry_product_detail_s_weight_inches` decimal(20,4) NOT NULL,
  `delivery_entry_product_detail_s_weight_mm` decimal(20,4) NOT NULL,
  `delivery_entry_product_detail_tot_length` decimal(20,4) NOT NULL,
  `delivery_entry_product_detail_rate` decimal(20,4) NOT NULL,
  `delivery_entry_product_detail_total` decimal(20,4) NOT NULL,
  `delivery_entry_product_detail_qty` decimal(20,4) NOT NULL,
  `delivery_entry_product_detail_added_by` int(11) NOT NULL,
  `delivery_entry_product_detail_added_on` int(11) NOT NULL,
  `delivery_entry_product_detail_added_ip` varchar(20) NOT NULL,
  `delivery_entry_product_detail_modified_by` int(11) NOT NULL,
  `delivery_entry_product_detail_modified_on` int(11) NOT NULL,
  `delivery_entry_product_detail_modified_ip` varchar(20) NOT NULL,
  `delivery_entry_product_detail_deleted_by` int(11) NOT NULL,
  `delivery_entry_product_detail_deleted_on` int(11) NOT NULL,
  `delivery_entry_product_detail_deleted_ip` varchar(20) NOT NULL,
  `delivery_entry_product_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `delivery_entry_product_details`
--

INSERT INTO `delivery_entry_product_details` (`delivery_entry_product_detail_id`, `delivery_entry_product_detail_uniq_id`, `delivery_entry_product_detail_delivery_entry_id`, `delivery_entry_product_detail_invoice_detail_id`, `delivery_entry_product_detail_invoice_entry_id`, `delivery_entry_product_detail_product_id`, `delivery_entry_product_detail_product_type`, `delivery_entry_product_detail_product_thick`, `delivery_entry_product_detail_width_inches`, `delivery_entry_product_detail_width_mm`, `delivery_entry_product_detail_s_width_inches`, `delivery_entry_product_detail_s_width_mm`, `delivery_entry_product_detail_sl_feet`, `delivery_entry_product_detail_sl_feet_in`, `delivery_entry_product_detail_sl_feet_mm`, `delivery_entry_product_detail_s_weight_inches`, `delivery_entry_product_detail_s_weight_mm`, `delivery_entry_product_detail_tot_length`, `delivery_entry_product_detail_rate`, `delivery_entry_product_detail_total`, `delivery_entry_product_detail_qty`, `delivery_entry_product_detail_added_by`, `delivery_entry_product_detail_added_on`, `delivery_entry_product_detail_added_ip`, `delivery_entry_product_detail_modified_by`, `delivery_entry_product_detail_modified_on`, `delivery_entry_product_detail_modified_ip`, `delivery_entry_product_detail_deleted_by`, `delivery_entry_product_detail_deleted_on`, `delivery_entry_product_detail_deleted_ip`, `delivery_entry_product_detail_deleted_status`) VALUES
(1, '9227340ccwa038alh8uea7a725830926b0281da6', 1, 3, 2, 7, 0, '0.0000', '36.0000', '914.4000', '3.0000', '914.4000', '100.0000', '1200.0000', '30480.0000', '0.0000', '0.0000', '2083.3300', '300.0000', '75000.0000', '250.0000', 1, 1515224844, '122.174.33.217', 0, 0, '', 0, 0, '', 0),
(2, '51045d22bxfb5ab0arf9e7a2d256873cd6e7e46c', 1, 4, 2, 8, 0, '0.0000', '48.0000', '1219.2000', '3.0000', '914.4000', '200.0000', '2400.0000', '60960.0000', '0.0000', '0.0000', '3750.0000', '30.0000', '9000.0000', '300.0000', 1, 1515224844, '122.174.33.217', 0, 0, '', 0, 0, '', 0),
(3, '2e2a3a1d6k0adaje9bpcc5e629153696b1d31332', 2, 9, 7, 8, 0, '0.0000', '48.0000', '1219.2000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '10.0000', '0.0000', '0.0000', '100000.0000', '100000.0000', '1.0000', 1, 1515231690, '103.197.196.11', 0, 0, '', 0, 0, '', 0),
(4, 'b28b1ech0fc374ulo73259b45ed61fe85f1ec3ee', 3, 6, 4, 5, 0, '0.0000', '10.0000', '254.0000', '0.0000', '914.4000', '10.0000', '120.0000', '3048.0000', '0.0000', '0.0000', '0.0000', '1000.0000', '1000.0000', '1.0000', 1, 1515232368, '103.197.196.11', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `department_id` int(11) NOT NULL,
  `department_uniq_id` varchar(100) NOT NULL,
  `department_name` varchar(80) NOT NULL,
  `department_company_id` int(11) NOT NULL,
  `department_added_by` int(11) NOT NULL,
  `department_added_on` int(11) NOT NULL,
  `department_added_ip` varchar(20) NOT NULL,
  `department_modified_by` int(11) NOT NULL,
  `department_modified_on` int(11) NOT NULL,
  `department_modified_ip` varchar(20) NOT NULL,
  `department_deleted_by` int(11) NOT NULL,
  `department_deleted_on` int(11) NOT NULL,
  `department_deleted_ip` varchar(20) NOT NULL,
  `department_active_status` varchar(20) NOT NULL DEFAULT 'active',
  `department_deleted_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`department_id`, `department_uniq_id`, `department_name`, `department_company_id`, `department_added_by`, `department_added_on`, `department_added_ip`, `department_modified_by`, `department_modified_on`, `department_modified_ip`, `department_deleted_by`, `department_deleted_on`, `department_deleted_ip`, `department_active_status`, `department_deleted_status`) VALUES
(1, '', 'Software', 0, 0, 0, '', 0, 0, '', 0, 0, '', 'active', 0),
(2, '', 'Consultant', 0, 0, 0, '', 0, 0, '', 0, 0, '', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `do_god_entry`
--

CREATE TABLE `do_god_entry` (
  `do_god_entry_id` int(11) NOT NULL,
  `do_god_entry_uniq_id` varchar(255) NOT NULL,
  `do_god_entry_no` varchar(30) NOT NULL,
  `do_god_entry_date` date NOT NULL,
  `do_god_entry_customer_id` int(11) NOT NULL,
  `do_god_entry_address` varchar(230) NOT NULL,
  `do_god_entry_vehicle_no` varchar(230) NOT NULL,
  `do_god_entry_person_name` varchar(230) NOT NULL,
  `do_god_entry_godown_id` int(11) NOT NULL,
  `do_god_entry_driver_name` varchar(230) NOT NULL,
  `do_god_entry_time` time NOT NULL,
  `do_god_entry_production_order_id` int(11) NOT NULL,
  `do_god_entry_company_id` int(11) NOT NULL,
  `do_god_entry_branch_id` int(11) NOT NULL,
  `do_god_entry_financial_year` int(11) NOT NULL,
  `do_god_entry_added_by` int(11) NOT NULL,
  `do_god_entry_added_on` int(11) NOT NULL,
  `do_god_entry_added_ip` varchar(20) NOT NULL,
  `do_god_entry_modified_by` int(11) NOT NULL,
  `do_god_entry_modified_on` int(11) NOT NULL,
  `do_god_entry_modified_ip` varchar(20) NOT NULL,
  `do_god_entry_deleted_by` int(11) NOT NULL,
  `do_god_entry_deleted_on` int(11) NOT NULL,
  `do_god_entry_deleted_ip` varchar(20) NOT NULL,
  `do_god_entry_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `do_god_entry_product_details`
--

CREATE TABLE `do_god_entry_product_details` (
  `do_god_entry_product_detail_id` int(11) NOT NULL,
  `do_god_entry_product_detail_uniq_id` varchar(255) NOT NULL,
  `do_god_entry_product_detail_do_god_entry_id` int(11) NOT NULL,
  `do_god_entry_product_detail_product_id` int(11) NOT NULL,
  `do_god_entry_product_detail_length_feet` decimal(20,4) NOT NULL,
  `do_god_entry_product_detail_length_inches` decimal(20,4) NOT NULL,
  `do_god_entry_product_detail_length_mm` decimal(20,4) NOT NULL,
  `do_god_entry_product_detail_length_meter` decimal(20,4) NOT NULL,
  `do_god_entry_product_detail_remarks` varchar(300) NOT NULL,
  `do_god_entry_product_detail_qty` decimal(20,4) NOT NULL,
  `do_god_entry_product_detail_production_order_id` int(11) NOT NULL,
  `do_god_entry_product_detail_production_detail_id` int(11) NOT NULL,
  `do_god_entry_product_detail_type` int(11) NOT NULL,
  `do_god_entry_product_detail_company_id` int(11) NOT NULL,
  `do_god_entry_product_detail_branch_id` int(11) NOT NULL,
  `do_god_entry_product_detail_financial_year` varchar(20) NOT NULL,
  `do_god_entry_product_detail_added_by` int(11) NOT NULL,
  `do_god_entry_product_detail_added_on` int(11) NOT NULL,
  `do_god_entry_product_detail_added_ip` varchar(20) NOT NULL,
  `do_god_entry_product_detail_modified_by` int(11) NOT NULL,
  `do_god_entry_product_detail_modified_on` int(11) NOT NULL,
  `do_god_entry_product_detail_modified_ip` varchar(20) NOT NULL,
  `do_god_entry_product_detail_deleted_by` int(11) NOT NULL,
  `do_god_entry_product_detail_deleted_on` int(11) NOT NULL,
  `do_god_entry_product_detail_deleted_ip` varchar(20) NOT NULL,
  `do_god_entry_product_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `employee_id` int(11) NOT NULL,
  `employee_no` varchar(20) NOT NULL,
  `employee_name` varchar(80) NOT NULL,
  `employee_branchid` int(11) NOT NULL,
  `employee_dob` date NOT NULL,
  `employee_phone_no` varchar(13) NOT NULL,
  `employee_mobile_no` varchar(13) NOT NULL,
  `employee_email` varchar(55) NOT NULL,
  `employee_address` text NOT NULL,
  `employee_gender` int(1) NOT NULL,
  `employee_marital_status` int(2) NOT NULL,
  `employee_qulification` varchar(55) NOT NULL,
  `employee_total_exp` varchar(155) NOT NULL,
  `employee_last_company` varchar(155) NOT NULL,
  `employee_basic_pay` decimal(11,2) NOT NULL,
  `employee_deduction_day` decimal(11,2) NOT NULL,
  `employee_deduction_hrs` decimal(11,2) NOT NULL,
  `employee_nrc` varchar(35) NOT NULL,
  `employee_employee_ssb` decimal(11,2) NOT NULL,
  `employee_employeer_ssb` decimal(11,2) NOT NULL,
  `employee_leave_permit` int(3) NOT NULL,
  `employee_medical_leave` int(3) NOT NULL,
  `employee_cascal_leave` int(3) NOT NULL,
  `employee_annual_leave` int(3) NOT NULL,
  `employee_other_leave` int(3) NOT NULL,
  `employee_customized` varchar(55) NOT NULL,
  `employee_status` int(1) NOT NULL,
  `employee_bonus` int(1) NOT NULL,
  `employee_bonus_amnt` decimal(11,2) NOT NULL,
  `employee_allowance` int(1) NOT NULL,
  `employee_phone_allowance` decimal(11,2) NOT NULL,
  `employee_food_allowance` decimal(11,2) NOT NULL,
  `employee_travel_allowance` decimal(11,2) NOT NULL,
  `employee_other_allowance` decimal(11,2) NOT NULL,
  `employee_overtime_day` decimal(11,2) NOT NULL,
  `employee_overtime_hrs` decimal(11,2) NOT NULL,
  `employee_device_id` varchar(15) NOT NULL,
  `gov_bouns` decimal(12,2) NOT NULL,
  `without_bouns` decimal(12,2) NOT NULL,
  `exp_bouns` decimal(12,2) NOT NULL,
  `other_bouns` decimal(12,2) NOT NULL,
  `employee_image` varchar(255) NOT NULL,
  `employee_company_id` int(11) NOT NULL,
  `employee_added_by` int(11) NOT NULL,
  `employee_added_on` datetime NOT NULL,
  `employee_added_ip` varchar(20) NOT NULL,
  `employee_modified_by` int(11) NOT NULL,
  `employee_modified_on` datetime NOT NULL,
  `employee_modified_ip` varchar(20) NOT NULL,
  `employee_deleted_by` int(11) NOT NULL,
  `employee_deleted_on` datetime NOT NULL,
  `employee_deleted_ip` varchar(20) NOT NULL,
  `employee_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`employee_id`, `employee_no`, `employee_name`, `employee_branchid`, `employee_dob`, `employee_phone_no`, `employee_mobile_no`, `employee_email`, `employee_address`, `employee_gender`, `employee_marital_status`, `employee_qulification`, `employee_total_exp`, `employee_last_company`, `employee_basic_pay`, `employee_deduction_day`, `employee_deduction_hrs`, `employee_nrc`, `employee_employee_ssb`, `employee_employeer_ssb`, `employee_leave_permit`, `employee_medical_leave`, `employee_cascal_leave`, `employee_annual_leave`, `employee_other_leave`, `employee_customized`, `employee_status`, `employee_bonus`, `employee_bonus_amnt`, `employee_allowance`, `employee_phone_allowance`, `employee_food_allowance`, `employee_travel_allowance`, `employee_other_allowance`, `employee_overtime_day`, `employee_overtime_hrs`, `employee_device_id`, `gov_bouns`, `without_bouns`, `exp_bouns`, `other_bouns`, `employee_image`, `employee_company_id`, `employee_added_by`, `employee_added_on`, `employee_added_ip`, `employee_modified_by`, `employee_modified_on`, `employee_modified_ip`, `employee_deleted_by`, `employee_deleted_on`, `employee_deleted_ip`, `employee_deleted_status`) VALUES
(1, '', 'Vijay', 1, '2017-10-03', '6786786767', '9867543423', 'cithggin', 'rtweweewr', 1, 1, 'mc', '5', 'THINKSYNQ', '55000.00', '500.00', '55.00', 'NRC32', '3.00', '4.00', 5, 0, 1, 1, 1, '1', 2, 1, '500.00', 1, '5000.00', '200.00', '300.00', '400.00', '500.00', '500.00', '55', '0.00', '0.00', '0.00', '0.00', '', 0, 1, '2017-10-31 12:58:09', '192.168.1.4', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(2, '', 'CITHRAVEL', 1, '2017-10-12', '6786786767', '9867543423', 'CITHARVEL@GMAIL.COM', 'FDFDSFSDF', 1, 1, 'mca', '5', 'THINKSYNQ', '6000.00', '200.00', '0.00', 'nrc', '3.00', '4.00', 25, 10, 4, 4, 4, '3', 2, 1, '0.00', 1, '0.00', '1000.00', '1000.00', '0.00', '0.00', '22.22', '4', '0.00', '0.00', '0.00', '0.00', '', 0, 1, '2017-10-31 12:59:44', '192.168.1.4', 1, '2017-10-31 18:14:33', '192.168.1.4', 0, '0000-00-00 00:00:00', ' ', 0),
(3, '', 'vel', 1, '2017-10-31', '6786786767', '9867543423', 'CITHARVEL@GMAIL.COM', 'werwerwe', 1, 1, 'mc', '5', 'THINKSYNQ', '35000.00', '1166.67', '129.63', 'werw', '4.00', '5.00', 10, 2, 3, 2, 1, '1', 2, 1, '500.00', 1, '500.00', '600.00', '1000.00', '100.00', '1166.67', '129.63', '1', '0.00', '0.00', '0.00', '0.00', '', 0, 1, '2017-10-31 18:29:15', '192.168.1.4', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(4, '', 'Prakash', 1, '1993-07-20', '9659802125', '9659802125', 'ramprakashtrp@gmail.com', 'chennai', 1, 0, 'mca', '5', '4354', '22000.00', '733.33', '81.48', 'shdjg', '45.00', '0.00', 243, 234, 0, 0, 0, '5', 2, 1, '3000.00', 1, '800.00', '700.00', '400.00', '500.00', '733.33', '81.48', '10', '0.00', '0.00', '0.00', '0.00', '', 1, 1, '2017-11-10 17:47:52', '192.168.1.8', 1, '2017-12-15 16:11:56', '182.65.86.37', 0, '0000-00-00 00:00:00', '', 0),
(5, '', 'Mg Mg', 1, '1994-10-05', '0956789909', '', '', 'Yangon', 1, 0, '', '', '', '150000.00', '5000.00', '555.56', '46789', '0.00', '0.00', 0, 0, 0, 0, 0, '', 2, 1, '0.00', 1, '5000.00', '10000.00', '2000.00', '0.00', '5000.00', '555.56', '', '0.00', '0.00', '0.00', '0.00', '', 1, 1, '2017-11-13 09:56:50', '103.197.196.40', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(6, '', 'Emp02', 1, '1976-12-15', '32', '32', '', '', 1, 1, 'Bsc', '4', 'Comp2', '200000.00', '6666.67', '740.74', 'RE4', '2.00', '3.00', 3, 1, 1, 1, 0, '', 2, 1, '0.00', 1, '0.00', '0.00', '0.00', '0.00', '1000.00', '1500.00', '3', '10000.00', '10000.00', '10000.00', '10000.00', '', 1, 1, '2017-12-06 15:52:59', '103.197.196.15', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(7, '', 'Han Ni Tun', 2, '1994-03-11', '0930048110', '7010704245', 'vanila@authorsmyanmar.com', 'Thingankyunt', 2, 1, 'BCSc computer science', '3', '3', '200000.00', '6666.67', '740.74', '1223', '2.00', '3.00', 10, 5, 3, 2, 0, '', 2, 1, '0.00', 1, '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', '30000.00', '7500.00', '2500.00', '0.00', '', 1, 1, '2017-12-07 08:58:42', '103.197.196.15', 1, '2017-12-15 16:12:40', '182.65.86.37', 0, '0000-00-00 00:00:00', '', 0),
(8, '', 'Emp03 13122017', 1, '1986-01-16', '90', '90', '', 'address', 1, 1, 'Bsc', '4', 'Comp1', '200000.00', '6666.67', '740.74', 'rter321312', '3.00', '2.00', 10, 3, 3, 3, 1, '', 2, 1, '0.00', 1, '0.00', '0.00', '0.00', '0.00', '800.00', '1000.00', '1', '10000.00', '10000.00', '10000.00', '0.00', '', 1, 1, '2017-12-13 15:42:13', '103.197.196.27', 1, '2017-12-13 15:43:44', '103.197.196.27', 0, '0000-00-00 00:00:00', '', 0),
(9, '', 'Emp 14122017', 1, '1986-03-07', '89', '89', '', 'Addess 890', 1, 2, 'MCA', '3', 'Company 2', '200000.00', '6666.67', '740.74', 'Yu7595jg', '3.00', '2.00', 5, 1, 2, 1, 1, '', 2, 1, '0.00', 1, '0.00', '0.00', '0.00', '0.00', '900.00', '1200.00', '34', '9000.00', '9000.00', '9000.00', '0.00', '', 1, 1, '2017-12-14 09:12:46', '103.197.196.20', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(10, '', 'emp 14122017', 1, '1978-04-08', '45', '45', '', '45', 1, 3, 'Bsc', '6', 'Comp2', '300000.00', '10000.00', '1111.11', 'sfsd', '3.00', '2.00', 3, 1, 1, 1, 0, '', 2, 1, '0.00', 1, '0.00', '0.00', '0.00', '0.00', '1000.00', '1500.00', '34', '10000.00', '10000.00', '10000.00', '0.00', '', 1, 1, '2017-12-15 16:29:25', '203.81.163.246', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(11, '', 'emp 1612017', 1, '1980-05-08', '56', '56', '', '56', 1, 3, 'Bsc', '6', 'Comp2', '300000.00', '10000.00', '1111.11', '1t566', '3.00', '2.00', 1, 1, 0, 0, 0, '', 2, 1, '0.00', 1, '0.00', '0.00', '0.00', '0.00', '1000.00', '1500.00', '21', '10000.00', '10000.00', '10000.00', '0.00', '', 1, 1, '2017-12-16 08:33:39', '203.81.163.238', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(12, '', 'Emp Thiru01', 1, '1982-05-05', '34', '34', '', '34', 1, 1, 'Bsc', '4', 'Comp2', '300000.00', '10000.00', '1111.11', '1fsd32', '3.00', '2.00', 1, 1, 0, 0, 0, '', 2, 1, '0.00', 1, '0.00', '0.00', '0.00', '0.00', '1200.00', '1800.00', '34', '10000.00', '10000.00', '10000.00', '0.00', '', 1, 1, '2017-12-16 10:04:07', '203.81.163.238', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(13, '', 'Aung', 3, '1995-12-01', '09970790828', '1', 'aung@gmail.com', 'tamwe', 1, 1, 'BA', '1', 'emerald', '108000.00', '3600.00', '400.00', '12hfkdnjkn', '2.00', '3.00', 10, 2, 3, 5, 0, '', 2, 1, '0.00', 1, '5000.00', '2000.00', '2000.00', '3000.00', '1000.00', '1500.00', '1', '31500.00', '7500.00', '3000.00', '0.00', '', 1, 1, '2017-12-27 11:24:56', '103.197.196.8', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `emp_advance`
--

CREATE TABLE `emp_advance` (
  `empAdvanceId` int(11) NOT NULL,
  `ad_branchid` int(11) NOT NULL,
  `ad_employee_id` int(11) NOT NULL,
  `ad_amount` decimal(11,2) NOT NULL,
  `ad_date` date NOT NULL,
  `ad_requestby` int(11) NOT NULL,
  `ad_approvalby` int(11) NOT NULL,
  `ad_remarks` text NOT NULL,
  `ad_company_id` int(11) NOT NULL,
  `ad_added_by` int(11) NOT NULL,
  `ad_added_on` datetime NOT NULL,
  `ad_added_ip` varchar(20) NOT NULL,
  `ad_modified_by` int(11) NOT NULL,
  `ad_modified_on` datetime NOT NULL,
  `ad_modified_ip` varchar(20) NOT NULL,
  `ad_deleted_by` int(11) NOT NULL,
  `ad_deleted_on` datetime NOT NULL,
  `ad_deleted_ip` varchar(20) NOT NULL,
  `ad_deleted_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_advance`
--

INSERT INTO `emp_advance` (`empAdvanceId`, `ad_branchid`, `ad_employee_id`, `ad_amount`, `ad_date`, `ad_requestby`, `ad_approvalby`, `ad_remarks`, `ad_company_id`, `ad_added_by`, `ad_added_on`, `ad_added_ip`, `ad_modified_by`, `ad_modified_on`, `ad_modified_ip`, `ad_deleted_by`, `ad_deleted_on`, `ad_deleted_ip`, `ad_deleted_status`) VALUES
(1, 1, 8, '10000.00', '2017-12-13', 6, 6, 'advance remarks', 1, 1, '2017-12-13 15:49:12', '103.197.196.27', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(2, 1, 9, '10000.00', '2017-12-13', 8, 8, 'advance Remarks', 1, 1, '2017-12-14 09:19:23', '103.197.196.20', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(3, 2, 2, '1500.00', '2017-12-15', 1, 1, 'test', 1, 1, '2017-12-15 16:15:54', '182.65.86.37', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(4, 1, 11, '10000.00', '2017-12-16', 2, 2, 're', 1, 1, '2017-12-16 08:37:43', '203.81.163.238', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(5, 1, 12, '10000.00', '2017-12-16', 6, 6, '', 1, 1, '2017-12-16 10:09:36', '203.81.163.238', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(6, 3, 13, '10000.00', '2017-12-27', 7, 7, 'Dec advance', 1, 1, '2017-12-27 11:41:39', '103.197.196.8', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `emp_attendance`
--

CREATE TABLE `emp_attendance` (
  `empAtncId` int(11) NOT NULL,
  `atnc_branchid` int(11) NOT NULL,
  `atnc_employee_id` int(11) NOT NULL,
  `atnc_intime` time NOT NULL,
  `atnc_outtime` time NOT NULL,
  `atnc_date` date NOT NULL,
  `atnc_remark` text NOT NULL,
  `atnc_company_id` int(11) NOT NULL,
  `atnc_added_by` int(11) NOT NULL,
  `atnc_added_on` datetime NOT NULL,
  `atnc_added_ip` varchar(20) NOT NULL,
  `atnc_modified_by` int(11) NOT NULL,
  `atnc_modified_on` datetime NOT NULL,
  `atnc_modified_ip` varchar(20) NOT NULL,
  `atnc_deleted_by` int(11) NOT NULL,
  `atnc_deleted_on` datetime NOT NULL,
  `atnc_deleted_ip` varchar(20) NOT NULL,
  `atnc_deleted_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_attendance`
--

INSERT INTO `emp_attendance` (`empAtncId`, `atnc_branchid`, `atnc_employee_id`, `atnc_intime`, `atnc_outtime`, `atnc_date`, `atnc_remark`, `atnc_company_id`, `atnc_added_by`, `atnc_added_on`, `atnc_added_ip`, `atnc_modified_by`, `atnc_modified_on`, `atnc_modified_ip`, `atnc_deleted_by`, `atnc_deleted_on`, `atnc_deleted_ip`, `atnc_deleted_status`) VALUES
(1, 1, 8, '01:30:00', '14:30:00', '2017-12-11', 'test', 1, 1, '2017-12-13 15:44:17', '103.197.196.27', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(2, 1, 9, '01:30:00', '14:30:00', '2017-12-11', 'Attendance Remarks', 1, 1, '2017-12-14 09:15:30', '103.197.196.20', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(3, 1, 2, '06:30:00', '06:30:00', '2017-11-16', 'Uben', 1, 1, '2017-12-15 16:56:37', '182.65.86.37', 1, '2017-12-15 17:04:35', '182.65.86.37', 0, '0000-00-00 00:00:00', '', 0),
(4, 1, 2, '19:00:00', '19:00:00', '2017-11-15', 'Uben', 1, 1, '2017-12-15 17:04:12', '182.65.86.37', 1, '2017-12-15 17:04:46', '182.65.86.37', 0, '0000-00-00 00:00:00', '', 0),
(5, 3, 13, '09:00:00', '05:00:00', '2017-12-27', 'outsite way', 1, 1, '2017-12-27 11:25:51', '103.197.196.8', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `emp_leave`
--

CREATE TABLE `emp_leave` (
  `empLeaveId` int(11) NOT NULL,
  `lv_branchid` int(11) NOT NULL,
  `lv_employee_id` int(11) NOT NULL,
  `lv_paymentid` int(11) NOT NULL,
  `lv_leave` int(2) NOT NULL,
  `lv_leavetype` varchar(255) NOT NULL,
  `lv_date` date NOT NULL,
  `lv_fromdate` date NOT NULL,
  `lv_todate` date NOT NULL,
  `lv_leaveno` int(11) NOT NULL,
  `lv_requestbyid` int(11) NOT NULL,
  `lv_approvalid` int(11) NOT NULL,
  `lv_remarks` text NOT NULL,
  `lv_company_id` int(11) NOT NULL,
  `lv_added_by` int(11) NOT NULL,
  `lv_added_on` datetime NOT NULL,
  `lv_added_ip` varchar(20) NOT NULL,
  `lv_modified_by` int(11) NOT NULL,
  `lv_modified_on` datetime NOT NULL,
  `lv_modified_ip` varchar(20) NOT NULL,
  `lv_deleted_by` int(11) NOT NULL,
  `lv_deleted_on` datetime NOT NULL,
  `lv_deleted_ip` varchar(20) NOT NULL,
  `lv_deleted_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_leave`
--

INSERT INTO `emp_leave` (`empLeaveId`, `lv_branchid`, `lv_employee_id`, `lv_paymentid`, `lv_leave`, `lv_leavetype`, `lv_date`, `lv_fromdate`, `lv_todate`, `lv_leaveno`, `lv_requestbyid`, `lv_approvalid`, `lv_remarks`, `lv_company_id`, `lv_added_by`, `lv_added_on`, `lv_added_ip`, `lv_modified_by`, `lv_modified_on`, `lv_modified_ip`, `lv_deleted_by`, `lv_deleted_on`, `lv_deleted_ip`, `lv_deleted_status`) VALUES
(1, 1, 4, 1, 1, '1', '2017-12-15', '2017-12-15', '2017-12-19', 4, 1, 2, 'test', 1, 1, '2017-12-15 16:25:06', '182.65.86.37', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(2, 1, 0, 1, 1, '2', '2017-12-15', '2017-12-08', '2017-12-09', 1, 3, 3, 'ds', 1, 1, '2017-12-15 16:30:14', '203.81.163.246', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(3, 1, 10, 2, 1, '2', '2017-12-15', '2017-12-11', '2017-12-12', 1, 2, 6, 'w', 1, 1, '2017-12-15 16:30:52', '203.81.163.246', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(4, 1, 2, 1, 1, '2', '2017-11-16', '2017-11-17', '2017-11-18', 2, 1, 7, 'FDV', 1, 1, '2017-12-15 17:11:56', '182.65.86.37', 1, '2017-12-15 17:16:35', '182.65.86.37', 0, '0000-00-00 00:00:00', '', 0),
(5, 1, 11, 1, 1, '4', '2017-12-16', '2017-12-13', '2017-12-14', 2, 2, 2, 're', 1, 1, '2017-12-16 08:35:12', '203.81.163.238', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(6, 1, 11, 2, 1, '2', '2017-12-16', '2017-12-14', '2017-12-15', 2, 2, 4, 're', 1, 1, '2017-12-16 08:35:49', '203.81.163.238', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(7, 1, 12, 1, 1, '1', '2017-12-16', '2017-12-06', '2017-12-07', 2, 2, 2, 're', 1, 1, '2017-12-16 10:05:35', '203.81.163.238', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(8, 1, 12, 2, 1, '2', '2017-12-16', '2017-12-11', '2017-12-12', 2, 6, 6, 're', 1, 1, '2017-12-16 10:06:20', '203.81.163.238', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(9, 3, 13, 1, 1, '5', '2017-12-27', '2017-12-28', '2017-12-28', 1, 7, 7, '', 1, 1, '2017-12-27 11:27:25', '103.197.196.8', 1, '2017-12-27 13:01:48', '103.197.196.8', 0, '0000-00-00 00:00:00', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `emp_overtime`
--

CREATE TABLE `emp_overtime` (
  `empOtId` int(11) NOT NULL,
  `ot_branchid` int(11) NOT NULL,
  `ot_employee_id` int(11) NOT NULL,
  `ot_starttime` time NOT NULL,
  `ot_endtime` time NOT NULL,
  `ot_durationtime` time NOT NULL,
  `ot_date` date NOT NULL,
  `ot_amount` decimal(11,2) NOT NULL,
  `ot_aprovalamnt` decimal(11,2) NOT NULL,
  `ot_requestby` int(11) NOT NULL,
  `ot_approvalby` int(11) NOT NULL,
  `ot_remarks` text NOT NULL,
  `ot_type_id` int(11) NOT NULL,
  `ot_rate` decimal(12,2) NOT NULL,
  `ot_company_id` int(11) NOT NULL,
  `ot_added_by` int(11) NOT NULL,
  `ot_added_on` datetime NOT NULL,
  `ot_added_ip` varchar(20) NOT NULL,
  `ot_modified_by` int(11) NOT NULL,
  `ot_modified_on` int(11) NOT NULL,
  `ot_modified_ip` varchar(20) NOT NULL,
  `ot_deleted_by` datetime NOT NULL,
  `ot_deleted_on` datetime NOT NULL,
  `ot_deleted_ip` varchar(20) NOT NULL,
  `ot_deleted_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_overtime`
--

INSERT INTO `emp_overtime` (`empOtId`, `ot_branchid`, `ot_employee_id`, `ot_starttime`, `ot_endtime`, `ot_durationtime`, `ot_date`, `ot_amount`, `ot_aprovalamnt`, `ot_requestby`, `ot_approvalby`, `ot_remarks`, `ot_type_id`, `ot_rate`, `ot_company_id`, `ot_added_by`, `ot_added_on`, `ot_added_ip`, `ot_modified_by`, `ot_modified_on`, `ot_modified_ip`, `ot_deleted_by`, `ot_deleted_on`, `ot_deleted_ip`, `ot_deleted_status`) VALUES
(1, 1, 8, '01:00:00', '04:00:00', '00:00:00', '2017-12-02', '3000.00', '3000.00', 6, 6, 'test', 2, '1000.00', 1, 1, '2017-12-13 15:47:38', '103.197.196.27', 0, 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 0),
(2, 1, 9, '01:00:00', '03:30:00', '00:00:00', '2017-12-04', '2250.00', '2500.00', 8, 8, 'OT rema1', 1, '900.00', 1, 1, '2017-12-14 09:17:56', '103.197.196.20', 0, 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 0),
(3, 1, 9, '02:00:00', '06:30:00', '00:00:00', '0000-00-00', '5400.00', '5500.00', 8, 8, 'OT rema2', 2, '1200.00', 1, 1, '2017-12-14 09:18:40', '103.197.196.20', 0, 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 0),
(4, 1, 4, '11:00:00', '14:30:00', '00:00:00', '2017-12-15', '2566.66', '2000.00', 4, 4, 'test', 1, '733.33', 1, 1, '2017-12-15 16:15:23', '182.65.86.37', 0, 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 0),
(5, 1, 0, '01:00:00', '08:30:00', '00:00:00', '0000-00-00', '7500.00', '8000.00', 8, 2, '', 1, '1000.00', 1, 1, '2017-12-15 16:31:32', '203.81.163.246', 0, 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 0),
(6, 1, 10, '01:00:00', '04:30:00', '00:00:00', '2017-12-15', '5250.00', '6000.00', 3, 2, '', 2, '1500.00', 1, 1, '2017-12-15 16:32:05', '203.81.163.246', 0, 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 0),
(7, 1, 2, '08:00:00', '16:30:00', '00:00:00', '2017-11-03', '188.87', '100.00', 4, 7, 'dfA', 2, '22.22', 1, 1, '2017-12-15 17:08:58', '182.65.86.37', 0, 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 0),
(8, 1, 11, '01:00:00', '02:00:00', '00:00:00', '0000-00-00', '1000.00', '1000.00', 2, 2, 're', 1, '1000.00', 1, 1, '2017-12-16 08:36:43', '203.81.163.238', 0, 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 0),
(9, 1, 11, '01:00:00', '02:00:00', '00:00:00', '0000-00-00', '1500.00', '1500.00', 2, 2, 're', 2, '1500.00', 1, 1, '2017-12-16 08:37:14', '203.81.163.238', 0, 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 0),
(10, 1, 12, '01:00:00', '02:00:00', '00:00:00', '2017-12-16', '1800.00', '1500.00', 6, 6, 're', 0, '1200.00', 1, 1, '2017-12-16 10:07:08', '203.81.163.238', 1, 2147483647, '203.81.163.238', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 0),
(11, 1, 12, '01:00:00', '02:00:00', '00:00:00', '2017-12-16', '1800.00', '2000.00', 6, 6, 're', 2, '1800.00', 1, 1, '2017-12-16 10:07:43', '203.81.163.238', 0, 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 0),
(12, 3, 13, '05:30:00', '06:30:00', '00:00:00', '2017-12-27', '1000.00', '1200.00', 7, 7, 'production', 1, '1000.00', 1, 1, '2017-12-27 11:35:39', '103.197.196.8', 0, 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `expense_payable`
--

CREATE TABLE `expense_payable` (
  `expensePayId` int(11) NOT NULL,
  `exP_branchid` int(11) NOT NULL,
  `exP_payable_typ` varchar(20) NOT NULL,
  `exP_payment_mode` varchar(20) NOT NULL,
  `exP_credit_ac` varchar(20) NOT NULL,
  `exP_debit_ac` varchar(20) NOT NULL,
  `exP_amount` decimal(11,2) NOT NULL,
  `exP_expense_date` date NOT NULL,
  `exP_ref_details` int(11) NOT NULL,
  `exP_narration` varchar(20) NOT NULL,
  `exP_request_by` varchar(20) NOT NULL,
  `exP_approval_by` varchar(20) NOT NULL,
  `exP_company_id` int(11) NOT NULL,
  `exP_added_by` int(11) NOT NULL,
  `exP_added_on` datetime NOT NULL,
  `exP_added_ip` varchar(20) NOT NULL,
  `exP_modified_by` int(11) NOT NULL,
  `exP_modified_on` datetime NOT NULL,
  `exP_modified_ip` varchar(20) NOT NULL,
  `exP_deleted_by` int(11) NOT NULL,
  `exP_deleted_on` datetime NOT NULL,
  `exP_deleted_ip` varchar(20) NOT NULL,
  `exP_deleted_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `financial_years`
--

CREATE TABLE `financial_years` (
  `financial_year_id` int(11) NOT NULL,
  `financial_year_from` varchar(40) NOT NULL,
  `financial_year_to` varchar(40) NOT NULL,
  `financial_year_form_date` date NOT NULL,
  `financial_year_to_date` date NOT NULL,
  `financial_year_opening_date` date NOT NULL,
  `financial_year_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `financial_years`
--

INSERT INTO `financial_years` (`financial_year_id`, `financial_year_from`, `financial_year_to`, `financial_year_form_date`, `financial_year_to_date`, `financial_year_opening_date`, `financial_year_status`) VALUES
(1, '2017', '2018', '2017-04-01', '2018-03-31', '2017-04-01', 0);

-- --------------------------------------------------------

--
-- Table structure for table `gate_pass`
--

CREATE TABLE `gate_pass` (
  `gatePassId` int(11) NOT NULL,
  `gp_pdo_entry_id` int(11) NOT NULL,
  `gp_branchid` int(11) NOT NULL,
  `gp_date` date NOT NULL,
  `gp_company_id` int(11) NOT NULL,
  `gp_added_by` int(11) NOT NULL,
  `gp_added_on` datetime NOT NULL,
  `gp_added_ip` varchar(20) NOT NULL,
  `gp_modified_by` int(11) NOT NULL,
  `gp_modified_on` datetime NOT NULL,
  `gp_modified_ip` varchar(20) NOT NULL,
  `gp_deleted_by` int(11) NOT NULL,
  `gp_deleted_on` datetime NOT NULL,
  `gp_deleted_ip` varchar(20) NOT NULL,
  `gp_deleted_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gate_pass_product_details`
--

CREATE TABLE `gate_pass_product_details` (
  `gpProductdetailsId` int(11) NOT NULL,
  `gpP_gatePassId` int(11) NOT NULL,
  `gpP_pdo_entry_product_detail_id` int(11) NOT NULL,
  `gpP_product_id` int(11) NOT NULL,
  `gpP_qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gin_entry`
--

CREATE TABLE `gin_entry` (
  `gin_entry_id` int(11) NOT NULL,
  `gin_entry_uniq_id` varchar(255) NOT NULL,
  `gin_entry_no` varchar(30) NOT NULL,
  `gin_entry_date` date NOT NULL,
  `gin_entry_production_section_id` int(11) NOT NULL,
  `gin_entry_from_godown_id` int(11) NOT NULL,
  `gin_entry_to_godown_id` int(11) NOT NULL,
  `gin_entry_type` int(11) NOT NULL,
  `gin_entry_production_order_id` int(11) NOT NULL,
  `gin_entry_status` int(11) NOT NULL DEFAULT '1',
  `gin_entry_company_id` int(11) NOT NULL,
  `gin_entry_branch_id` int(11) NOT NULL,
  `gin_entry_financial_year` int(11) NOT NULL,
  `gin_entry_added_by` int(11) NOT NULL,
  `gin_entry_added_on` int(11) NOT NULL,
  `gin_entry_added_ip` varchar(20) NOT NULL,
  `gin_entry_modified_by` int(11) NOT NULL,
  `gin_entry_modified_on` int(11) NOT NULL,
  `gin_entry_modified_ip` varchar(20) NOT NULL,
  `gin_entry_deleted_by` int(11) NOT NULL,
  `gin_entry_deleted_on` int(11) NOT NULL,
  `gin_entry_deleted_ip` varchar(20) NOT NULL,
  `gin_entry_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gin_entry`
--

INSERT INTO `gin_entry` (`gin_entry_id`, `gin_entry_uniq_id`, `gin_entry_no`, `gin_entry_date`, `gin_entry_production_section_id`, `gin_entry_from_godown_id`, `gin_entry_to_godown_id`, `gin_entry_type`, `gin_entry_production_order_id`, `gin_entry_status`, `gin_entry_company_id`, `gin_entry_branch_id`, `gin_entry_financial_year`, `gin_entry_added_by`, `gin_entry_added_on`, `gin_entry_added_ip`, `gin_entry_modified_by`, `gin_entry_modified_on`, `gin_entry_modified_ip`, `gin_entry_deleted_by`, `gin_entry_deleted_on`, `gin_entry_deleted_ip`, `gin_entry_deleted_status`) VALUES
(1, '1849d07nkd72e2zi83ccaec96e77ab090f6568f5', '00001', '2017-12-13', 4, 1, 3, 2, 2, 1, 1, 1, 1, 1, 1513161188, '103.197.196.27', 0, 0, '', 1, 1513161290, '103.197.196.27', 1),
(2, '97f9074fcf1852qghlte31f03b2d9717b6b059ac', '00001', '2017-12-13', 4, 1, 3, 2, 2, 1, 1, 1, 1, 1, 1513161537, '103.197.196.27', 0, 0, '', 0, 0, '', 0),
(3, '55270cbcj4d79d6gpk8654005d9b61123b87d702', '00002', '2017-12-14', 1, 1, 3, 2, 3, 1, 1, 1, 1, 1, 1513235377, '103.197.196.20', 0, 0, '', 0, 0, '', 0),
(4, 'cb10ff5gune038ndnm18441bd5ce9660ba2addb6', '00003', '2017-12-15', 1, 1, 3, 2, 14, 1, 1, 1, 1, 1, 1513332438, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(5, '826d294ifba291fb23900715c9a7888a3eef2af2', '00004', '2017-12-15', 1, 1, 3, 2, 16, 1, 1, 1, 1, 1, 1513333275, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(6, 'd64a22co6u7c45k4i33be3157ac9dcaa043768a9', '00005', '2017-12-15', 1, 1, 3, 1, 15, 1, 1, 1, 1, 1, 1513333444, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(7, '68e0e98i19c6e1fqz2ta0e6c31a5215e9e7a11e2', '00006', '2017-12-16', 2, 1, 3, 2, 17, 1, 1, 1, 1, 1, 1513391272, '203.81.163.238', 0, 0, '', 0, 0, '', 0),
(8, 'fb61a0dcsd6f947cmsjdb9f4d651dc169a61f552', '00007', '2017-12-16', 4, 1, 3, 2, 18, 1, 1, 1, 1, 1, 1513392910, '203.81.163.238', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `gin_entry_product_details`
--

CREATE TABLE `gin_entry_product_details` (
  `gin_entry_product_detail_id` int(11) NOT NULL,
  `gin_entry_product_detail_uniq_id` varchar(255) NOT NULL,
  `gin_entry_product_detail_gin_entry_id` int(11) NOT NULL,
  `gin_entry_product_detail_product_id` int(11) NOT NULL,
  `gin_entry_product_detail_width_feet` decimal(20,4) NOT NULL,
  `gin_entry_product_detail_width_inches` decimal(20,4) NOT NULL,
  `gin_entry_product_detail_width_mm` decimal(20,4) NOT NULL,
  `gin_entry_product_detail_width_meter` decimal(20,4) NOT NULL,
  `gin_entry_product_detail_length_feet` decimal(20,4) NOT NULL,
  `gin_entry_product_detail_length_inches` decimal(20,4) NOT NULL,
  `gin_entry_product_detail_length_mm` decimal(20,4) NOT NULL,
  `gin_entry_product_detail_length_meter` decimal(20,4) NOT NULL,
  `gin_entry_product_detail_ext_length_feet` decimal(20,4) NOT NULL,
  `gin_entry_product_detail_ext_length_meter` decimal(20,4) NOT NULL,
  `gin_entry_product_detail_qty` decimal(20,4) NOT NULL,
  `gin_entry_product_detail_type` int(11) NOT NULL,
  `gin_entry_product_detail_production_order_id` int(11) NOT NULL,
  `gin_entry_product_detail_production_order_detail_id` int(11) NOT NULL,
  `gin_entry_product_detail_company_id` int(11) NOT NULL,
  `gin_entry_product_detail_branch_id` int(11) NOT NULL,
  `gin_entry_product_detail_financial_year` varchar(20) NOT NULL,
  `gin_entry_product_detail_added_by` int(11) NOT NULL,
  `gin_entry_product_detail_added_on` int(11) NOT NULL,
  `gin_entry_product_detail_added_ip` varchar(20) NOT NULL,
  `gin_entry_product_detail_modified_by` int(11) NOT NULL,
  `gin_entry_product_detail_modified_on` int(11) NOT NULL,
  `gin_entry_product_detail_modified_ip` varchar(20) NOT NULL,
  `gin_entry_product_detail_deleted_by` int(11) NOT NULL,
  `gin_entry_product_detail_deleted_on` int(11) NOT NULL,
  `gin_entry_product_detail_deleted_ip` varchar(20) NOT NULL,
  `gin_entry_product_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gin_entry_product_details`
--

INSERT INTO `gin_entry_product_details` (`gin_entry_product_detail_id`, `gin_entry_product_detail_uniq_id`, `gin_entry_product_detail_gin_entry_id`, `gin_entry_product_detail_product_id`, `gin_entry_product_detail_width_feet`, `gin_entry_product_detail_width_inches`, `gin_entry_product_detail_width_mm`, `gin_entry_product_detail_width_meter`, `gin_entry_product_detail_length_feet`, `gin_entry_product_detail_length_inches`, `gin_entry_product_detail_length_mm`, `gin_entry_product_detail_length_meter`, `gin_entry_product_detail_ext_length_feet`, `gin_entry_product_detail_ext_length_meter`, `gin_entry_product_detail_qty`, `gin_entry_product_detail_type`, `gin_entry_product_detail_production_order_id`, `gin_entry_product_detail_production_order_detail_id`, `gin_entry_product_detail_company_id`, `gin_entry_product_detail_branch_id`, `gin_entry_product_detail_financial_year`, `gin_entry_product_detail_added_by`, `gin_entry_product_detail_added_on`, `gin_entry_product_detail_added_ip`, `gin_entry_product_detail_modified_by`, `gin_entry_product_detail_modified_on`, `gin_entry_product_detail_modified_ip`, `gin_entry_product_detail_deleted_by`, `gin_entry_product_detail_deleted_on`, `gin_entry_product_detail_deleted_ip`, `gin_entry_product_detail_deleted_status`) VALUES
(1, 'ca35a77szla32br1yzveeb9e1a9a414322bfc4fa', 1, 1, '36.0000', '432.0000', '10972.8000', '10.9728', '20.0000', '240.0000', '6096.0000', '6.0960', '0.0000', '0.0000', '1.0000', 2, 2, 2, 0, 0, '', 1, 1513161189, '103.197.196.27', 0, 0, '', 1, 1513161290, '103.197.196.27', 1),
(2, 'fa7c8b2p53b6fcdd0wgf66e0c04666a5a012613d', 2, 1, '36.0000', '432.0000', '10972.8000', '10.9728', '20.0000', '240.0000', '6096.0000', '6.0960', '0.0000', '0.0000', '1.0000', 2, 2, 2, 0, 0, '', 1, 1513161537, '103.197.196.27', 0, 0, '', 0, 0, '', 0),
(3, '7b6be9bt639bea9hs3u22073d170ae2706998662', 3, 5, '36.0000', '432.0000', '10972.8000', '10.9728', '200.0000', '2400.0000', '60960.0000', '60.9600', '0.2999', '0.0914', '10.0000', 1, 3, 3, 0, 0, '', 1, 1513235377, '103.197.196.20', 0, 0, '', 0, 0, '', 0),
(4, '1310c20lq851b3odbqs5287ae3154277beec6eef', 4, 4, '36.0000', '432.0000', '10972.8000', '10.9728', '10.0000', '120.0000', '3048.0000', '3.0480', '0.0000', '0.0000', '1.0000', 1, 14, 20, 0, 0, '', 1, 1513332438, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(5, 'd942f27ykrb06192e18936cfd61a853463fc4714', 5, 4, '300.0000', '3600.0000', '91440.0000', '91.4400', '100.0000', '1200.0000', '30480.0000', '30.4800', '0.2999', '0.0914', '10.0000', 1, 16, 22, 0, 0, '', 1, 1513333275, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(6, 'd70be3b5j07515jb5py678e78ae78eb0b1647af7', 6, 24, '3.0000', '36.0000', '914.4000', '0.9144', '10.0000', '120.0000', '3048.0000', '3.0480', '2.0000', '0.6096', '10.0000', 1, 15, 21, 0, 0, '', 1, 1513333444, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(7, '9334a001elb2a73l1b527647fad522ff98128d48', 7, 4, '3.0000', '36.0000', '914.4000', '0.9144', '10.0000', '120.0000', '3048.0000', '3.0480', '0.0000', '0.0000', '1.0000', 1, 17, 23, 0, 0, '', 1, 1513391272, '203.81.163.238', 0, 0, '', 0, 0, '', 0),
(8, '31d58c5hofbb226m4w45b718ff63c7e971e428e3', 8, 4, '3.0000', '36.0000', '914.4000', '0.9144', '10.0000', '120.0000', '3048.0000', '3.0480', '0.0000', '0.0000', '1.0000', 1, 18, 24, 0, 0, '', 1, 1513392910, '203.81.163.238', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `gin_entry_raw_product_details`
--

CREATE TABLE `gin_entry_raw_product_details` (
  `gin_entry_raw_product_detail_id` int(11) NOT NULL,
  `gin_entry_raw_product_detail_uniq_id` varchar(255) NOT NULL,
  `gin_entry_raw_product_detail_gin_entry_id` int(11) NOT NULL,
  `gin_entry_raw_product_detail_raw_product_id` int(11) NOT NULL,
  `gin_entry_raw_product_detail_product_id` int(11) NOT NULL,
  `gin_entry_raw_product_detail_width_feet` decimal(20,4) NOT NULL,
  `gin_entry_raw_product_detail_width_inches` decimal(20,4) NOT NULL,
  `gin_entry_raw_product_detail_width_mm` decimal(20,4) NOT NULL,
  `gin_entry_raw_product_detail_width_meter` decimal(20,4) NOT NULL,
  `gin_entry_raw_product_detail_length_feet` decimal(20,4) NOT NULL,
  `gin_entry_raw_product_detail_length_inches` decimal(20,4) NOT NULL,
  `gin_entry_raw_product_detail_length_mm` decimal(20,4) NOT NULL,
  `gin_entry_raw_product_detail_length_meter` decimal(20,4) NOT NULL,
  `gin_entry_raw_product_detail_ext_length_feet` decimal(20,4) NOT NULL,
  `gin_entry_raw_product_detail_ext_length_meter` decimal(20,4) NOT NULL,
  `gin_entry_raw_product_detail_qty` decimal(20,4) NOT NULL,
  `gin_entry_raw_product_detail_company_id` int(11) NOT NULL,
  `gin_entry_raw_product_detail_branch_id` int(11) NOT NULL,
  `gin_entry_raw_product_detail_financial_year` varchar(20) NOT NULL,
  `gin_entry_raw_product_detail_added_by` int(11) NOT NULL,
  `gin_entry_raw_product_detail_added_on` int(11) NOT NULL,
  `gin_entry_raw_product_detail_added_ip` varchar(20) NOT NULL,
  `gin_entry_raw_product_detail_modified_by` int(11) NOT NULL,
  `gin_entry_raw_product_detail_modified_on` int(11) NOT NULL,
  `gin_entry_raw_product_detail_modified_ip` varchar(20) NOT NULL,
  `gin_entry_raw_product_detail_deleted_by` int(11) NOT NULL,
  `gin_entry_raw_product_detail_deleted_on` int(11) NOT NULL,
  `gin_entry_raw_product_detail_deleted_ip` varchar(20) NOT NULL,
  `gin_entry_raw_product_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gin_entry_raw_product_details`
--

INSERT INTO `gin_entry_raw_product_details` (`gin_entry_raw_product_detail_id`, `gin_entry_raw_product_detail_uniq_id`, `gin_entry_raw_product_detail_gin_entry_id`, `gin_entry_raw_product_detail_raw_product_id`, `gin_entry_raw_product_detail_product_id`, `gin_entry_raw_product_detail_width_feet`, `gin_entry_raw_product_detail_width_inches`, `gin_entry_raw_product_detail_width_mm`, `gin_entry_raw_product_detail_width_meter`, `gin_entry_raw_product_detail_length_feet`, `gin_entry_raw_product_detail_length_inches`, `gin_entry_raw_product_detail_length_mm`, `gin_entry_raw_product_detail_length_meter`, `gin_entry_raw_product_detail_ext_length_feet`, `gin_entry_raw_product_detail_ext_length_meter`, `gin_entry_raw_product_detail_qty`, `gin_entry_raw_product_detail_company_id`, `gin_entry_raw_product_detail_branch_id`, `gin_entry_raw_product_detail_financial_year`, `gin_entry_raw_product_detail_added_by`, `gin_entry_raw_product_detail_added_on`, `gin_entry_raw_product_detail_added_ip`, `gin_entry_raw_product_detail_modified_by`, `gin_entry_raw_product_detail_modified_on`, `gin_entry_raw_product_detail_modified_ip`, `gin_entry_raw_product_detail_deleted_by`, `gin_entry_raw_product_detail_deleted_on`, `gin_entry_raw_product_detail_deleted_ip`, `gin_entry_raw_product_detail_deleted_status`) VALUES
(1, '2df2073v9d8c2936dgcccd1554873295bafd29a2', 1, 3, 1, '3.0000', '36.0000', '914.4000', '0.9144', '20.0000', '240.0000', '6096.0000', '6.0960', '0.0000', '0.0000', '1.0000', 0, 0, '', 1, 1513161189, '103.197.196.27', 0, 0, '', 0, 0, '', 0),
(2, 'bf620a1imm3a6fy6lp0affb2a5285d254d1dfc1b', 2, 2, 1, '3.0000', '36.0000', '914.4000', '0.9144', '20.0000', '240.0000', '6096.0000', '6.0960', '0.0000', '0.0000', '1.0000', 0, 0, '', 1, 1513161537, '103.197.196.27', 0, 0, '', 0, 0, '', 0),
(3, '4e120374ecdf614poe136953ab1e153bd6647235', 3, 4, 5, '36.0000', '432.0000', '10972.8000', '10.9728', '2100.0000', '25200.0000', '640080.0000', '640.0800', '0.0000', '0.0000', '1.0000', 0, 0, '', 1, 1513235377, '103.197.196.20', 0, 0, '', 0, 0, '', 0),
(4, '38cc0dbxmeffafrg1mda9414b4d2a6354eabddc4', 4, 11, 4, '3.0000', '36.0000', '914.4000', '0.9144', '10.0000', '120.0000', '3048.0000', '3.0480', '0.0000', '0.0000', '1.0000', 0, 0, '', 1, 1513332438, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(5, '59cede8d9e08b8ge9ti7af771001e2cc4814c4de', 5, 11, 4, '3.0000', '36.0000', '914.4000', '0.9144', '100.0000', '1200.0000', '30480.0000', '30.4800', '0.0000', '0.0000', '1.0000', 0, 0, '', 1, 1513333275, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(6, 'ee78ad8fhqd8cb9tzat91094257d71b4876dfafa', 6, 23, 24, '3.0000', '36.0000', '914.4000', '0.9144', '120.0000', '1440.0000', '36576.0000', '36.5760', '0.0000', '0.0000', '1.0000', 0, 0, '', 1, 1513333444, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(7, '9d6bfb5nlqcfeblgdfw6dcc533e5dfe67e163fd3', 7, 11, 4, '3.0000', '36.0000', '914.4000', '0.9144', '10.0000', '120.0000', '3048.0000', '3.0480', '0.0000', '0.0000', '1.0000', 0, 0, '', 1, 1513391272, '203.81.163.238', 0, 0, '', 0, 0, '', 0),
(8, '427f8328o483618rfqw897f54dab1a8859025ff2', 8, 11, 4, '3.0000', '36.0000', '914.4000', '0.9144', '10.0000', '120.0000', '3048.0000', '3.0480', '0.0000', '0.0000', '1.0000', 0, 0, '', 1, 1513392910, '203.81.163.238', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `godowns`
--

CREATE TABLE `godowns` (
  `godown_id` int(11) NOT NULL,
  `godown_uniq_id` varchar(100) NOT NULL,
  `godown_code` varchar(10) NOT NULL,
  `godown_name` varchar(80) NOT NULL,
  `godown_company_name` varchar(100) NOT NULL,
  `godown_address` text NOT NULL,
  `godown_country_id` int(11) NOT NULL,
  `godown_state_id` int(11) NOT NULL,
  `godown_city_id` int(11) NOT NULL,
  `godown_email` varchar(40) NOT NULL,
  `godown_zip_code` varchar(40) NOT NULL,
  `godown_fax_no` varchar(40) NOT NULL,
  `godown_company_id` int(11) NOT NULL,
  `godown_added_by` int(11) NOT NULL,
  `godown_added_on` int(11) NOT NULL,
  `godown_added_ip` varchar(20) NOT NULL,
  `godown_modified_by` int(11) NOT NULL,
  `godown_modified_on` int(11) NOT NULL,
  `godown_modified_ip` varchar(20) NOT NULL,
  `godown_deleted_by` int(11) NOT NULL,
  `godown_deleted_on` int(11) NOT NULL,
  `godown_deleted_ip` varchar(20) NOT NULL,
  `godown_active_status` varchar(20) NOT NULL DEFAULT 'active',
  `godown_deleted_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `godowns`
--

INSERT INTO `godowns` (`godown_id`, `godown_uniq_id`, `godown_code`, `godown_name`, `godown_company_name`, `godown_address`, `godown_country_id`, `godown_state_id`, `godown_city_id`, `godown_email`, `godown_zip_code`, `godown_fax_no`, `godown_company_id`, `godown_added_by`, `godown_added_on`, `godown_added_ip`, `godown_modified_by`, `godown_modified_on`, `godown_modified_ip`, `godown_deleted_by`, `godown_deleted_on`, `godown_deleted_ip`, `godown_active_status`, `godown_deleted_status`) VALUES
(1, '0b4fe5blbuccfedh6q1ab3569ccf350977ce2f0f', 'GD000001', 'Main Warehouse', '', 'Yangon', 1, 1, 6, '', '', '', 0, 1, 1504507015, '0', 0, 0, '', 0, 0, '', 'active', 0),
(2, 'asda123123', 'GD000002', 'Sales Warehouse', '', 'dsdf', 1, 1, 2, '', '', '', 0, 1, 0, '', 0, 0, '', 0, 0, '', 'active', 0),
(3, '05ecc2e7ns2c929sojid6c9da5dffd1a60e87c4c', 'GD000003', 'Manufacture Warehouse', '', 'Yangon', 1, 1, 0, '', '', '', 1, 1, 1510392748, '103', 0, 0, '', 0, 0, '', 'active', 0),
(4, 'ee3e1d6iz6d6601e1wwd3b7ea5e8db740ddcd123', 'GD000004', 'Test Warehouse', '', 'Yangon', 1, 1, 6, 'testwarehouse@gmail.com', '', '', 1, 1, 1512715087, '103', 0, 0, '', 0, 0, '', 'active', 0),
(5, 'd6adfad76qb5d58cnmg241a9f28169a33f95ce26', 'GD000005', 'test1', '', 'amlm', 1, 8, 11, '', '', '', 1, 1, 1513747007, '103', 0, 0, '', 0, 0, '', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `godown_multi_contacts`
--

CREATE TABLE `godown_multi_contacts` (
  `godown_multi_contact_id` int(11) NOT NULL,
  `godown_multi_contact_godown_id` int(11) NOT NULL,
  `godown_multi_contact_title` varchar(80) NOT NULL,
  `godown_multi_contact_name` varchar(80) NOT NULL,
  `godown_multi_contact_department` varchar(80) NOT NULL,
  `godown_multi_contact_mobile_no` varchar(40) NOT NULL,
  `godown_multi_contact_email` varchar(80) NOT NULL,
  `godown_multi_contact_extn_no` int(5) NOT NULL,
  `godown_multi_contact_added_by` int(11) NOT NULL,
  `godown_multi_contact_added_on` int(11) NOT NULL,
  `godown_multi_contact_added_ip` varchar(20) NOT NULL,
  `godown_multi_contact_modified_by` int(11) NOT NULL,
  `godown_multi_contact_modified_on` int(11) NOT NULL,
  `godown_multi_contact_modified_ip` varchar(20) NOT NULL,
  `godown_multi_contact_deleted_by` int(11) NOT NULL,
  `godown_multi_contact_deleted_on` int(11) NOT NULL,
  `godown_multi_contact_deleted_ip` int(20) NOT NULL,
  `godown_multi_contact_deleted_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `grn_child_product_details`
--

CREATE TABLE `grn_child_product_details` (
  `grn_child_product_detail_id` int(11) NOT NULL,
  `grn_child_product_detail_uniq_id` varchar(255) NOT NULL,
  `grn_child_product_detail_grn_id` int(11) NOT NULL,
  `grn_child_product_detail_inv_detail_id` int(11) NOT NULL,
  `grn_child_product_detail_product_id` int(11) NOT NULL,
  `grn_child_product_detail_code` varchar(255) NOT NULL,
  `grn_child_product_detail_name` varchar(255) NOT NULL,
  `grn_child_product_detail_color_id` int(11) NOT NULL,
  `grn_child_product_detail_thick_ness` int(11) NOT NULL,
  `grn_child_product_detail_width_inches` decimal(20,4) NOT NULL,
  `grn_child_product_detail_width_mm` decimal(20,4) NOT NULL,
  `grn_child_product_detail_length_mm` decimal(20,4) NOT NULL,
  `grn_child_product_detail_length_feet` decimal(20,4) NOT NULL,
  `grn_child_product_detail_ton_qty` decimal(12,2) NOT NULL,
  `grn_child_product_detail_kg_qty` decimal(12,2) NOT NULL,
  `grn_child_product_detail_uom_id` int(11) NOT NULL,
  `grn_child_product_detail_type` int(11) NOT NULL DEFAULT '1',
  `grn_child_product_detail_company_id` int(11) NOT NULL,
  `grn_child_product_detail_branch_id` int(11) NOT NULL,
  `grn_child_product_detail_financial_year` varchar(20) NOT NULL,
  `grn_child_product_detail_added_by` int(11) NOT NULL,
  `grn_child_product_detail_added_on` int(11) NOT NULL,
  `grn_child_product_detail_added_ip` varchar(20) NOT NULL,
  `grn_child_product_detail_modified_by` int(11) NOT NULL,
  `grn_child_product_detail_modified_on` int(11) NOT NULL,
  `grn_child_product_detail_modified_ip` varchar(20) NOT NULL,
  `grn_child_product_detail_deleted_by` int(11) NOT NULL,
  `grn_child_product_detail_deleted_on` int(11) NOT NULL,
  `grn_child_product_detail_deleted_ip` varchar(20) NOT NULL,
  `grn_child_product_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `grn_child_product_details`
--

INSERT INTO `grn_child_product_details` (`grn_child_product_detail_id`, `grn_child_product_detail_uniq_id`, `grn_child_product_detail_grn_id`, `grn_child_product_detail_inv_detail_id`, `grn_child_product_detail_product_id`, `grn_child_product_detail_code`, `grn_child_product_detail_name`, `grn_child_product_detail_color_id`, `grn_child_product_detail_thick_ness`, `grn_child_product_detail_width_inches`, `grn_child_product_detail_width_mm`, `grn_child_product_detail_length_mm`, `grn_child_product_detail_length_feet`, `grn_child_product_detail_ton_qty`, `grn_child_product_detail_kg_qty`, `grn_child_product_detail_uom_id`, `grn_child_product_detail_type`, `grn_child_product_detail_company_id`, `grn_child_product_detail_branch_id`, `grn_child_product_detail_financial_year`, `grn_child_product_detail_added_by`, `grn_child_product_detail_added_on`, `grn_child_product_detail_added_ip`, `grn_child_product_detail_modified_by`, `grn_child_product_detail_modified_on`, `grn_child_product_detail_modified_ip`, `grn_child_product_detail_deleted_by`, `grn_child_product_detail_deleted_on`, `grn_child_product_detail_deleted_ip`, `grn_child_product_detail_deleted_status`) VALUES
(1, 'ea0f4365br0034g0251a8d5a61738807d3b70b3b', 1, 7, 2, 'CH00001', 'PPGI 1', 6, 1, '36.0000', '914.4000', '304800.0000', '1000.0000', '1500.00', '0.00', 3, 1, 1, 4, '1', 1, 1515041573, '103.197.196.14', 0, 0, '', 0, 0, '', 0),
(2, '830426fdt9e70a817xfbf85b86b7ce530429920f', 1, 8, 2, 'CH00002', 'PPGI 1', 6, 2, '48.0000', '1219.2000', '304800.0000', '1000.0000', '500.00', '0.00', 3, 1, 1, 4, '1', 1, 1515041573, '103.197.196.14', 0, 0, '', 0, 0, '', 0),
(3, '7a83ca6n8r776f4yf9od0a94c0bc9e096b0d82a1', 1, 9, 2, 'CH00001', 'Raw GI', 0, 2, '36.0000', '914.4000', '457200.0000', '1500.0000', '1500.00', '0.00', 3, 1, 1, 4, '1', 1, 1515041573, '103.197.196.14', 0, 0, '', 0, 0, '', 0),
(4, 'aaf754dvrf9215mgtgmf0ec6ce4ea1cbe897bd61', 1, 10, 2, 'CH00002', 'Raw GI', 0, 1, '54.0000', '1371.6000', '457200.0000', '1500.0000', '1500.00', '0.00', 3, 1, 1, 4, '1', 1, 1515041573, '103.197.196.14', 0, 0, '', 0, 0, '', 0),
(5, 'd803584orw51a8d7ri91db26243906dc39936358', 2, 11, 5, 'CH00001', 'GIPP Coin 1', 5, 2, '45.0000', '1143.0000', '1524000.0000', '5000.0000', '5000.00', '0.00', 3, 1, 1, 4, '1', 1, 1515047749, '103.197.196.14', 0, 0, '', 0, 0, '', 0),
(6, '908c7c6n4md7ccrcs4tee411371c3b3b03aa8206', 2, 12, 5, 'CH00002', 'GIPP Coin 1', 5, 3, '36.0000', '914.4000', '1524000.0000', '5000.0000', '5000.00', '0.00', 3, 1, 1, 4, '1', 1, 1515047749, '103.197.196.14', 0, 0, '', 0, 0, '', 0),
(7, '7f84826cxffa08k7t6cc3d4cae51b8c970709796', 3, 13, 6, 'CH00001', 'PPGI 1', 6, 1, '36.0000', '914.4000', '152400.0000', '500.0000', '500.00', '0.00', 3, 1, 1, 4, '1', 1, 1515126668, '103.197.196.24', 0, 0, '', 0, 0, '', 0),
(8, '40df0aax2cf060v10zsb4305485be000e26187a7', 3, 14, 6, 'CH00002', 'PPGI 1', 5, 2, '36.0000', '914.4000', '152400.0000', '500.0000', '500.00', '0.00', 3, 1, 1, 4, '1', 1, 1515126668, '103.197.196.24', 0, 0, '', 0, 0, '', 0),
(9, '31a2d740ao76e0lvgfl3d80648f6fef6622a237b', 3, 15, 6, 'CH00001', 'GI_Test_02', 0, 3, '45.0000', '1143.0000', '152400.0000', '500.0000', '500.00', '0.00', 3, 1, 1, 4, '1', 1, 1515126668, '103.197.196.24', 0, 0, '', 0, 0, '', 0),
(10, '880c133upke583vv558921a8b71d2e250f0f92d1', 3, 16, 6, 'CH00002', 'GI_Test_02', 0, 3, '54.0000', '1371.6000', '152400.0000', '500.0000', '500.00', '0.00', 3, 1, 1, 4, '1', 1, 1515126668, '103.197.196.24', 0, 0, '', 0, 0, '', 0),
(11, '88d97d92ks6ce8adymb788e4c8b7ec62a737d4ee', 3, 17, 6, 'CH00001', 'Other Mother Coin', 5, 2, '36.0000', '914.4000', '304800.0000', '1000.0000', '1000.00', '0.00', 3, 1, 1, 4, '1', 1, 1515126668, '103.197.196.24', 0, 0, '', 0, 0, '', 0),
(12, '9c58ec50z6557f1z6u038b24200a07c238df53a4', 3, 18, 6, 'CH00002', 'Other Mother Coin', 5, 2, '36.0000', '914.4000', '304800.0000', '1000.0000', '1000.00', '0.00', 3, 1, 1, 4, '1', 1, 1515126668, '103.197.196.24', 0, 0, '', 0, 0, '', 0),
(13, 'b03b29f6g955f5lv9zh71e62f813348e4074a828', 5, 19, 10, 'CH00001', 'LT', 2, 1, '36.0000', '914.4000', '30480.0000', '100.0000', '35.00', '5250.00', 3, 1, 1, 1, '1', 1, 1515129085, '103.197.196.24', 0, 0, '', 0, 0, '', 0),
(14, 'b50212a22d4619brnqece13149de1307e3c0164e', 5, 20, 10, 'CH00002', 'LT', 5, 1, '36.0000', '914.4000', '30480.0000', '100.0000', '35.00', '5250.00', 3, 1, 1, 1, '1', 1, 1515129086, '103.197.196.24', 0, 0, '', 0, 0, '', 0),
(15, 'c01fcf7w1u18af83odv191d7c12df85f17a088e8', 5, 21, 10, 'CH00003', 'LT', 1, 1, '36.0000', '914.4000', '27432.0000', '90.0000', '30.00', '4500.00', 3, 1, 1, 1, '1', 1, 1515129086, '103.197.196.24', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `grn_details`
--

CREATE TABLE `grn_details` (
  `grnId` int(11) NOT NULL,
  `grn_branchid` int(11) NOT NULL,
  `grn_purchaseId` int(11) NOT NULL,
  `grn_warehouseid` int(11) NOT NULL,
  `grn_grn_type` varchar(20) NOT NULL,
  `grn_date` date NOT NULL,
  `grn_remarks` text NOT NULL,
  `grn_company_id` int(11) NOT NULL,
  `grn_added_by` int(11) NOT NULL,
  `grn_added_on` datetime NOT NULL,
  `grn_added_ip` varchar(20) NOT NULL,
  `grn_modified_by` int(11) NOT NULL,
  `grn_modified_on` datetime NOT NULL,
  `grn_modified_ip` varchar(20) NOT NULL,
  `grn_deleted_by` int(11) NOT NULL,
  `grn_deleted_on` datetime NOT NULL,
  `grn_deleted_ip` varchar(20) NOT NULL,
  `grn_deleted_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `grn_details`
--

INSERT INTO `grn_details` (`grnId`, `grn_branchid`, `grn_purchaseId`, `grn_warehouseid`, `grn_grn_type`, `grn_date`, `grn_remarks`, `grn_company_id`, `grn_added_by`, `grn_added_on`, `grn_added_ip`, `grn_modified_by`, `grn_modified_on`, `grn_modified_ip`, `grn_deleted_by`, `grn_deleted_on`, `grn_deleted_ip`, `grn_deleted_status`) VALUES
(1, 4, 3, 1, '', '2018-01-04', '', 1, 1, '2018-01-04 10:22:53', '103.197.196.14', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(2, 4, 5, 1, '', '2018-01-04', '', 1, 1, '2018-01-04 12:05:49', '103.197.196.14', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(3, 4, 6, 1, '', '2018-01-05', '', 1, 1, '2018-01-05 10:01:08', '103.197.196.24', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(4, 4, 7, 1, '', '2018-01-05', '', 1, 1, '2018-01-05 10:11:53', '103.197.196.24', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(5, 1, 8, 1, '', '2018-01-05', '', 1, 1, '2018-01-05 10:41:25', '103.197.196.24', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `grn_details_products`
--

CREATE TABLE `grn_details_products` (
  `grnProdId` int(11) NOT NULL,
  `grnP_grnId` int(11) NOT NULL,
  `grnP_product_id` int(11) NOT NULL,
  `grnP_po_id` int(11) NOT NULL,
  `grnP_podetail_id` int(11) NOT NULL,
  `grnP_poqty` int(11) NOT NULL,
  `grnP_received_earlier` int(11) NOT NULL,
  `grnP_curnt_supply` int(11) NOT NULL,
  `grnP_reject` int(11) NOT NULL,
  `grnP_accept` int(11) NOT NULL,
  `grnP_pending` int(11) NOT NULL,
  `grnP_deleted_by` int(11) NOT NULL,
  `grnP_deleted_on` int(11) NOT NULL,
  `grnP_deleted_ip` varchar(20) NOT NULL,
  `grnP_deleted_status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `grn_details_products`
--

INSERT INTO `grn_details_products` (`grnProdId`, `grnP_grnId`, `grnP_product_id`, `grnP_po_id`, `grnP_podetail_id`, `grnP_poqty`, `grnP_received_earlier`, `grnP_curnt_supply`, `grnP_reject`, `grnP_accept`, `grnP_pending`, `grnP_deleted_by`, `grnP_deleted_on`, `grnP_deleted_ip`, `grnP_deleted_status`) VALUES
(1, 4, 26, 7, 9, 100, 0, 100, 0, 100, 0, 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `grn_entry`
--

CREATE TABLE `grn_entry` (
  `grn_entry_id` int(11) NOT NULL,
  `grn_entry_uniq_id` varchar(255) NOT NULL,
  `grn_entry_no` varchar(30) NOT NULL,
  `grn_entry_date` date NOT NULL,
  `grn_entry_production_section_id` int(11) NOT NULL,
  `grn_entry_from_godown_id` int(11) NOT NULL,
  `grn_entry_to_godown_id` int(11) NOT NULL,
  `grn_entry_type` int(11) NOT NULL,
  `grn_entry_gin_entry_id` int(11) NOT NULL,
  `grn_entry_status` int(11) NOT NULL DEFAULT '1',
  `grn_entry_company_id` int(11) NOT NULL,
  `grn_entry_branch_id` int(11) NOT NULL,
  `grn_entry_financial_year` int(11) NOT NULL,
  `grn_entry_added_by` int(11) NOT NULL,
  `grn_entry_added_on` int(11) NOT NULL,
  `grn_entry_added_ip` varchar(20) NOT NULL,
  `grn_entry_modified_by` int(11) NOT NULL,
  `grn_entry_modified_on` int(11) NOT NULL,
  `grn_entry_modified_ip` varchar(20) NOT NULL,
  `grn_entry_deleted_by` int(11) NOT NULL,
  `grn_entry_deleted_on` int(11) NOT NULL,
  `grn_entry_deleted_ip` varchar(20) NOT NULL,
  `grn_entry_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `grn_entry`
--

INSERT INTO `grn_entry` (`grn_entry_id`, `grn_entry_uniq_id`, `grn_entry_no`, `grn_entry_date`, `grn_entry_production_section_id`, `grn_entry_from_godown_id`, `grn_entry_to_godown_id`, `grn_entry_type`, `grn_entry_gin_entry_id`, `grn_entry_status`, `grn_entry_company_id`, `grn_entry_branch_id`, `grn_entry_financial_year`, `grn_entry_added_by`, `grn_entry_added_on`, `grn_entry_added_ip`, `grn_entry_modified_by`, `grn_entry_modified_on`, `grn_entry_modified_ip`, `grn_entry_deleted_by`, `grn_entry_deleted_on`, `grn_entry_deleted_ip`, `grn_entry_deleted_status`) VALUES
(1, '8e7e867lq311578op5gdf0db481f950f02b49963', '00001', '2017-12-13', 4, 1, 3, 2, 2, 1, 1, 1, 1, 1, 1513161787, '103.197.196.27', 0, 0, '', 0, 0, '', 0),
(2, 'a8f3fb2p1zdd454tldvb681ad48630dd105e8406', '00002', '2017-12-14', 1, 1, 3, 2, 3, 1, 1, 1, 1, 1, 1513235453, '103.197.196.20', 0, 0, '', 0, 0, '', 0),
(3, '3a78aeepgh5992xlact013c932567c33f19a844b', '00003', '2017-12-15', 1, 1, 3, 2, 4, 1, 1, 1, 1, 1, 1513332476, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(4, '7de7b3bgf64710r94ncccf37589cbac8b7d1d980', '00004', '2017-12-15', 1, 1, 3, 2, 5, 1, 1, 1, 1, 1, 1513333334, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(5, 'd25c80dnqn4d00tosqhaec86c7e73419d68b8d26', '00005', '2017-12-15', 1, 1, 3, 1, 6, 1, 1, 1, 1, 1, 1513333573, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(6, 'adf765e28k3f0a1sak6d0c7eb863a469a7282930', '00006', '2017-12-16', 2, 1, 3, 1, 7, 1, 1, 1, 1, 1, 1513391361, '203.81.163.238', 0, 0, '', 0, 0, '', 0),
(7, '41feef60acf61be04in04d564673cfa012dcf7a5', '00007', '2017-12-16', 4, 1, 3, 2, 8, 1, 1, 1, 1, 1, 1513392946, '203.81.163.238', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `grn_entry_product_details`
--

CREATE TABLE `grn_entry_product_details` (
  `grn_entry_product_detail_id` int(11) NOT NULL,
  `grn_entry_product_detail_uniq_id` varchar(255) NOT NULL,
  `grn_entry_product_detail_grn_entry_id` int(11) NOT NULL,
  `grn_entry_product_detail_product_id` int(11) NOT NULL,
  `grn_entry_product_detail_width_feet` decimal(20,4) NOT NULL,
  `grn_entry_product_detail_width_inches` decimal(20,4) NOT NULL,
  `grn_entry_product_detail_width_mm` decimal(20,4) NOT NULL,
  `grn_entry_product_detail_width_meter` decimal(20,4) NOT NULL,
  `grn_entry_product_detail_length_feet` decimal(20,4) NOT NULL,
  `grn_entry_product_detail_length_inches` decimal(20,4) NOT NULL,
  `grn_entry_product_detail_length_mm` decimal(20,4) NOT NULL,
  `grn_entry_product_detail_length_meter` decimal(20,4) NOT NULL,
  `grn_entry_product_detail_ext_length_feet` decimal(20,4) NOT NULL,
  `grn_entry_product_detail_ext_length_meter` decimal(20,4) NOT NULL,
  `grn_entry_product_detail_qty` decimal(20,4) NOT NULL,
  `grn_entry_product_detail_type` int(11) NOT NULL,
  `grn_entry_product_detail_gin_entry_id` int(11) NOT NULL,
  `grn_entry_product_detail_gin_entry_detail_id` int(11) NOT NULL,
  `grn_entry_product_detail_company_id` int(11) NOT NULL,
  `grn_entry_product_detail_branch_id` int(11) NOT NULL,
  `grn_entry_product_detail_financial_year` varchar(20) NOT NULL,
  `grn_entry_product_detail_added_by` int(11) NOT NULL,
  `grn_entry_product_detail_added_on` int(11) NOT NULL,
  `grn_entry_product_detail_added_ip` varchar(20) NOT NULL,
  `grn_entry_product_detail_modified_by` int(11) NOT NULL,
  `grn_entry_product_detail_modified_on` int(11) NOT NULL,
  `grn_entry_product_detail_modified_ip` varchar(20) NOT NULL,
  `grn_entry_product_detail_deleted_by` int(11) NOT NULL,
  `grn_entry_product_detail_deleted_on` int(11) NOT NULL,
  `grn_entry_product_detail_deleted_ip` varchar(20) NOT NULL,
  `grn_entry_product_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `grn_entry_product_details`
--

INSERT INTO `grn_entry_product_details` (`grn_entry_product_detail_id`, `grn_entry_product_detail_uniq_id`, `grn_entry_product_detail_grn_entry_id`, `grn_entry_product_detail_product_id`, `grn_entry_product_detail_width_feet`, `grn_entry_product_detail_width_inches`, `grn_entry_product_detail_width_mm`, `grn_entry_product_detail_width_meter`, `grn_entry_product_detail_length_feet`, `grn_entry_product_detail_length_inches`, `grn_entry_product_detail_length_mm`, `grn_entry_product_detail_length_meter`, `grn_entry_product_detail_ext_length_feet`, `grn_entry_product_detail_ext_length_meter`, `grn_entry_product_detail_qty`, `grn_entry_product_detail_type`, `grn_entry_product_detail_gin_entry_id`, `grn_entry_product_detail_gin_entry_detail_id`, `grn_entry_product_detail_company_id`, `grn_entry_product_detail_branch_id`, `grn_entry_product_detail_financial_year`, `grn_entry_product_detail_added_by`, `grn_entry_product_detail_added_on`, `grn_entry_product_detail_added_ip`, `grn_entry_product_detail_modified_by`, `grn_entry_product_detail_modified_on`, `grn_entry_product_detail_modified_ip`, `grn_entry_product_detail_deleted_by`, `grn_entry_product_detail_deleted_on`, `grn_entry_product_detail_deleted_ip`, `grn_entry_product_detail_deleted_status`) VALUES
(1, '36bd6950wa5ee1gizvc32d7f5e7eca38d7477b59', 1, 1, '36.0000', '432.0000', '10972.8000', '10.9728', '20.0000', '240.0000', '6096.0000', '6.0960', '0.0000', '0.0000', '1.0000', 2, 2, 2, 0, 0, '', 1, 1513161787, '103.197.196.27', 0, 0, '', 0, 0, '', 0),
(2, '03b74ceujwe576jankx9d2a5d007a0c41b0d2a48', 2, 5, '36.0000', '432.0000', '10972.8000', '10.9728', '200.0000', '2400.0000', '60960.0000', '60.9600', '0.2999', '0.0914', '10.0000', 1, 3, 3, 0, 0, '', 1, 1513235453, '103.197.196.20', 0, 0, '', 0, 0, '', 0),
(3, '7b84279nx415770t1go1d6fa1b6cb226dc949b3b', 3, 4, '36.0000', '432.0000', '10972.8000', '10.9728', '10.0000', '120.0000', '3048.0000', '3.0480', '0.0000', '0.0000', '1.0000', 1, 4, 4, 0, 0, '', 1, 1513332476, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(4, 'a830756j28f157aq7t7f893f77dd198a5ae38d74', 4, 4, '300.0000', '3600.0000', '91440.0000', '91.4400', '100.0000', '1200.0000', '30480.0000', '30.4800', '0.2999', '0.0914', '10.0000', 1, 5, 5, 0, 0, '', 1, 1513333334, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(5, 'a634eectl61ea1y49qac749b7ec9b071bf446350', 5, 24, '3.0000', '36.0000', '914.4000', '0.9144', '10.0000', '120.0000', '3048.0000', '3.0480', '2.0000', '0.6096', '10.0000', 1, 6, 6, 0, 0, '', 1, 1513333573, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(6, '79510605myaef9sz3gkd59cfaf110e68ba34e611', 6, 4, '3.0000', '36.0000', '914.4000', '0.9144', '10.0000', '120.0000', '3048.0000', '3.0480', '0.0000', '0.0000', '1.0000', 1, 7, 7, 0, 0, '', 1, 1513391361, '203.81.163.238', 0, 0, '', 0, 0, '', 0),
(7, 'd38da14o00724aipcg2f066e6a9e9f6756ee59c1', 7, 4, '3.0000', '36.0000', '914.4000', '0.9144', '10.0000', '120.0000', '3048.0000', '3.0480', '0.0000', '0.0000', '1.0000', 1, 8, 8, 0, 0, '', 1, 1513392946, '203.81.163.238', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `grn_entry_raw_product_details`
--

CREATE TABLE `grn_entry_raw_product_details` (
  `grn_entry_raw_product_detail_id` int(11) NOT NULL,
  `grn_entry_raw_product_detail_uniq_id` varchar(255) NOT NULL,
  `grn_entry_raw_product_detail_grn_entry_id` int(11) NOT NULL,
  `grn_entry_raw_product_detail_raw_product_id` int(11) NOT NULL,
  `grn_entry_raw_product_detail_product_id` int(11) NOT NULL,
  `grn_entry_raw_product_detail_width_feet` decimal(20,4) NOT NULL,
  `grn_entry_raw_product_detail_width_inches` decimal(20,4) NOT NULL,
  `grn_entry_raw_product_detail_width_mm` decimal(20,4) NOT NULL,
  `grn_entry_raw_product_detail_width_meter` decimal(20,4) NOT NULL,
  `grn_entry_raw_product_detail_length_feet` decimal(20,4) NOT NULL,
  `grn_entry_raw_product_detail_length_inches` decimal(20,4) NOT NULL,
  `grn_entry_raw_product_detail_length_mm` decimal(20,4) NOT NULL,
  `grn_entry_raw_product_detail_length_meter` decimal(20,4) NOT NULL,
  `grn_entry_raw_product_detail_ext_length_feet` decimal(20,4) NOT NULL,
  `grn_entry_raw_product_detail_ext_length_meter` decimal(20,4) NOT NULL,
  `grn_entry_raw_product_detail_qty` decimal(20,4) NOT NULL,
  `grn_entry_product_detail_gin_entry_id` int(11) NOT NULL,
  `grn_entry_product_detail_gin_entry_raw_detail_id` int(11) NOT NULL,
  `grn_entry_raw_product_detail_company_id` int(11) NOT NULL,
  `grn_entry_raw_product_detail_branch_id` int(11) NOT NULL,
  `grn_entry_raw_product_detail_financial_year` varchar(20) NOT NULL,
  `grn_entry_raw_product_detail_added_by` int(11) NOT NULL,
  `grn_entry_raw_product_detail_added_on` int(11) NOT NULL,
  `grn_entry_raw_product_detail_added_ip` varchar(20) NOT NULL,
  `grn_entry_raw_product_detail_modified_by` int(11) NOT NULL,
  `grn_entry_raw_product_detail_modified_on` int(11) NOT NULL,
  `grn_entry_raw_product_detail_modified_ip` varchar(20) NOT NULL,
  `grn_entry_raw_product_detail_deleted_by` int(11) NOT NULL,
  `grn_entry_raw_product_detail_deleted_on` int(11) NOT NULL,
  `grn_entry_raw_product_detail_deleted_ip` varchar(20) NOT NULL,
  `grn_entry_raw_product_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `grn_entry_raw_product_details`
--

INSERT INTO `grn_entry_raw_product_details` (`grn_entry_raw_product_detail_id`, `grn_entry_raw_product_detail_uniq_id`, `grn_entry_raw_product_detail_grn_entry_id`, `grn_entry_raw_product_detail_raw_product_id`, `grn_entry_raw_product_detail_product_id`, `grn_entry_raw_product_detail_width_feet`, `grn_entry_raw_product_detail_width_inches`, `grn_entry_raw_product_detail_width_mm`, `grn_entry_raw_product_detail_width_meter`, `grn_entry_raw_product_detail_length_feet`, `grn_entry_raw_product_detail_length_inches`, `grn_entry_raw_product_detail_length_mm`, `grn_entry_raw_product_detail_length_meter`, `grn_entry_raw_product_detail_ext_length_feet`, `grn_entry_raw_product_detail_ext_length_meter`, `grn_entry_raw_product_detail_qty`, `grn_entry_product_detail_gin_entry_id`, `grn_entry_product_detail_gin_entry_raw_detail_id`, `grn_entry_raw_product_detail_company_id`, `grn_entry_raw_product_detail_branch_id`, `grn_entry_raw_product_detail_financial_year`, `grn_entry_raw_product_detail_added_by`, `grn_entry_raw_product_detail_added_on`, `grn_entry_raw_product_detail_added_ip`, `grn_entry_raw_product_detail_modified_by`, `grn_entry_raw_product_detail_modified_on`, `grn_entry_raw_product_detail_modified_ip`, `grn_entry_raw_product_detail_deleted_by`, `grn_entry_raw_product_detail_deleted_on`, `grn_entry_raw_product_detail_deleted_ip`, `grn_entry_raw_product_detail_deleted_status`) VALUES
(1, 'dd855d1pr79bfap5rrke334ad4edf3f665569e04', 1, 2, 1, '3.0000', '36.0000', '914.4000', '0.9144', '20.0000', '240.0000', '6096.0000', '0.0000', '0.0000', '0.0000', '1.0000', 2, 2, 0, 0, '', 1, 1513161787, '103.197.196.27', 0, 0, '', 0, 0, '', 0),
(2, '706e54bseqb9fekk2maf32a874bc30901c150207', 2, 4, 5, '36.0000', '432.0000', '10972.8000', '10.9728', '2100.0000', '25200.0000', '640080.0000', '640.0800', '0.0000', '0.0000', '1.0000', 3, 3, 0, 0, '', 1, 1513235453, '103.197.196.20', 0, 0, '', 0, 0, '', 0),
(3, '95c1a37ao34693b1k2b0d5664cebe696918b19a7', 3, 11, 4, '3.0000', '36.0000', '914.4000', '0.9144', '10.0000', '120.0000', '3048.0000', '0.0000', '0.0000', '0.0000', '1.0000', 4, 4, 0, 0, '', 1, 1513332476, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(4, '6a1745a8cece6d0gnv952a2ce7de02a27e3602e9', 4, 11, 4, '3.0000', '36.0000', '914.4000', '0.9144', '100.0000', '1200.0000', '30480.0000', '0.0000', '0.0000', '0.0000', '1.0000', 5, 5, 0, 0, '', 1, 1513333334, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(5, 'de17d08ooi4283t7icy610441c452e6ee4a79f6f', 5, 23, 24, '3.0000', '36.0000', '914.4000', '0.9144', '120.0000', '1440.0000', '36576.0000', '0.0000', '0.0000', '0.0000', '1.0000', 6, 6, 0, 0, '', 1, 1513333573, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(6, 'b66f7ddlxxc2b1gsulzadec3d44a3da2c73db56a', 6, 11, 4, '3.0000', '36.0000', '914.4000', '0.9144', '10.0000', '120.0000', '3048.0000', '0.0000', '0.0000', '0.0000', '1.0000', 7, 7, 0, 0, '', 1, 1513391361, '203.81.163.238', 0, 0, '', 0, 0, '', 0),
(7, '7375119cmse633ab4wd123d4df4d662296104ed1', 7, 11, 4, '3.0000', '36.0000', '914.4000', '0.9144', '10.0000', '120.0000', '3048.0000', '0.0000', '0.0000', '0.0000', '1.0000', 8, 8, 0, 0, '', 1, 1513392946, '203.81.163.238', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `invoice_entry`
--

CREATE TABLE `invoice_entry` (
  `invoice_entry_id` int(11) NOT NULL,
  `invoice_entry_uniq_id` varchar(255) NOT NULL,
  `invoice_entry_no` varchar(30) NOT NULL,
  `invoice_entry_date` date NOT NULL,
  `invoice_entry_customer_id` int(11) NOT NULL,
  `invoice_entry_validity_date` date NOT NULL,
  `invoice_entry_credit_days` int(11) NOT NULL,
  `invoice_entry_due_date` date NOT NULL,
  `invoice_entry_godown_id` int(11) NOT NULL,
  `invoice_entry_salesman_id` int(11) NOT NULL,
  `invoice_entry_gross_amount` decimal(20,4) NOT NULL,
  `invoice_entry_transport_amount` decimal(20,4) NOT NULL,
  `invoice_entry_tax_per` decimal(20,4) NOT NULL,
  `invoice_entry_tax_amount` decimal(20,4) NOT NULL,
  `invoice_entry_advance_amount` decimal(20,4) NOT NULL,
  `invoice_entry_net_amount` decimal(20,4) NOT NULL,
  `invoice_entry_type` int(11) NOT NULL,
  `invoice_entry_prd_type` int(11) NOT NULL,
  `invoice_entry_type_id` int(11) NOT NULL,
  `invoice_entry_quotation_entry_id` int(11) NOT NULL,
  `invoice_entry_company_id` int(11) NOT NULL,
  `invoice_entry_branch_id` int(11) NOT NULL,
  `invoice_entry_financial_year` int(11) NOT NULL,
  `invoice_entry_added_by` int(11) NOT NULL,
  `invoice_entry_added_on` int(11) NOT NULL,
  `invoice_entry_added_ip` varchar(20) NOT NULL,
  `invoice_entry_modified_by` int(11) NOT NULL,
  `invoice_entry_modified_on` int(11) NOT NULL,
  `invoice_entry_modified_ip` varchar(20) NOT NULL,
  `invoice_entry_deleted_by` int(11) NOT NULL,
  `invoice_entry_deleted_on` int(11) NOT NULL,
  `invoice_entry_deleted_ip` varchar(20) NOT NULL,
  `invoice_entry_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoice_entry`
--

INSERT INTO `invoice_entry` (`invoice_entry_id`, `invoice_entry_uniq_id`, `invoice_entry_no`, `invoice_entry_date`, `invoice_entry_customer_id`, `invoice_entry_validity_date`, `invoice_entry_credit_days`, `invoice_entry_due_date`, `invoice_entry_godown_id`, `invoice_entry_salesman_id`, `invoice_entry_gross_amount`, `invoice_entry_transport_amount`, `invoice_entry_tax_per`, `invoice_entry_tax_amount`, `invoice_entry_advance_amount`, `invoice_entry_net_amount`, `invoice_entry_type`, `invoice_entry_prd_type`, `invoice_entry_type_id`, `invoice_entry_quotation_entry_id`, `invoice_entry_company_id`, `invoice_entry_branch_id`, `invoice_entry_financial_year`, `invoice_entry_added_by`, `invoice_entry_added_on`, `invoice_entry_added_ip`, `invoice_entry_modified_by`, `invoice_entry_modified_on`, `invoice_entry_modified_ip`, `invoice_entry_deleted_by`, `invoice_entry_deleted_on`, `invoice_entry_deleted_ip`, `invoice_entry_deleted_status`) VALUES
(1, '8e591b49uedd03izytide04251e0f0780149f063', 'U-IN0001', '2018-01-06', 1, '0000-00-00', 10, '2018-01-16', 2, 1, '30.0000', '30.0000', '100.0000', '0.0000', '3.0000', '87.0000', 1, 1, 1, 1, 1, 2, 1, 1, 1515224104, '122.174.33.217', 0, 0, '', 0, 0, '', 0),
(2, '3ad7bfdcq3e8972t7gjd7edcbf83f20a5e139fb1', 'Inv0002', '2018-01-06', 1, '2018-01-06', 10, '2018-01-16', 1, 0, '84000.0000', '8400.0000', '10.0000', '2018.0000', '100.0000', '95300.0000', 2, 2, 1, 2, 1, 2, 1, 1, 1515224553, '122.174.33.217', 0, 0, '', 0, 0, '', 0),
(3, '0d2f818s36b26f97lfe4939952cca7fc49d5d37e', '11', '2018-01-06', 7, '2018-01-06', 0, '2018-01-06', 2, 0, '1000.0000', '0.0000', '0.0000', '2018.0000', '0.0000', '1000.0000', 2, 1, 1, 3, 1, 4, 1, 1, 1515226506, '103.197.196.11', 0, 0, '', 0, 0, '', 0),
(4, '31cef056ugf7de6z1al402c550a1916ae2785715', 'INV901', '2018-01-06', 3, '2018-01-13', 30, '2018-02-05', 2, 0, '1000.0000', '0.0000', '0.0000', '2018.0000', '0.0000', '1000.0000', 1, 1, 1, 4, 1, 3, 1, 1, 1515230638, '103.197.196.11', 0, 0, '', 0, 0, '', 0),
(5, 'f4060c2ug86e0esatp0eaf9f41edf0bd15db4e60', 'INV902', '2018-01-06', 3, '2018-01-13', 30, '2018-02-05', 2, 0, '10000.0000', '0.0000', '0.0000', '2018.0000', '0.0000', '10000.0000', 2, 1, 1, 4, 1, 3, 1, 1, 1515230839, '103.197.196.11', 0, 0, '', 0, 0, '', 0),
(6, '94c8e087jia0f6mvthn59d520922b1078aa90bf0', 'i99121', '2018-01-07', 6, '2018-01-08', 0, '2018-01-07', 1, 0, '2000.0000', '0.0000', '0.0000', '2018.0000', '0.0000', '2010.0000', 1, 1, 1, 6, 1, 1, 1, 1, 1515231612, '103.197.196.11', 0, 0, '', 0, 0, '', 0),
(7, '07888bbof4e7f2tmuyafbff1df4ebb6d4542e8b2', 'INV903', '2018-01-06', 3, '2018-01-13', 23, '2018-01-29', 2, 0, '100000.0000', '0.0000', '0.0000', '2018.0000', '0.0000', '100000.0000', 1, 2, 2, 7, 1, 3, 1, 1, 1515231654, '103.197.196.11', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `invoice_entry_product_details`
--

CREATE TABLE `invoice_entry_product_details` (
  `invoice_entry_product_detail_id` int(11) NOT NULL,
  `invoice_entry_product_detail_uniq_id` varchar(255) NOT NULL,
  `invoice_entry_product_detail_invoice_entry_id` int(11) NOT NULL,
  `invoice_entry_product_detail_quotation_detail_id` int(11) NOT NULL,
  `invoice_entry_product_detail_quotation_entry_id` int(11) NOT NULL,
  `invoice_entry_product_detail_product_id` int(11) NOT NULL,
  `invoice_entry_product_detail_product_type` int(11) NOT NULL,
  `invoice_entry_product_detail_product_thick` decimal(20,4) NOT NULL,
  `invoice_entry_product_detail_width_inches` decimal(20,4) NOT NULL,
  `invoice_entry_product_detail_width_mm` decimal(20,4) NOT NULL,
  `invoice_entry_product_detail_s_width_inches` decimal(20,4) NOT NULL,
  `invoice_entry_product_detail_s_width_mm` decimal(20,4) NOT NULL,
  `invoice_entry_product_detail_sl_feet` decimal(20,4) NOT NULL,
  `invoice_entry_product_detail_sl_feet_in` decimal(20,4) NOT NULL,
  `invoice_entry_product_detail_sl_feet_mm` decimal(20,4) NOT NULL,
  `invoice_entry_product_detail_s_weight_inches` decimal(20,4) NOT NULL,
  `invoice_entry_product_detail_s_weight_mm` decimal(20,4) NOT NULL,
  `invoice_entry_product_detail_tot_length` decimal(20,4) NOT NULL,
  `invoice_entry_product_detail_rate` decimal(20,4) NOT NULL,
  `invoice_entry_product_detail_total` decimal(20,4) NOT NULL,
  `invoice_entry_product_detail_qty` decimal(20,4) NOT NULL,
  `invoice_entry_product_detail_added_by` int(11) NOT NULL,
  `invoice_entry_product_detail_added_on` int(11) NOT NULL,
  `invoice_entry_product_detail_added_ip` varchar(20) NOT NULL,
  `invoice_entry_product_detail_modified_by` int(11) NOT NULL,
  `invoice_entry_product_detail_modified_on` int(11) NOT NULL,
  `invoice_entry_product_detail_modified_ip` varchar(20) NOT NULL,
  `invoice_entry_product_detail_deleted_by` int(11) NOT NULL,
  `invoice_entry_product_detail_deleted_on` int(11) NOT NULL,
  `invoice_entry_product_detail_deleted_ip` varchar(20) NOT NULL,
  `invoice_entry_product_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoice_entry_product_details`
--

INSERT INTO `invoice_entry_product_details` (`invoice_entry_product_detail_id`, `invoice_entry_product_detail_uniq_id`, `invoice_entry_product_detail_invoice_entry_id`, `invoice_entry_product_detail_quotation_detail_id`, `invoice_entry_product_detail_quotation_entry_id`, `invoice_entry_product_detail_product_id`, `invoice_entry_product_detail_product_type`, `invoice_entry_product_detail_product_thick`, `invoice_entry_product_detail_width_inches`, `invoice_entry_product_detail_width_mm`, `invoice_entry_product_detail_s_width_inches`, `invoice_entry_product_detail_s_width_mm`, `invoice_entry_product_detail_sl_feet`, `invoice_entry_product_detail_sl_feet_in`, `invoice_entry_product_detail_sl_feet_mm`, `invoice_entry_product_detail_s_weight_inches`, `invoice_entry_product_detail_s_weight_mm`, `invoice_entry_product_detail_tot_length`, `invoice_entry_product_detail_rate`, `invoice_entry_product_detail_total`, `invoice_entry_product_detail_qty`, `invoice_entry_product_detail_added_by`, `invoice_entry_product_detail_added_on`, `invoice_entry_product_detail_added_ip`, `invoice_entry_product_detail_modified_by`, `invoice_entry_product_detail_modified_on`, `invoice_entry_product_detail_modified_ip`, `invoice_entry_product_detail_deleted_by`, `invoice_entry_product_detail_deleted_on`, `invoice_entry_product_detail_deleted_ip`, `invoice_entry_product_detail_deleted_status`) VALUES
(1, 'feed7fdf642634n97fzdbaf427c4248adc21d625', 1, 1, 1, 5, 0, '0.0000', '10.0000', '254.0000', '36.0000', '914.4000', '100.0000', '1200.0000', '30480.0000', '0.0000', '0.0000', '720.0000', '10.0000', '20.0000', '2.0000', 1, 1515224104, '122.174.33.217', 0, 0, '', 0, 0, '', 0),
(2, '0f52d6b33d5b37rj3hj60b0249c024213ea98930', 1, 2, 1, 6, 0, '0.0000', '20.0000', '508.0000', '3.0000', '914.4000', '50.0000', '600.0000', '15240.0000', '0.0000', '0.0000', '7.5000', '10.0000', '10.0000', '1.0000', 1, 1515224104, '122.174.33.217', 0, 0, '', 0, 0, '', 0),
(3, 'b2e73e9gez9edfh74ss989dbd6c1a7c960d82e18', 2, 3, 2, 7, 0, '0.0000', '36.0000', '914.4000', '3.0000', '914.4000', '100.0000', '1200.0000', '30480.0000', '0.0000', '0.0000', '2083.3300', '300.0000', '75000.0000', '250.0000', 1, 1515224553, '122.174.33.217', 0, 0, '', 0, 0, '', 0),
(4, 'e551683dx0cb879iguj2773381e94cbed6eaa526', 2, 4, 2, 8, 0, '0.0000', '48.0000', '1219.2000', '3.0000', '914.4000', '200.0000', '2400.0000', '60960.0000', '0.0000', '0.0000', '3750.0000', '30.0000', '9000.0000', '300.0000', 1, 1515224553, '122.174.33.217', 0, 0, '', 0, 0, '', 0),
(5, '7d37936x5q736a64gpud53d7c75cd5dcb87baad2', 3, 5, 3, 7, 0, '0.0000', '36.0000', '914.4000', '2.0000', '508.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '100.0000', '1000.0000', '10.0000', 1, 1515226506, '103.197.196.11', 0, 0, '', 0, 0, '', 0),
(6, '8bafbeboja0752zuge33bb9365bcd920b3ef2d45', 4, 6, 4, 5, 0, '0.0000', '10.0000', '254.0000', '0.0000', '914.4000', '10.0000', '120.0000', '3048.0000', '0.0000', '0.0000', '0.0000', '1000.0000', '1000.0000', '1.0000', 1, 1515230638, '103.197.196.11', 0, 0, '', 0, 0, '', 0),
(7, '55f4d684swdd72vajdqdb8dc4dc1a8efe8dd9d17', 5, 6, 4, 6, 0, '0.0000', '20.0000', '508.0000', '0.0000', '914.4000', '10.0000', '120.0000', '3048.0000', '0.0000', '0.0000', '0.0000', '10000.0000', '10000.0000', '1.0000', 1, 1515230839, '103.197.196.11', 0, 0, '', 0, 0, '', 0),
(8, 'a9b58265p6f1848tupd6a8cab43cf66a7f89490b', 6, 8, 6, 14, 0, '0.0000', '36.0000', '914.4000', '18.0000', '457.2003', '100.0000', '1200.0000', '30480.0000', '0.0000', '0.0000', '50.0000', '1000.0000', '2000.0000', '2.0000', 1, 1515231612, '103.197.196.11', 0, 0, '', 0, 0, '', 0),
(9, '837c53cr7dd2233apqd383b9e8b5818bfde64515', 7, 9, 7, 8, 0, '0.0000', '48.0000', '1219.2000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '10.0000', '0.0000', '0.0000', '100000.0000', '100000.0000', '1.0000', 1, 1515231654, '103.197.196.11', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `opening_stock`
--

CREATE TABLE `opening_stock` (
  `opening_stock_id` int(11) NOT NULL,
  `opening_stock_uniq_id` varchar(255) NOT NULL,
  `opening_stock_no` varchar(30) NOT NULL,
  `opening_stock_date` date NOT NULL,
  `opening_stock_godown_id` int(11) NOT NULL,
  `opening_stock_company_id` int(11) NOT NULL,
  `opening_stock_branch_id` int(11) NOT NULL,
  `opening_stock_financial_year` int(11) NOT NULL,
  `opening_stock_added_by` int(11) NOT NULL,
  `opening_stock_added_on` int(11) NOT NULL,
  `opening_stock_added_ip` varchar(20) NOT NULL,
  `opening_stock_modified_by` int(11) NOT NULL,
  `opening_stock_modified_on` int(11) NOT NULL,
  `opening_stock_modified_ip` varchar(20) NOT NULL,
  `opening_stock_deleted_by` int(11) NOT NULL,
  `opening_stock_deleted_on` int(11) NOT NULL,
  `opening_stock_deleted_ip` varchar(20) NOT NULL,
  `opening_stock_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `opening_stock_product_details`
--

CREATE TABLE `opening_stock_product_details` (
  `opening_stock_product_detail_id` int(11) NOT NULL,
  `opening_stock_product_detail_uniq_id` varchar(255) NOT NULL,
  `opening_stock_product_detail_opening_stock_id` int(11) NOT NULL,
  `opening_stock_product_detail_product_id` int(11) NOT NULL,
  `opening_stock_product_detail_uom2` int(11) NOT NULL,
  `opening_stock_product_detail_qty1` decimal(20,4) NOT NULL,
  `opening_stock_product_detail_qty2` decimal(20,4) NOT NULL,
  `opening_stock_product_detail_company_id` int(11) NOT NULL,
  `opening_stock_product_detail_branch_id` int(11) NOT NULL,
  `opening_stock_product_detail_financial_year` varchar(20) NOT NULL,
  `opening_stock_product_detail_added_by` int(11) NOT NULL,
  `opening_stock_product_detail_added_on` int(11) NOT NULL,
  `opening_stock_product_detail_added_ip` varchar(20) NOT NULL,
  `opening_stock_product_detail_modified_by` int(11) NOT NULL,
  `opening_stock_product_detail_modified_on` int(11) NOT NULL,
  `opening_stock_product_detail_modified_ip` varchar(20) NOT NULL,
  `opening_stock_product_detail_deleted_by` int(11) NOT NULL,
  `opening_stock_product_detail_deleted_on` int(11) NOT NULL,
  `opening_stock_product_detail_deleted_ip` varchar(20) NOT NULL,
  `opening_stock_product_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payroll`
--

CREATE TABLE `payroll` (
  `payroll_id` int(11) NOT NULL,
  `payroll_branchid` int(11) NOT NULL,
  `payroll_mm_yyyy` varchar(20) NOT NULL,
  `payroll_month` int(11) NOT NULL,
  `payroll_year` int(11) NOT NULL,
  `payroll_employee_id` int(11) NOT NULL,
  `payroll_no_of_working_days` decimal(12,2) NOT NULL,
  `payroll_no_of_worked` decimal(12,2) NOT NULL,
  `payroll_no_of_leaves` decimal(12,2) NOT NULL,
  `payroll_basic_pay` decimal(12,2) NOT NULL,
  `payroll_allowance_amount` decimal(12,2) NOT NULL,
  `payroll_overtime_amount` decimal(12,2) NOT NULL,
  `payroll_gov_bouns` decimal(12,2) NOT NULL,
  `payroll_without_bouns` decimal(12,2) NOT NULL,
  `payroll_exp_bouns` decimal(12,2) NOT NULL,
  `payroll_earning_amount` decimal(12,2) NOT NULL,
  `payroll_loan_deduct_amount` decimal(12,2) NOT NULL,
  `payroll_ssb_deduct_amount` decimal(12,2) NOT NULL,
  `payroll_advance_amount` decimal(12,2) NOT NULL,
  `payroll_loss_of_pay` decimal(12,2) NOT NULL,
  `payroll_deduction_amount` decimal(12,2) NOT NULL,
  `payroll_net_amount` decimal(12,2) NOT NULL,
  `payroll_financial_year_id` int(11) NOT NULL,
  `payroll_branch_id` int(11) NOT NULL,
  `payroll_added_by` int(11) NOT NULL,
  `payroll_added_on` int(11) NOT NULL,
  `payroll_added_ip` varchar(20) NOT NULL,
  `payroll_modified_by` int(11) NOT NULL,
  `payroll_modified_on` int(11) NOT NULL,
  `payroll_modified_ip` varchar(20) NOT NULL,
  `payroll_deleted_by` int(11) NOT NULL,
  `payroll_deleted_on` int(11) NOT NULL,
  `payroll_deleted_ip` varchar(20) NOT NULL,
  `payroll_publish_status` varchar(20) NOT NULL,
  `payroll_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payroll`
--

INSERT INTO `payroll` (`payroll_id`, `payroll_branchid`, `payroll_mm_yyyy`, `payroll_month`, `payroll_year`, `payroll_employee_id`, `payroll_no_of_working_days`, `payroll_no_of_worked`, `payroll_no_of_leaves`, `payroll_basic_pay`, `payroll_allowance_amount`, `payroll_overtime_amount`, `payroll_gov_bouns`, `payroll_without_bouns`, `payroll_exp_bouns`, `payroll_earning_amount`, `payroll_loan_deduct_amount`, `payroll_ssb_deduct_amount`, `payroll_advance_amount`, `payroll_loss_of_pay`, `payroll_deduction_amount`, `payroll_net_amount`, `payroll_financial_year_id`, `payroll_branch_id`, `payroll_added_by`, `payroll_added_on`, `payroll_added_ip`, `payroll_modified_by`, `payroll_modified_on`, `payroll_modified_ip`, `payroll_deleted_by`, `payroll_deleted_on`, `payroll_deleted_ip`, `payroll_publish_status`, `payroll_deleted_status`) VALUES
(1, 1, '12-2017', 12, 2017, 1, '31.00', '31.00', '0.00', '55000.00', '5900.00', '0.00', '0.00', '0.00', '0.00', '60900.00', '0.00', '0.00', '0.00', '0.00', '0.00', '60900.00', 0, 1, 1, 2147483647, '182.65.86.37', 1, 2147483647, '203.81.163.238', 0, 0, '', '', 0),
(2, 1, '12-2017', 12, 2017, 2, '31.00', '31.00', '0.00', '6000.00', '2000.00', '0.00', '0.00', '0.00', '0.00', '8000.00', '0.00', '0.00', '1500.00', '0.00', '1500.00', '6500.00', 0, 1, 1, 2147483647, '182.65.86.37', 1, 2147483647, '203.81.163.238', 0, 0, '', '', 0),
(3, 1, '12-2017', 12, 2017, 3, '31.00', '31.00', '0.00', '35000.00', '2200.00', '0.00', '0.00', '0.00', '0.00', '37200.00', '0.00', '0.00', '0.00', '0.00', '0.00', '37200.00', 0, 1, 1, 2147483647, '182.65.86.37', 1, 2147483647, '203.81.163.238', 0, 0, '', '', 0),
(4, 1, '12-2017', 12, 2017, 4, '31.00', '27.00', '4.00', '22000.00', '2400.00', '2000.00', '0.00', '0.00', '0.00', '26400.00', '0.00', '0.00', '0.00', '2838.71', '2838.71', '23561.29', 0, 1, 1, 2147483647, '182.65.86.37', 1, 2147483647, '203.81.163.238', 0, 0, '', '', 0),
(5, 1, '12-2017', 12, 2017, 5, '31.00', '31.00', '0.00', '150000.00', '17000.00', '0.00', '0.00', '0.00', '0.00', '167000.00', '0.00', '0.00', '0.00', '0.00', '0.00', '167000.00', 0, 1, 1, 2147483647, '182.65.86.37', 1, 2147483647, '203.81.163.238', 0, 0, '', '', 0),
(6, 1, '12-2017', 12, 2017, 6, '31.00', '31.00', '0.00', '200000.00', '0.00', '0.00', '10000.00', '0.00', '10000.00', '220000.00', '0.00', '0.00', '0.00', '0.00', '0.00', '220000.00', 0, 1, 1, 2147483647, '182.65.86.37', 1, 2147483647, '203.81.163.238', 0, 0, '', '', 0),
(7, 1, '12-2017', 12, 2017, 8, '31.00', '31.00', '0.00', '200000.00', '0.00', '3000.00', '10000.00', '0.00', '10000.00', '223000.00', '0.00', '0.00', '10000.00', '0.00', '10000.00', '213000.00', 0, 1, 1, 2147483647, '182.65.86.37', 1, 2147483647, '203.81.163.238', 0, 0, '', '', 0),
(8, 1, '12-2017', 12, 2017, 9, '31.00', '31.00', '0.00', '200000.00', '0.00', '2500.00', '9000.00', '0.00', '9000.00', '220500.00', '0.00', '0.00', '10000.00', '0.00', '10000.00', '210500.00', 0, 1, 1, 2147483647, '182.65.86.37', 1, 2147483647, '203.81.163.238', 0, 0, '', '', 0),
(9, 1, '12-2017', 12, 2017, 10, '31.00', '30.00', '1.00', '300000.00', '0.00', '6000.00', '10000.00', '10000.00', '10000.00', '336000.00', '0.00', '0.00', '0.00', '0.00', '0.00', '336000.00', 0, 1, 1, 2147483647, '203.81.163.246', 1, 2147483647, '203.81.163.238', 0, 0, '', '', 0),
(10, 1, '11-2017', 11, 2017, 1, '30.00', '30.00', '0.00', '55000.00', '5900.00', '0.00', '0.00', '0.00', '0.00', '60900.00', '0.00', '0.00', '0.00', '0.00', '0.00', '60900.00', 0, 1, 1, 2147483647, '182.65.86.37', 1, 2147483647, '182.65.86.37', 0, 0, '', '', 0),
(11, 1, '11-2017', 11, 2017, 2, '30.00', '28.00', '2.00', '6000.00', '2000.00', '100.00', '0.00', '0.00', '0.00', '8100.00', '0.00', '0.00', '0.00', '400.00', '400.00', '7700.00', 0, 1, 1, 2147483647, '182.65.86.37', 1, 2147483647, '182.65.86.37', 0, 0, '', '', 0),
(12, 1, '11-2017', 11, 2017, 3, '30.00', '30.00', '0.00', '35000.00', '2200.00', '0.00', '0.00', '0.00', '0.00', '37200.00', '0.00', '0.00', '0.00', '0.00', '0.00', '37200.00', 0, 1, 1, 2147483647, '182.65.86.37', 1, 2147483647, '182.65.86.37', 0, 0, '', '', 0),
(13, 1, '11-2017', 11, 2017, 4, '30.00', '30.00', '0.00', '22000.00', '2400.00', '0.00', '0.00', '0.00', '0.00', '24400.00', '0.00', '0.00', '0.00', '0.00', '0.00', '24400.00', 0, 1, 1, 2147483647, '182.65.86.37', 1, 2147483647, '182.65.86.37', 0, 0, '', '', 0),
(14, 1, '11-2017', 11, 2017, 5, '30.00', '30.00', '0.00', '150000.00', '17000.00', '0.00', '0.00', '0.00', '0.00', '167000.00', '0.00', '0.00', '0.00', '0.00', '0.00', '167000.00', 0, 1, 1, 2147483647, '182.65.86.37', 1, 2147483647, '182.65.86.37', 0, 0, '', '', 0),
(15, 1, '11-2017', 11, 2017, 6, '30.00', '30.00', '0.00', '200000.00', '0.00', '0.00', '0.00', '0.00', '0.00', '200000.00', '0.00', '0.00', '0.00', '0.00', '0.00', '200000.00', 0, 1, 1, 2147483647, '182.65.86.37', 1, 2147483647, '182.65.86.37', 0, 0, '', '', 0),
(16, 1, '11-2017', 11, 2017, 8, '30.00', '30.00', '0.00', '200000.00', '0.00', '0.00', '0.00', '0.00', '0.00', '200000.00', '0.00', '0.00', '0.00', '0.00', '0.00', '200000.00', 0, 1, 1, 2147483647, '182.65.86.37', 1, 2147483647, '182.65.86.37', 0, 0, '', '', 0),
(17, 1, '11-2017', 11, 2017, 9, '30.00', '30.00', '0.00', '200000.00', '0.00', '0.00', '0.00', '0.00', '0.00', '200000.00', '0.00', '0.00', '0.00', '0.00', '0.00', '200000.00', 0, 1, 1, 2147483647, '182.65.86.37', 1, 2147483647, '182.65.86.37', 0, 0, '', '', 0),
(18, 1, '11-2017', 11, 2017, 10, '30.00', '30.00', '0.00', '300000.00', '0.00', '0.00', '0.00', '0.00', '0.00', '300000.00', '0.00', '0.00', '0.00', '0.00', '0.00', '300000.00', 0, 1, 1, 2147483647, '182.65.86.37', 1, 2147483647, '182.65.86.37', 0, 0, '', '', 0),
(19, 1, '12-2017', 12, 2017, 11, '31.00', '27.00', '4.00', '300000.00', '0.00', '0.00', '10000.00', '10000.00', '10000.00', '330000.00', '0.00', '0.00', '10000.00', '19354.84', '29354.84', '300645.16', 0, 1, 1, 2147483647, '203.81.163.238', 1, 2147483647, '203.81.163.238', 0, 0, '', '', 0),
(20, 1, '12-2017', 12, 2017, 12, '31.00', '27.00', '4.00', '300000.00', '0.00', '3500.00', '10000.00', '10000.00', '10000.00', '333500.00', '0.00', '0.00', '10000.00', '19354.84', '29354.84', '304145.16', 0, 1, 1, 2147483647, '203.81.163.238', 1, 2147483647, '203.81.163.238', 0, 0, '', '', 0),
(21, 3, '12-2017', 12, 2017, 13, '31.00', '30.00', '1.00', '108000.00', '12000.00', '1200.00', '31500.00', '7500.00', '3000.00', '163200.00', '0.00', '0.00', '10000.00', '3483.87', '13483.87', '149716.13', 0, 1, 1, 2147483647, '103.197.196.8', 1, 2147483647, '103.197.196.8', 0, 0, '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `pdo_entry`
--

CREATE TABLE `pdo_entry` (
  `pdo_entry_id` int(11) NOT NULL,
  `pdo_entry_uniq_id` varchar(255) NOT NULL,
  `pdo_entry_no` varchar(30) NOT NULL,
  `pdo_entry_date` date NOT NULL,
  `pdo_entry_godown_id` int(11) NOT NULL,
  `pdo_entry_delivery_type` int(11) NOT NULL,
  `pdo_entry_customer_id` int(11) NOT NULL,
  `pdo_entry_vehicle_no` varchar(100) NOT NULL,
  `pdo_entry_driver_name` varchar(100) NOT NULL,
  `pdo_entry_production_entry_id` int(11) NOT NULL,
  `pdo_entry_company_id` int(11) NOT NULL,
  `pdo_entry_branch_id` int(11) NOT NULL,
  `pdo_entry_financial_year` int(11) NOT NULL,
  `pdo_entry_added_by` int(11) NOT NULL,
  `pdo_entry_added_on` int(11) NOT NULL,
  `pdo_entry_added_ip` varchar(20) NOT NULL,
  `pdo_entry_modified_by` int(11) NOT NULL,
  `pdo_entry_modified_on` int(11) NOT NULL,
  `pdo_entry_modified_ip` varchar(20) NOT NULL,
  `pdo_entry_deleted_by` int(11) NOT NULL,
  `pdo_entry_deleted_on` int(11) NOT NULL,
  `pdo_entry_deleted_ip` varchar(20) NOT NULL,
  `pdo_entry_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pdo_entry_product_details`
--

CREATE TABLE `pdo_entry_product_details` (
  `pdo_entry_product_detail_id` int(11) NOT NULL,
  `pdo_entry_product_detail_uniq_id` varchar(255) NOT NULL,
  `pdo_entry_product_detail_pdo_entry_id` int(11) NOT NULL,
  `pdo_entry_product_detail_product_id` int(11) NOT NULL,
  `pdo_entry_product_detail_width_feet` decimal(20,4) NOT NULL,
  `pdo_entry_product_detail_width_inches` decimal(20,4) NOT NULL,
  `pdo_entry_product_detail_width_mm` decimal(20,4) NOT NULL,
  `pdo_entry_product_detail_width_meter` decimal(20,4) NOT NULL,
  `pdo_entry_product_detail_length_feet` decimal(20,4) NOT NULL,
  `pdo_entry_product_detail_length_inches` decimal(20,4) NOT NULL,
  `pdo_entry_product_detail_length_mm` decimal(20,4) NOT NULL,
  `pdo_entry_product_detail_length_meter` decimal(20,4) NOT NULL,
  `pdo_entry_product_detail_ext_length_feet` decimal(20,4) NOT NULL,
  `pdo_entry_product_detail_ext_length_meter` decimal(20,4) NOT NULL,
  `pdo_entry_product_detail_qty` decimal(20,4) NOT NULL,
  `pdo_entry_product_detail_type` int(11) NOT NULL,
  `pdo_entry_product_detail_production_entry_id` int(11) NOT NULL,
  `pdo_entry_product_detail_production_entry_detail_id` int(11) NOT NULL,
  `pdo_entry_product_detail_company_id` int(11) NOT NULL,
  `pdo_entry_product_detail_branch_id` int(11) NOT NULL,
  `pdo_entry_product_detail_financial_year` varchar(20) NOT NULL,
  `pdo_entry_product_detail_added_by` int(11) NOT NULL,
  `pdo_entry_product_detail_added_on` int(11) NOT NULL,
  `pdo_entry_product_detail_added_ip` varchar(20) NOT NULL,
  `pdo_entry_product_detail_modified_by` int(11) NOT NULL,
  `pdo_entry_product_detail_modified_on` int(11) NOT NULL,
  `pdo_entry_product_detail_modified_ip` varchar(20) NOT NULL,
  `pdo_entry_product_detail_deleted_by` int(11) NOT NULL,
  `pdo_entry_product_detail_deleted_on` int(11) NOT NULL,
  `pdo_entry_product_detail_deleted_ip` varchar(20) NOT NULL,
  `pdo_entry_product_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `prn_entry`
--

CREATE TABLE `prn_entry` (
  `prn_entry_id` int(11) NOT NULL,
  `prn_entry_uniq_id` varchar(255) NOT NULL,
  `prn_entry_no` varchar(30) NOT NULL,
  `prn_entry_date` date NOT NULL,
  `prn_entry_from_godown_id` int(11) NOT NULL,
  `prn_entry_to_godown_id` int(11) NOT NULL,
  `prn_entry_production_section_id` int(11) NOT NULL,
  `prn_entry_production_entry_id` int(11) NOT NULL,
  `prn_entry_company_id` int(11) NOT NULL,
  `prn_entry_branch_id` int(11) NOT NULL,
  `prn_entry_financial_year` int(11) NOT NULL,
  `prn_entry_added_by` int(11) NOT NULL,
  `prn_entry_added_on` int(11) NOT NULL,
  `prn_entry_added_ip` varchar(20) NOT NULL,
  `prn_entry_modified_by` int(11) NOT NULL,
  `prn_entry_modified_on` int(11) NOT NULL,
  `prn_entry_modified_ip` varchar(20) NOT NULL,
  `prn_entry_deleted_by` int(11) NOT NULL,
  `prn_entry_deleted_on` int(11) NOT NULL,
  `prn_entry_deleted_ip` varchar(20) NOT NULL,
  `prn_entry_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prn_entry`
--

INSERT INTO `prn_entry` (`prn_entry_id`, `prn_entry_uniq_id`, `prn_entry_no`, `prn_entry_date`, `prn_entry_from_godown_id`, `prn_entry_to_godown_id`, `prn_entry_production_section_id`, `prn_entry_production_entry_id`, `prn_entry_company_id`, `prn_entry_branch_id`, `prn_entry_financial_year`, `prn_entry_added_by`, `prn_entry_added_on`, `prn_entry_added_ip`, `prn_entry_modified_by`, `prn_entry_modified_on`, `prn_entry_modified_ip`, `prn_entry_deleted_by`, `prn_entry_deleted_on`, `prn_entry_deleted_ip`, `prn_entry_deleted_status`) VALUES
(1, 'ddacbc63io066dg7wa8a7b1e10d16c708f315756', '00001', '2017-12-15', 3, 1, 1, 3, 1, 1, 1, 1, 1513333797, '203.81.163.246', 1, 1513334021, '182.65.86.37', 0, 0, '', 0),
(2, '302a8f2ocn0b58vxko65880ca8eaaa4968b866cf', '00002', '2017-12-15', 3, 1, 1, 4, 1, 1, 1, 1, 1513334331, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(3, '3223767w5l21e160mu9f6f731ec442f37d160dbf', '00003', '2017-12-15', 3, 1, 1, 5, 1, 1, 1, 1, 1513335066, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(4, 'adaa70d68w648645bzo4a77ab1a029b283b91cef', '00004', '2017-12-16', 3, 1, 2, 6, 1, 1, 1, 1, 1513392021, '203.81.163.238', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `prn_entry_product_details`
--

CREATE TABLE `prn_entry_product_details` (
  `prn_entry_product_detail_id` int(11) NOT NULL,
  `prn_entry_product_detail_uniq_id` varchar(255) NOT NULL,
  `prn_entry_product_detail_prn_entry_id` int(11) NOT NULL,
  `prn_entry_product_detail_product_id` int(11) NOT NULL,
  `prn_entry_product_detail_width_feet` decimal(20,4) NOT NULL,
  `prn_entry_product_detail_width_inches` decimal(20,4) NOT NULL,
  `prn_entry_product_detail_width_mm` decimal(20,4) NOT NULL,
  `prn_entry_product_detail_width_meter` decimal(20,4) NOT NULL,
  `prn_entry_product_detail_length_feet` decimal(20,4) NOT NULL,
  `prn_entry_product_detail_length_inches` decimal(20,4) NOT NULL,
  `prn_entry_product_detail_length_mm` decimal(20,4) NOT NULL,
  `prn_entry_product_detail_length_meter` decimal(20,4) NOT NULL,
  `prn_entry_product_detail_ext_length_feet` decimal(20,4) NOT NULL,
  `prn_entry_product_detail_ext_length_meter` decimal(20,4) NOT NULL,
  `prn_entry_product_detail_qty` decimal(20,4) NOT NULL,
  `prn_entry_product_detail_type` int(11) NOT NULL,
  `prn_entry_product_detail_production_entry_id` int(11) NOT NULL,
  `prn_entry_product_detail_production_entry_detail_id` int(11) NOT NULL,
  `prn_entry_product_detail_company_id` int(11) NOT NULL,
  `prn_entry_product_detail_branch_id` int(11) NOT NULL,
  `prn_entry_product_detail_financial_year` varchar(20) NOT NULL,
  `prn_entry_product_detail_added_by` int(11) NOT NULL,
  `prn_entry_product_detail_added_on` int(11) NOT NULL,
  `prn_entry_product_detail_added_ip` varchar(20) NOT NULL,
  `prn_entry_product_detail_modified_by` int(11) NOT NULL,
  `prn_entry_product_detail_modified_on` int(11) NOT NULL,
  `prn_entry_product_detail_modified_ip` varchar(20) NOT NULL,
  `prn_entry_product_detail_deleted_by` int(11) NOT NULL,
  `prn_entry_product_detail_deleted_on` int(11) NOT NULL,
  `prn_entry_product_detail_deleted_ip` varchar(20) NOT NULL,
  `prn_entry_product_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prn_entry_product_details`
--

INSERT INTO `prn_entry_product_details` (`prn_entry_product_detail_id`, `prn_entry_product_detail_uniq_id`, `prn_entry_product_detail_prn_entry_id`, `prn_entry_product_detail_product_id`, `prn_entry_product_detail_width_feet`, `prn_entry_product_detail_width_inches`, `prn_entry_product_detail_width_mm`, `prn_entry_product_detail_width_meter`, `prn_entry_product_detail_length_feet`, `prn_entry_product_detail_length_inches`, `prn_entry_product_detail_length_mm`, `prn_entry_product_detail_length_meter`, `prn_entry_product_detail_ext_length_feet`, `prn_entry_product_detail_ext_length_meter`, `prn_entry_product_detail_qty`, `prn_entry_product_detail_type`, `prn_entry_product_detail_production_entry_id`, `prn_entry_product_detail_production_entry_detail_id`, `prn_entry_product_detail_company_id`, `prn_entry_product_detail_branch_id`, `prn_entry_product_detail_financial_year`, `prn_entry_product_detail_added_by`, `prn_entry_product_detail_added_on`, `prn_entry_product_detail_added_ip`, `prn_entry_product_detail_modified_by`, `prn_entry_product_detail_modified_on`, `prn_entry_product_detail_modified_ip`, `prn_entry_product_detail_deleted_by`, `prn_entry_product_detail_deleted_on`, `prn_entry_product_detail_deleted_ip`, `prn_entry_product_detail_deleted_status`) VALUES
(1, '37a8440l3i67ef5s7pl3e386fe53dd18e2ce6bc8', 1, 4, '36.0000', '432.0000', '10972.8000', '10.9728', '10.0000', '120.0000', '3048.0000', '3.0480', '0.0000', '0.0000', '1.0000', 1, 3, 1, 0, 0, '', 1, 1513333797, '203.81.163.246', 1, 1513334021, '182.65.86.37', 0, 0, '', 0),
(2, '7dbeab79eyfda5ux54f54364073739abcd26f0b8', 2, 4, '300.0000', '3600.0000', '91440.0000', '91.4400', '100.0000', '1200.0000', '30480.0000', '30.4800', '0.2999', '0.0914', '10.0000', 1, 4, 2, 0, 0, '', 1, 1513334331, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(3, '988ee9a29gf780itbx21344fc85915860522f1be', 3, 24, '3.0000', '36.0000', '914.4000', '0.9144', '10.0000', '120.0000', '3048.0000', '3.0480', '2.0000', '0.6096', '10.0000', 1, 5, 3, 0, 0, '', 1, 1513335066, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(4, '653890f12lc8351ogu4e48c8b336bc8aa71abc8c', 4, 4, '3.0000', '36.0000', '914.4000', '0.9144', '10.0000', '120.0000', '3048.0000', '3.0480', '0.0000', '0.0000', '1.0000', 1, 6, 4, 0, 0, '', 1, 1513392021, '203.81.163.238', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `production_entry`
--

CREATE TABLE `production_entry` (
  `production_entry_id` int(11) NOT NULL,
  `production_entry_uniq_id` varchar(255) NOT NULL,
  `production_entry_no` varchar(30) NOT NULL,
  `production_entry_date` date NOT NULL,
  `production_entry_godown_id` int(11) NOT NULL,
  `production_entry_type` int(11) NOT NULL,
  `production_entry_vendor_id` int(11) NOT NULL,
  `production_entry_grn_date` date NOT NULL,
  `production_entry_production_type` varchar(250) NOT NULL,
  `production_entry_grn_entry_id` int(11) NOT NULL,
  `production_entry_remarks` varchar(400) NOT NULL,
  `production_entry_company_id` int(11) NOT NULL,
  `production_entry_branch_id` int(11) NOT NULL,
  `production_entry_financial_year` int(11) NOT NULL,
  `production_entry_added_by` int(11) NOT NULL,
  `production_entry_added_on` int(11) NOT NULL,
  `production_entry_added_ip` varchar(20) NOT NULL,
  `production_entry_modified_by` int(11) NOT NULL,
  `production_entry_modified_on` int(11) NOT NULL,
  `production_entry_modified_ip` varchar(20) NOT NULL,
  `production_entry_deleted_by` int(11) NOT NULL,
  `production_entry_deleted_on` int(11) NOT NULL,
  `production_entry_deleted_ip` varchar(20) NOT NULL,
  `production_entry_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `production_entry`
--

INSERT INTO `production_entry` (`production_entry_id`, `production_entry_uniq_id`, `production_entry_no`, `production_entry_date`, `production_entry_godown_id`, `production_entry_type`, `production_entry_vendor_id`, `production_entry_grn_date`, `production_entry_production_type`, `production_entry_grn_entry_id`, `production_entry_remarks`, `production_entry_company_id`, `production_entry_branch_id`, `production_entry_financial_year`, `production_entry_added_by`, `production_entry_added_on`, `production_entry_added_ip`, `production_entry_modified_by`, `production_entry_modified_on`, `production_entry_modified_ip`, `production_entry_deleted_by`, `production_entry_deleted_on`, `production_entry_deleted_ip`, `production_entry_deleted_status`) VALUES
(3, '7d073b81uld80cj5hdxded7033ab6ee2a0e121bd', '00001', '2017-12-15', 3, 1, 0, '2017-12-15', '', 3, '', 1, 1, 1, 1, 1513332584, '203.81.163.246', 1, 1513333353, '182.65.86.37', 0, 0, '', 0),
(4, '3e7ef71qqz26ecbstye64829d2bf6f3ad2abd47e', '00002', '2017-12-15', 3, 1, 0, '2017-12-15', '', 4, '', 1, 1, 1, 1, 1513333450, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(5, 'ceed2aa34z32297vt9zba69feeb1a66b64b22b7a', '00003', '2017-12-15', 1, 1, 0, '2017-12-15', '', 5, '', 1, 1, 1, 1, 1513334728, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(6, '95a7f062zb9e7b6752l3a3981b7742f074cb03c1', '00004', '2017-12-16', 3, 1, 0, '2017-12-16', '', 6, '', 1, 1, 1, 1, 1513391762, '203.81.163.238', 0, 0, '', 0, 0, '', 0),
(7, 'dc68275k703a15uepfc861a1aab76fe0b7432e57', '00005', '2017-12-16', 3, 1, 0, '2017-12-16', '', 7, '', 1, 1, 1, 1, 1513393047, '203.81.163.238', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `production_entry_dam_product_details`
--

CREATE TABLE `production_entry_dam_product_details` (
  `production_entry_dam_product_detail_id` int(11) NOT NULL,
  `production_entry_dam_product_detail_uniq_id` varchar(255) NOT NULL,
  `production_entry_dam_product_detail_production_entry_id` int(11) NOT NULL,
  `production_entry_dam_product_detail_raw_product_id` int(11) NOT NULL,
  `production_entry_dam_product_detail_product_id` int(11) NOT NULL,
  `production_entry_dam_product_detail_width_feet` decimal(20,4) NOT NULL,
  `production_entry_dam_product_detail_width_inches` decimal(20,4) NOT NULL,
  `production_entry_dam_product_detail_width_mm` decimal(20,4) NOT NULL,
  `production_entry_dam_product_detail_width_meter` decimal(20,4) NOT NULL,
  `production_entry_dam_product_detail_length_feet` decimal(20,4) NOT NULL,
  `production_entry_dam_product_detail_length_inches` decimal(20,4) NOT NULL,
  `production_entry_dam_product_detail_length_mm` decimal(20,4) NOT NULL,
  `production_entry_dam_product_detail_length_meter` decimal(20,4) NOT NULL,
  `production_entry_dam_product_detail_ext_length_feet` decimal(20,4) NOT NULL,
  `production_entry_dam_product_detail_ext_length_meter` decimal(20,4) NOT NULL,
  `production_entry_dam_product_detail_qty` decimal(20,4) NOT NULL,
  `production_entry_dam_product_detail_company_id` int(11) NOT NULL,
  `production_entry_dam_product_detail_branch_id` int(11) NOT NULL,
  `production_entry_dam_product_detail_financial_year` varchar(20) NOT NULL,
  `production_entry_dam_product_detail_added_by` int(11) NOT NULL,
  `production_entry_dam_product_detail_added_on` int(11) NOT NULL,
  `production_entry_dam_product_detail_added_ip` varchar(20) NOT NULL,
  `production_entry_dam_product_detail_modified_by` int(11) NOT NULL,
  `production_entry_dam_product_detail_modified_on` int(11) NOT NULL,
  `production_entry_dam_product_detail_modified_ip` varchar(20) NOT NULL,
  `production_entry_dam_product_detail_deleted_by` int(11) NOT NULL,
  `production_entry_dam_product_detail_deleted_on` int(11) NOT NULL,
  `production_entry_dam_product_detail_deleted_ip` varchar(20) NOT NULL,
  `production_entry_dam_product_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `production_entry_dam_product_details`
--

INSERT INTO `production_entry_dam_product_details` (`production_entry_dam_product_detail_id`, `production_entry_dam_product_detail_uniq_id`, `production_entry_dam_product_detail_production_entry_id`, `production_entry_dam_product_detail_raw_product_id`, `production_entry_dam_product_detail_product_id`, `production_entry_dam_product_detail_width_feet`, `production_entry_dam_product_detail_width_inches`, `production_entry_dam_product_detail_width_mm`, `production_entry_dam_product_detail_width_meter`, `production_entry_dam_product_detail_length_feet`, `production_entry_dam_product_detail_length_inches`, `production_entry_dam_product_detail_length_mm`, `production_entry_dam_product_detail_length_meter`, `production_entry_dam_product_detail_ext_length_feet`, `production_entry_dam_product_detail_ext_length_meter`, `production_entry_dam_product_detail_qty`, `production_entry_dam_product_detail_company_id`, `production_entry_dam_product_detail_branch_id`, `production_entry_dam_product_detail_financial_year`, `production_entry_dam_product_detail_added_by`, `production_entry_dam_product_detail_added_on`, `production_entry_dam_product_detail_added_ip`, `production_entry_dam_product_detail_modified_by`, `production_entry_dam_product_detail_modified_on`, `production_entry_dam_product_detail_modified_ip`, `production_entry_dam_product_detail_deleted_by`, `production_entry_dam_product_detail_deleted_on`, `production_entry_dam_product_detail_deleted_ip`, `production_entry_dam_product_detail_deleted_status`) VALUES
(1, '5e407fbz27d7a5sv66x48ca57326f039c9294231', 4, 11, 4, '3.0000', '36.0000', '914.4000', '0.9144', '1.0000', '12.0000', '304.8000', '0.3048', '0.0000', '0.0000', '1.0000', 0, 0, '', 1, 1513333450, '203.81.163.246', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `production_entry_product_details`
--

CREATE TABLE `production_entry_product_details` (
  `production_entry_product_detail_id` int(11) NOT NULL,
  `production_entry_product_detail_uniq_id` varchar(255) NOT NULL,
  `production_entry_product_detail_production_entry_id` int(11) NOT NULL,
  `production_entry_product_detail_product_id` int(11) NOT NULL,
  `production_entry_product_detail_width_feet` decimal(20,4) NOT NULL,
  `production_entry_product_detail_width_inches` decimal(20,4) NOT NULL,
  `production_entry_product_detail_width_mm` decimal(20,4) NOT NULL,
  `production_entry_product_detail_width_meter` decimal(20,4) NOT NULL,
  `production_entry_product_detail_length_feet` decimal(20,4) NOT NULL,
  `production_entry_product_detail_length_inches` decimal(20,4) NOT NULL,
  `production_entry_product_detail_length_mm` decimal(20,4) NOT NULL,
  `production_entry_product_detail_length_meter` decimal(20,4) NOT NULL,
  `production_entry_product_detail_ext_length_feet` decimal(20,4) NOT NULL,
  `production_entry_product_detail_ext_length_meter` decimal(20,4) NOT NULL,
  `production_entry_product_detail_qty` decimal(20,4) NOT NULL,
  `production_entry_product_detail_type` int(11) NOT NULL,
  `production_entry_product_detail_grn_entry_id` int(11) NOT NULL,
  `production_entry_product_detail_grn_entry_detail_id` int(11) NOT NULL,
  `production_entry_product_detail_company_id` int(11) NOT NULL,
  `production_entry_product_detail_branch_id` int(11) NOT NULL,
  `production_entry_product_detail_financial_year` varchar(20) NOT NULL,
  `production_entry_product_detail_added_by` int(11) NOT NULL,
  `production_entry_product_detail_added_on` int(11) NOT NULL,
  `production_entry_product_detail_added_ip` varchar(20) NOT NULL,
  `production_entry_product_detail_modified_by` int(11) NOT NULL,
  `production_entry_product_detail_modified_on` int(11) NOT NULL,
  `production_entry_product_detail_modified_ip` varchar(20) NOT NULL,
  `production_entry_product_detail_deleted_by` int(11) NOT NULL,
  `production_entry_product_detail_deleted_on` int(11) NOT NULL,
  `production_entry_product_detail_deleted_ip` varchar(20) NOT NULL,
  `production_entry_product_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `production_entry_product_details`
--

INSERT INTO `production_entry_product_details` (`production_entry_product_detail_id`, `production_entry_product_detail_uniq_id`, `production_entry_product_detail_production_entry_id`, `production_entry_product_detail_product_id`, `production_entry_product_detail_width_feet`, `production_entry_product_detail_width_inches`, `production_entry_product_detail_width_mm`, `production_entry_product_detail_width_meter`, `production_entry_product_detail_length_feet`, `production_entry_product_detail_length_inches`, `production_entry_product_detail_length_mm`, `production_entry_product_detail_length_meter`, `production_entry_product_detail_ext_length_feet`, `production_entry_product_detail_ext_length_meter`, `production_entry_product_detail_qty`, `production_entry_product_detail_type`, `production_entry_product_detail_grn_entry_id`, `production_entry_product_detail_grn_entry_detail_id`, `production_entry_product_detail_company_id`, `production_entry_product_detail_branch_id`, `production_entry_product_detail_financial_year`, `production_entry_product_detail_added_by`, `production_entry_product_detail_added_on`, `production_entry_product_detail_added_ip`, `production_entry_product_detail_modified_by`, `production_entry_product_detail_modified_on`, `production_entry_product_detail_modified_ip`, `production_entry_product_detail_deleted_by`, `production_entry_product_detail_deleted_on`, `production_entry_product_detail_deleted_ip`, `production_entry_product_detail_deleted_status`) VALUES
(1, '1de3ee66b3d40ffpfyp0992408547a8dea789654', 3, 4, '36.0000', '432.0000', '10972.8000', '10.9728', '10.0000', '120.0000', '3048.0000', '3.0480', '0.0000', '0.0000', '1.0000', 1, 3, 0, 0, 0, '', 1, 1513333353, '182.65.86.37', 0, 0, '', 0, 0, '', 0),
(2, '4116de61yrd7a6vhszha04a120c4b3b4aafb44af', 4, 4, '300.0000', '3600.0000', '91440.0000', '91.4400', '100.0000', '1200.0000', '30480.0000', '30.4800', '0.2999', '0.0914', '10.0000', 1, 4, 4, 0, 0, '', 1, 1513333450, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(3, '5b01b9fa364041woth7a0c50fd48ba98c2ed4a10', 5, 24, '3.0000', '36.0000', '914.4000', '0.9144', '10.0000', '120.0000', '3048.0000', '3.0480', '2.0000', '0.6096', '10.0000', 1, 5, 0, 0, 0, '', 1, 1513334728, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(4, '019903c7cw40247k81mbad43dde52ca3ade4e20b', 6, 4, '3.0000', '36.0000', '914.4000', '0.9144', '10.0000', '120.0000', '3048.0000', '3.0480', '0.0000', '0.0000', '1.0000', 1, 6, 0, 0, 0, '', 1, 1513391762, '203.81.163.238', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `production_entry_raw_product_details`
--

CREATE TABLE `production_entry_raw_product_details` (
  `production_entry_raw_product_detail_id` int(11) NOT NULL,
  `production_entry_raw_product_detail_uniq_id` varchar(255) NOT NULL,
  `production_entry_raw_product_detail_production_entry_id` int(11) NOT NULL,
  `production_entry_raw_product_detail_raw_product_id` int(11) NOT NULL,
  `production_entry_raw_product_detail_product_id` int(11) NOT NULL,
  `production_entry_raw_product_detail_width_feet` decimal(20,4) NOT NULL,
  `production_entry_raw_product_detail_width_inches` decimal(20,4) NOT NULL,
  `production_entry_raw_product_detail_width_mm` decimal(20,4) NOT NULL,
  `production_entry_raw_product_detail_width_meter` decimal(20,4) NOT NULL,
  `production_entry_raw_product_detail_length_feet` decimal(20,4) NOT NULL,
  `production_entry_raw_product_detail_length_inches` decimal(20,4) NOT NULL,
  `production_entry_raw_product_detail_length_mm` decimal(20,4) NOT NULL,
  `production_entry_raw_product_detail_length_meter` decimal(20,4) NOT NULL,
  `production_entry_raw_product_detail_ext_length_feet` decimal(20,4) NOT NULL,
  `production_entry_raw_product_detail_ext_length_meter` decimal(20,4) NOT NULL,
  `production_entry_raw_product_detail_qty` decimal(20,4) NOT NULL,
  `production_entry_raw_product_detail_grn_entry_id` int(11) NOT NULL,
  `production_entry_raw_product_detail_raw_detail_id` int(11) NOT NULL,
  `production_entry_raw_product_detail_company_id` int(11) NOT NULL,
  `production_entry_raw_product_detail_branch_id` int(11) NOT NULL,
  `production_entry_raw_product_detail_financial_year` varchar(20) NOT NULL,
  `production_entry_raw_product_detail_added_by` int(11) NOT NULL,
  `production_entry_raw_product_detail_added_on` int(11) NOT NULL,
  `production_entry_raw_product_detail_added_ip` varchar(20) NOT NULL,
  `production_entry_raw_product_detail_modified_by` int(11) NOT NULL,
  `production_entry_raw_product_detail_modified_on` int(11) NOT NULL,
  `production_entry_raw_product_detail_modified_ip` varchar(20) NOT NULL,
  `production_entry_raw_product_detail_deleted_by` int(11) NOT NULL,
  `production_entry_raw_product_detail_deleted_on` int(11) NOT NULL,
  `production_entry_raw_product_detail_deleted_ip` varchar(20) NOT NULL,
  `production_entry_raw_product_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `production_entry_raw_product_details`
--

INSERT INTO `production_entry_raw_product_details` (`production_entry_raw_product_detail_id`, `production_entry_raw_product_detail_uniq_id`, `production_entry_raw_product_detail_production_entry_id`, `production_entry_raw_product_detail_raw_product_id`, `production_entry_raw_product_detail_product_id`, `production_entry_raw_product_detail_width_feet`, `production_entry_raw_product_detail_width_inches`, `production_entry_raw_product_detail_width_mm`, `production_entry_raw_product_detail_width_meter`, `production_entry_raw_product_detail_length_feet`, `production_entry_raw_product_detail_length_inches`, `production_entry_raw_product_detail_length_mm`, `production_entry_raw_product_detail_length_meter`, `production_entry_raw_product_detail_ext_length_feet`, `production_entry_raw_product_detail_ext_length_meter`, `production_entry_raw_product_detail_qty`, `production_entry_raw_product_detail_grn_entry_id`, `production_entry_raw_product_detail_raw_detail_id`, `production_entry_raw_product_detail_company_id`, `production_entry_raw_product_detail_branch_id`, `production_entry_raw_product_detail_financial_year`, `production_entry_raw_product_detail_added_by`, `production_entry_raw_product_detail_added_on`, `production_entry_raw_product_detail_added_ip`, `production_entry_raw_product_detail_modified_by`, `production_entry_raw_product_detail_modified_on`, `production_entry_raw_product_detail_modified_ip`, `production_entry_raw_product_detail_deleted_by`, `production_entry_raw_product_detail_deleted_on`, `production_entry_raw_product_detail_deleted_ip`, `production_entry_raw_product_detail_deleted_status`) VALUES
(1, '22b6cd4on78f8ai4wy8f0f8827b7263b038aeb91', 3, 11, 4, '3.0000', '36.0000', '914.4000', '0.9144', '10.0000', '120.0000', '3048.0000', '0.0000', '0.0000', '0.0000', '1.0000', 3, 3, 0, 0, '', 1, 1513332584, '203.81.163.246', 1, 1513333353, '182.65.86.37', 0, 0, '', 0),
(2, '6e06446zpt606d47gunc6777f67281db8a08aaed', 4, 11, 4, '3.0000', '36.0000', '914.4000', '0.9144', '100.0000', '1200.0000', '30480.0000', '0.0000', '0.0000', '0.0000', '1.0000', 4, 4, 0, 0, '', 1, 1513333450, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(3, '8a0c55a6n249d8gt4we99c368f051dc1e4a68455', 5, 23, 24, '3.0000', '36.0000', '914.4000', '0.9144', '120.0000', '1440.0000', '36576.0000', '0.0000', '0.0000', '0.0000', '1.0000', 5, 5, 0, 0, '', 1, 1513334728, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(4, '8600f02x3x3a54oo9wn2ae6575e1d1922ba8648e', 6, 11, 4, '3.0000', '36.0000', '914.4000', '0.9144', '10.0000', '120.0000', '3048.0000', '0.0000', '0.0000', '0.0000', '1.0000', 6, 6, 0, 0, '', 1, 1513391762, '203.81.163.238', 0, 0, '', 0, 0, '', 0),
(5, 'dcf2f025p651d2xzwekb0f75f4c4cda648dbe77b', 7, 11, 4, '3.0000', '36.0000', '914.4000', '0.9144', '10.0000', '120.0000', '3048.0000', '0.0000', '0.0000', '0.0000', '1.0000', 7, 7, 0, 0, '', 1, 1513393047, '203.81.163.238', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `production_entry_work_details`
--

CREATE TABLE `production_entry_work_details` (
  `production_entry_work_detail_id` int(11) NOT NULL,
  `production_entry_work_detail_uniq_id` varchar(255) NOT NULL,
  `production_entry_work_detail_production_entry_id` int(11) NOT NULL,
  `production_entry_work_detail_production_section_id` int(11) NOT NULL,
  `production_entry_work_detail_production_machine_id` int(11) NOT NULL,
  `production_entry_work_detail_employee_id` int(11) NOT NULL,
  `production_entry_work_detail_from_date` date NOT NULL,
  `production_entry_work_detail_to_date` date NOT NULL,
  `production_entry_work_detail_due` int(11) NOT NULL,
  `production_entry_work_detail_remarks` varchar(255) NOT NULL,
  `production_entry_work_detail_company_id` int(11) NOT NULL,
  `production_entry_work_detail_branch_id` int(11) NOT NULL,
  `production_entry_work_detail_financial_year` varchar(20) NOT NULL,
  `production_entry_work_detail_added_by` int(11) NOT NULL,
  `production_entry_work_detail_added_on` int(11) NOT NULL,
  `production_entry_work_detail_added_ip` varchar(20) NOT NULL,
  `production_entry_work_detail_modified_by` int(11) NOT NULL,
  `production_entry_work_detail_modified_on` int(11) NOT NULL,
  `production_entry_work_detail_modified_ip` varchar(20) NOT NULL,
  `production_entry_work_detail_deleted_by` int(11) NOT NULL,
  `production_entry_work_detail_deleted_on` int(11) NOT NULL,
  `production_entry_work_detail_deleted_ip` varchar(20) NOT NULL,
  `production_entry_work_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `production_entry_work_details`
--

INSERT INTO `production_entry_work_details` (`production_entry_work_detail_id`, `production_entry_work_detail_uniq_id`, `production_entry_work_detail_production_entry_id`, `production_entry_work_detail_production_section_id`, `production_entry_work_detail_production_machine_id`, `production_entry_work_detail_employee_id`, `production_entry_work_detail_from_date`, `production_entry_work_detail_to_date`, `production_entry_work_detail_due`, `production_entry_work_detail_remarks`, `production_entry_work_detail_company_id`, `production_entry_work_detail_branch_id`, `production_entry_work_detail_financial_year`, `production_entry_work_detail_added_by`, `production_entry_work_detail_added_on`, `production_entry_work_detail_added_ip`, `production_entry_work_detail_modified_by`, `production_entry_work_detail_modified_on`, `production_entry_work_detail_modified_ip`, `production_entry_work_detail_deleted_by`, `production_entry_work_detail_deleted_on`, `production_entry_work_detail_deleted_ip`, `production_entry_work_detail_deleted_status`) VALUES
(1, 'dc000b4tci7dffk692wba272aae89a3d3f67ba8d', 4, 1, 1, 2, '2017-12-15', '2017-12-16', 2, '', 0, 0, '', 1, 1513333450, '203.81.163.246', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `production_machines`
--

CREATE TABLE `production_machines` (
  `production_machine_id` int(11) NOT NULL,
  `production_machine_uniq_id` varchar(100) NOT NULL,
  `production_machine_name` varchar(80) NOT NULL,
  `production_machine_company_id` int(11) NOT NULL,
  `production_machine_production_section_id` int(11) NOT NULL,
  `production_machine_added_by` int(11) NOT NULL,
  `production_machine_added_on` int(11) NOT NULL,
  `production_machine_added_ip` varchar(20) NOT NULL,
  `production_machine_modified_by` int(11) NOT NULL,
  `production_machine_modified_on` int(11) NOT NULL,
  `production_machine_modified_ip` varchar(20) NOT NULL,
  `production_machine_deleted_by` int(11) NOT NULL,
  `production_machine_deleted_on` int(11) NOT NULL,
  `production_machine_deleted_ip` varchar(20) NOT NULL,
  `production_machine_active_status` varchar(20) NOT NULL DEFAULT 'active',
  `production_machine_deleted_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `production_machines`
--

INSERT INTO `production_machines` (`production_machine_id`, `production_machine_uniq_id`, `production_machine_name`, `production_machine_company_id`, `production_machine_production_section_id`, `production_machine_added_by`, `production_machine_added_on`, `production_machine_added_ip`, `production_machine_modified_by`, `production_machine_modified_on`, `production_machine_modified_ip`, `production_machine_deleted_by`, `production_machine_deleted_on`, `production_machine_deleted_ip`, `production_machine_active_status`, `production_machine_deleted_status`) VALUES
(1, '596ff928isabf3719di9c15f74731ab8197b208a', 'machine one', 0, 1, 1, 1507612647, '::1', 0, 0, '', 0, 0, '', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `production_order`
--

CREATE TABLE `production_order` (
  `production_order_id` int(11) NOT NULL,
  `production_order_uniq_id` varchar(255) NOT NULL,
  `production_order_no` varchar(30) NOT NULL,
  `production_order_date` date NOT NULL,
  `production_order_production_section_id` int(11) NOT NULL,
  `production_order_customer_id` int(11) NOT NULL,
  `production_order_department_id` int(11) NOT NULL,
  `production_order_type` int(11) NOT NULL,
  `production_order_invoice_entry_id` int(11) NOT NULL,
  `production_order_type_id` int(11) NOT NULL,
  `production_order_status` int(11) NOT NULL DEFAULT '1',
  `production_order_company_id` int(11) NOT NULL,
  `production_order_branch_id` int(11) NOT NULL,
  `production_order_financial_year` int(11) NOT NULL,
  `production_order_added_by` int(11) NOT NULL,
  `production_order_added_on` int(11) NOT NULL,
  `production_order_added_ip` varchar(20) NOT NULL,
  `production_order_modified_by` int(11) NOT NULL,
  `production_order_modified_on` int(11) NOT NULL,
  `production_order_modified_ip` varchar(20) NOT NULL,
  `production_order_deleted_by` int(11) NOT NULL,
  `production_order_deleted_on` int(11) NOT NULL,
  `production_order_deleted_ip` varchar(20) NOT NULL,
  `production_order_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `production_order`
--

INSERT INTO `production_order` (`production_order_id`, `production_order_uniq_id`, `production_order_no`, `production_order_date`, `production_order_production_section_id`, `production_order_customer_id`, `production_order_department_id`, `production_order_type`, `production_order_invoice_entry_id`, `production_order_type_id`, `production_order_status`, `production_order_company_id`, `production_order_branch_id`, `production_order_financial_year`, `production_order_added_by`, `production_order_added_on`, `production_order_added_ip`, `production_order_modified_by`, `production_order_modified_on`, `production_order_modified_ip`, `production_order_deleted_by`, `production_order_deleted_on`, `production_order_deleted_ip`, `production_order_deleted_status`) VALUES
(1, '5789be8nfaa877648aj02d4b0c8c91f958cf4d86', 'PO0002', '2018-01-06', 1, 1, 0, 1, 1, 1, 1, 1, 2, 1, 1, 1515224596, '122.174.33.217', 0, 0, '', 0, 0, '', 0),
(2, '07b358edpd2d8ei6nrh4a18d7c410036d34569ba', '11', '2018-01-06', 1, 7, 2, 2, 3, 1, 1, 1, 4, 1, 1, 1515226823, '103.197.196.11', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `production_order_product_details`
--

CREATE TABLE `production_order_product_details` (
  `production_order_product_detail_id` int(11) NOT NULL,
  `production_order_product_detail_uniq_id` varchar(255) NOT NULL,
  `production_order_product_detail_production_order_id` int(11) NOT NULL,
  `production_order_product_detail_invoice_detail_id` int(11) NOT NULL,
  `production_order_product_detail_invoice_entry_id` int(11) NOT NULL,
  `production_order_product_detail_product_id` int(11) NOT NULL,
  `production_order_product_detail_product_type` int(11) NOT NULL,
  `production_order_product_detail_product_thick` decimal(20,4) NOT NULL,
  `production_order_product_detail_width_inches` decimal(20,4) NOT NULL,
  `production_order_product_detail_width_mm` decimal(20,4) NOT NULL,
  `production_order_product_detail_s_width_inches` decimal(20,4) NOT NULL,
  `production_order_product_detail_s_width_mm` decimal(20,4) NOT NULL,
  `production_order_product_detail_sl_feet` decimal(20,4) NOT NULL,
  `production_order_product_detail_sl_feet_in` decimal(20,4) NOT NULL,
  `production_order_product_detail_sl_feet_mm` decimal(20,4) NOT NULL,
  `production_order_product_detail_s_weight_inches` decimal(20,4) NOT NULL,
  `production_order_product_detail_s_weight_mm` decimal(20,4) NOT NULL,
  `production_order_product_detail_tot_length` decimal(20,4) NOT NULL,
  `production_order_product_detail_qty` decimal(20,4) NOT NULL,
  `production_order_product_detail_added_by` int(11) NOT NULL,
  `production_order_product_detail_added_on` int(11) NOT NULL,
  `production_order_product_detail_added_ip` varchar(20) NOT NULL,
  `production_order_product_detail_modified_by` int(11) NOT NULL,
  `production_order_product_detail_modified_on` int(11) NOT NULL,
  `production_order_product_detail_modified_ip` varchar(20) NOT NULL,
  `production_order_product_detail_deleted_by` int(11) NOT NULL,
  `production_order_product_detail_deleted_on` int(11) NOT NULL,
  `production_order_product_detail_deleted_ip` varchar(20) NOT NULL,
  `production_order_product_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `production_order_product_details`
--

INSERT INTO `production_order_product_details` (`production_order_product_detail_id`, `production_order_product_detail_uniq_id`, `production_order_product_detail_production_order_id`, `production_order_product_detail_invoice_detail_id`, `production_order_product_detail_invoice_entry_id`, `production_order_product_detail_product_id`, `production_order_product_detail_product_type`, `production_order_product_detail_product_thick`, `production_order_product_detail_width_inches`, `production_order_product_detail_width_mm`, `production_order_product_detail_s_width_inches`, `production_order_product_detail_s_width_mm`, `production_order_product_detail_sl_feet`, `production_order_product_detail_sl_feet_in`, `production_order_product_detail_sl_feet_mm`, `production_order_product_detail_s_weight_inches`, `production_order_product_detail_s_weight_mm`, `production_order_product_detail_tot_length`, `production_order_product_detail_qty`, `production_order_product_detail_added_by`, `production_order_product_detail_added_on`, `production_order_product_detail_added_ip`, `production_order_product_detail_modified_by`, `production_order_product_detail_modified_on`, `production_order_product_detail_modified_ip`, `production_order_product_detail_deleted_by`, `production_order_product_detail_deleted_on`, `production_order_product_detail_deleted_ip`, `production_order_product_detail_deleted_status`) VALUES
(1, '4986bb9ga4edffrmauf25bca8a46f8bf2f230448', 1, 1, 1, 5, 0, '0.0000', '10.0000', '254.0000', '36.0000', '914.4000', '100.0000', '1200.0000', '30480.0000', '0.0000', '0.0000', '720.0000', '2.0000', 1, 1515224596, '122.174.33.217', 0, 0, '', 0, 0, '', 0),
(2, 'e12e5223etfec78b5nqa98f034e40e88cc592799', 1, 2, 1, 6, 0, '0.0000', '20.0000', '508.0000', '3.0000', '914.4000', '50.0000', '600.0000', '15240.0000', '0.0000', '0.0000', '7.5000', '1.0000', 1, 1515224596, '122.174.33.217', 0, 0, '', 0, 0, '', 0),
(3, '4792e517sy39858jt17d57d69054fcb4e51848a8', 2, 5, 3, 7, 0, '0.0000', '36.0000', '914.4000', '2.0000', '508.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '10.0000', 1, 1515226823, '103.197.196.11', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `production_sections`
--

CREATE TABLE `production_sections` (
  `production_section_id` int(11) NOT NULL,
  `production_section_uniq_id` varchar(100) NOT NULL,
  `production_section_name` varchar(80) NOT NULL,
  `production_section_company_id` int(11) NOT NULL,
  `production_section_added_by` int(11) NOT NULL,
  `production_section_added_on` int(11) NOT NULL,
  `production_section_added_ip` varchar(20) NOT NULL,
  `production_section_modified_by` int(11) NOT NULL,
  `production_section_modified_on` int(11) NOT NULL,
  `production_section_modified_ip` varchar(20) NOT NULL,
  `production_section_deleted_by` int(11) NOT NULL,
  `production_section_deleted_on` int(11) NOT NULL,
  `production_section_deleted_ip` varchar(20) NOT NULL,
  `production_section_active_status` varchar(20) NOT NULL DEFAULT 'active',
  `production_section_deleted_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `production_sections`
--

INSERT INTO `production_sections` (`production_section_id`, `production_section_uniq_id`, `production_section_name`, `production_section_company_id`, `production_section_added_by`, `production_section_added_on`, `production_section_added_ip`, `production_section_modified_by`, `production_section_modified_on`, `production_section_modified_ip`, `production_section_deleted_by`, `production_section_deleted_on`, `production_section_deleted_ip`, `production_section_active_status`, `production_section_deleted_status`) VALUES
(1, 'a0b68e0lkc89c4k4ys3c26515e09eae7155210de', 'First Section', 0, 1, 1507541496, '::1', 0, 0, '', 0, 0, '', 'active', 0),
(2, 'f816c65zvn49c40r3nt3119dcae2c7dd0ebd4259', 'Prd Sect_01', 1, 1, 1510372615, '103.197.196.17', 0, 0, '', 0, 0, '', 'active', 0),
(3, '2a58d4eti58c9e92chgfb22a9218c2e3a254f02e', 'Prd Sect_01', 1, 1, 1510372616, '103.197.196.17', 0, 0, '', 0, 0, '', 'active', 0),
(4, '5b289638yf52c9qonvkdf30f3d3af926d13d00e9', 'PS01', 1, 1, 1510989853, '103.197.196.40', 0, 0, '', 0, 0, '', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_uniq_id` varchar(100) NOT NULL,
  `product_code` varchar(50) NOT NULL,
  `product_name` varchar(80) NOT NULL,
  `product_brand_id` int(11) NOT NULL,
  `product_product_category_id` int(11) NOT NULL,
  `product_type` int(11) NOT NULL,
  `product_product_uom_id` int(11) NOT NULL,
  `product_purchase_uom_id` int(11) NOT NULL,
  `product_uom_one_id` int(11) NOT NULL,
  `product_product_colour_id` int(11) NOT NULL,
  `product_thick_ness` decimal(12,3) NOT NULL,
  `product_feet_qty` decimal(12,3) NOT NULL,
  `product_meter_qty` decimal(12,3) NOT NULL,
  `product_inches_qty` decimal(12,3) NOT NULL,
  `product_mm_qty` decimal(12,4) NOT NULL,
  `product_cost_price` decimal(12,3) NOT NULL,
  `product_production_type` int(11) NOT NULL,
  `product_company_id` int(11) NOT NULL,
  `product_added_by` int(11) NOT NULL,
  `product_added_on` int(11) NOT NULL,
  `product_added_ip` varchar(20) NOT NULL,
  `product_modified_by` int(11) NOT NULL,
  `product_modified_on` int(11) NOT NULL,
  `product_modified_ip` varchar(20) NOT NULL,
  `product_deleted_by` int(11) NOT NULL,
  `product_deleted_on` int(11) NOT NULL,
  `product_deleted_ip` varchar(20) NOT NULL,
  `product_active_status` varchar(20) NOT NULL DEFAULT 'active',
  `product_deleted_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_uniq_id`, `product_code`, `product_name`, `product_brand_id`, `product_product_category_id`, `product_type`, `product_product_uom_id`, `product_purchase_uom_id`, `product_uom_one_id`, `product_product_colour_id`, `product_thick_ness`, `product_feet_qty`, `product_meter_qty`, `product_inches_qty`, `product_mm_qty`, `product_cost_price`, `product_production_type`, `product_company_id`, `product_added_by`, `product_added_on`, `product_added_ip`, `product_modified_by`, `product_modified_on`, `product_modified_ip`, `product_deleted_by`, `product_deleted_on`, `product_deleted_ip`, `product_active_status`, `product_deleted_status`) VALUES
(1, 'f62084fpdod808nxexg878bc4159a85a9210fce4', 'PR000001', 'Honor', 2, 3, 1, 2, 0, 2, 1, '12.000', '12.000', '3.658', '144.000', '3657.6000', '5000.000', 0, 0, 1, 1507520018, '::1', 0, 0, '', 0, 0, '', 'active', 0),
(2, '819f86cceq1533drs5a7a9d024fb70ab321a92ee', 'PR000002', 'Honor Raw One', 2, 3, 1, 1, 0, 1, 1, '1.000', '2.000', '0.610', '24.000', '609.6000', '3000.000', 0, 0, 1, 1507547164, '::1', 0, 0, '', 0, 0, '', 'active', 0),
(3, '1c6036fhawc434q8ltlc138af2032ba4df02b760', 'PR000003', 'Honor Raw Two', 2, 3, 1, 1, 0, 1, 1, '2.000', '3.000', '0.914', '36.000', '914.4000', '2500.000', 0, 0, 1, 1507547321, '::1', 0, 0, '', 0, 0, '', 'active', 0),
(4, '6fe083ew5g554c1bsqs6ec8de24087086bc50875', 'PP', 'PPGI 1', 4, 8, 1, 3, 0, 0, 1, '1.000', '0.000', '0.000', '0.000', '0.0000', '0.000', 0, 1, 1, 1510375288, '103.197.196.17', 1, 1513403398, '', 0, 0, '', 'active', 0),
(5, '9d6d285l5v3982ptg2u03b66f797695d34e37b9c', 'LT0001', '4 Angel Red 1mm', 4, 8, 3, 1, 3, 0, 1, '1.000', '1.000', '0.305', '12.000', '304.8000', '0.000', 1, 1, 1, 1510375815, '103.197.196.17', 1, 1513403450, '', 0, 0, '', 'active', 0),
(6, '9ee8337ot3732bk7ist259c939945d1415b55348', 'PR000001', 'Raw GI', 6, 9, 1, 3, 0, 0, 1, '3.000', '0.000', '0.000', '0.000', '0.0000', '0.000', 0, 1, 1, 1510387520, '103.197.196.17', 0, 0, '', 0, 0, '', 'active', 0),
(7, '2448e6daaw0ebfl8b1l4824bbd859e859312a883', 'CC0001', 'C channel1 Red 1mm', 4, 10, 3, 3, 3, 0, 1, '1.000', '1.000', '0.305', '12.000', '304.8000', '0.000', 2, 1, 1, 1510984703, '74.50.213.41', 1, 1513390016, '', 0, 0, '', 'active', 0),
(8, '518352cl4i3a08owlhe39217c51e4e4acd56a547', 'RGI01', 'Raw GI _Test_01', 6, 9, 1, 6, 3, 0, 1, '1.000', '100.000', '30.480', '1200.000', '30480.0000', '0.000', 1, 1, 1, 1510989327, '103.197.196.40', 1, 1510989492, '', 0, 0, '', 'active', 0),
(9, '5d02006eix97d9a4wwf2937139f31e932bc43187', 'GIF01', 'GI_Test_02', 6, 8, 3, 6, 3, 0, 1, '1.000', '10.000', '3.048', '120.000', '3048.0000', '0.000', 1, 1, 1, 1510989400, '103.197.196.40', 1, 1510990041, '', 0, 0, '', 'active', 0),
(10, 'f8c307folqc2a7zesys0367642b996f4f3249035', 'PPGL00090', 'Mother Coin Raw', 7, 11, 1, 7, 7, 0, 1, '36.000', '0.000', '0.000', '0.000', '0.0000', '0.000', 1, 1, 1, 1512558109, '103.197.196.15', 1, 1512719170, '', 0, 0, '', 'active', 0),
(11, 'e94109a98n13e63q4a693b468db6cfa980838a12', 'PPGL000111', 'Mother Coin', 7, 11, 1, 3, 7, 0, 1, '3.000', '1000.000', '304.800', '12000.000', '304800.0000', '0.000', 1, 1, 1, 1512719525, '103.197.196.19', 1, 1512720062, '', 0, 0, '', 'active', 0),
(12, 'eeadd3barte4e95b19c96b3d9b530ada5b2981b2', 'PR000002', '4 Angel Red 3mm', 7, 8, 3, 1, 7, 0, 1, '3.000', '4.000', '1.219', '48.000', '1219.2000', '0.000', 1, 1, 1, 1512791380, '103.197.196.17', 1, 1513390250, '', 0, 0, '', 'active', 0),
(13, '2e9cbect0w08b7sj28a81586e32d2267893ea878', 'PR000003', '4 Angel blue 1mm', 6, 8, 3, 1, 3, 0, 1, '1.000', '1.000', '0.305', '12.000', '304.8000', '0.000', 1, 1, 1, 1512800575, '103.197.196.14', 1, 1513390209, '', 0, 0, '', 'active', 0),
(14, '6e23862ax6059fb3mvz3312199238bbc5fe3ba58', 'PR000004', 'GIPP Coin', 8, 11, 1, 6, 3, 0, 1, '0.000', '0.000', '0.000', '0.000', '0.0000', '0.000', 1, 1, 1, 1513143119, '103.197.196.27', 0, 0, '', 0, 0, '', 'active', 0),
(15, '582ef77dao9091qug282118a30de1913320feee9', 'PR000005', 'Royal Design red 2mm', 8, 8, 3, 1, 0, 0, 1, '2.000', '0.000', '0.000', '0.000', '0.0000', '0.000', 1, 1, 1, 1513143173, '103.197.196.27', 1, 1513390077, '', 0, 0, '', 'active', 0),
(16, '693df1egra8446igtfae32dcf9403fef877c371f', 'PR000006', 'GIPP Coin 1', 8, 11, 1, 3, 0, 0, 0, '0.000', '0.000', '0.000', '0.000', '0.0000', '0.000', 0, 1, 1, 1513144306, '103.197.196.27', 0, 0, '', 0, 0, '', 'active', 0),
(17, 'cdaf685zjbf741zwg1td9c4583b19d49e73b67ea', 'PR000007', 'Korea Design', 8, 8, 3, 1, 0, 0, 1, '0.000', '0.000', '0.000', '0.000', '0.0000', '0.000', 1, 1, 1, 1513164437, '103.197.196.20', 0, 0, '', 0, 0, '', 'active', 0),
(18, '0ca1cbbgctf51d4nvee17f8b5e7506940f182dff', 'PR000008', 'Royal Design Thailand Red 3mm', 9, 8, 3, 1, 1, 0, 1, '3.000', '0.000', '0.000', '0.000', '0.0000', '0.000', 1, 1, 1, 1513225858, '103.197.196.20', 1, 1513390157, '', 0, 0, '', 'active', 0),
(19, 'e83943bnut8f9cgrj525c47cf3b3dda0f673da18', 'PR000009', '4 Angel Thailand', 9, 8, 3, 1, 1, 0, 1, '3.000', '0.000', '0.000', '0.000', '0.0000', '0.000', 1, 1, 1, 1513225906, '103.197.196.20', 0, 0, '', 0, 0, '', 'active', 0),
(20, '9306c057a5d35cunogde9fe6fe967926b0050036', 'PR000010', 'Korea Design Thailand', 9, 8, 3, 1, 1, 0, 1, '0.000', '0.000', '0.000', '0.000', '0.0000', '0.000', 1, 1, 1, 1513226249, '103.197.196.20', 0, 0, '', 0, 0, '', 'active', 0),
(21, 'a9813dab3s8840u8l2f1a091aa7886073c91b87d', 'PR000011', 'PPGI Thailand Raw', 9, 11, 1, 3, 3, 0, 1, '3.000', '0.000', '0.000', '0.000', '0.0000', '0.000', 1, 1, 1, 1513245867, '103.197.196.20', 0, 0, '', 0, 0, '', 'active', 0),
(22, '091d819e8qfe92zf9lx3d8f759ffa4e336f80722', 'PR000012', 'GI Coin', 10, 12, 1, 3, 3, 0, 1, '3.000', '0.000', '0.000', '0.000', '0.0000', '0.000', 2, 1, 1, 1513313336, '203.81.163.231', 0, 0, '', 0, 0, '', 'active', 0),
(23, '7419202xkce99ajsq8o7f4d6c623daaa5661c783', 'PR000013', 'Other Mother Coin', 11, 11, 1, 3, 0, 0, 1, '3.000', '0.000', '0.000', '0.000', '0.0000', '0.000', 0, 1, 1, 1513326399, '203.81.163.246', 0, 0, '', 0, 0, '', 'active', 0),
(24, 'abefbad8dn1f52d06lxe9ecb4bf5da95adfbd5a9', 'PR000014', 'Other Royal Design', 11, 8, 3, 1, 0, 0, 1, '3.000', '0.000', '0.000', '0.000', '0.0000', '0.000', 0, 1, 1, 1513326576, '203.81.163.246', 1, 1513326611, '', 0, 0, '', 'active', 0),
(25, 'bc54d2dpcsf7f4qwayw23b59ee5b770949f3f046', 'CPPGI', 'PPGI', 4, 8, 1, 3, 3, 0, 1, '3.000', '1.000', '0.305', '12.000', '304.8000', '0.000', 1, 1, 1, 1513390434, '103.242.98.230', 0, 0, '', 0, 0, '', 'active', 0),
(26, '916fa852jx0363q5a8l0bfc024e36aa8c82e1737', 'PR000015', 'Accessories', 4, 12, 3, 1, 1, 0, 0, '0.000', '0.000', '0.000', '0.000', '0.0000', '0.000', 0, 1, 1, 1513400358, '103.242.98.226', 0, 0, '', 0, 0, '', 'active', 0),
(27, '63e2fc4iebf627q6dmxea3d873fb3fd5cf5ff922', '', 'LT', 6, 11, 1, 0, 0, 0, 0, '0.000', '0.000', '0.000', '0.000', '0.0000', '0.000', 0, 1, 1, 1513401851, '103.242.98.226', 0, 0, '', 0, 0, '', 'active', 0),
(28, '3c1f3e5t67c57ad5qi9391117b35d14e1a3df29e', 'LT4765', 'LT', 6, 11, 1, 3, 3, 0, 1, '0.000', '0.000', '0.000', '0.000', '0.0000', '0.000', 1, 1, 1, 1513402175, '103.242.98.226', 0, 0, '', 0, 0, '', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_calculations`
--

CREATE TABLE `product_calculations` (
  `product_calculation_id` int(11) NOT NULL,
  `product_calculation_type` varchar(100) NOT NULL,
  `product_calculation_fleet` decimal(12,4) NOT NULL,
  `product_calculation_inches` decimal(12,4) NOT NULL,
  `product_calculation_mm` decimal(12,4) NOT NULL,
  `product_calculation_meter` decimal(12,4) NOT NULL,
  `product_calculation_added_by` int(11) NOT NULL,
  `product_calculation_added_on` int(11) NOT NULL,
  `product_calculation_added_ip` varchar(20) NOT NULL,
  `product_calculation_modified_by` int(11) NOT NULL,
  `product_calculation_modified_on` int(11) NOT NULL,
  `product_calculation_modified_ip` varchar(20) NOT NULL,
  `product_calculation_deleted_by` int(11) NOT NULL,
  `product_calculation_deleted_on` int(11) NOT NULL,
  `product_calculation_deleted_ip` varchar(20) NOT NULL,
  `product_calculation_active_status` varchar(20) NOT NULL DEFAULT 'active',
  `product_calculation_deleted_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_calculations`
--

INSERT INTO `product_calculations` (`product_calculation_id`, `product_calculation_type`, `product_calculation_fleet`, `product_calculation_inches`, `product_calculation_mm`, `product_calculation_meter`, `product_calculation_added_by`, `product_calculation_added_on`, `product_calculation_added_ip`, `product_calculation_modified_by`, `product_calculation_modified_on`, `product_calculation_modified_ip`, `product_calculation_deleted_by`, `product_calculation_deleted_on`, `product_calculation_deleted_ip`, `product_calculation_active_status`, `product_calculation_deleted_status`) VALUES
(1, '1', '1.0000', '12.0000', '304.8000', '0.3048', 0, 0, '', 0, 0, '', 0, 0, '', 'active', 0),
(2, '2', '0.0833', '1.0000', '25.4000', '0.0254', 0, 0, '', 0, 0, '', 0, 0, '', 'active', 0),
(3, '3', '0.0033', '0.0394', '1.0000', '0.0010', 0, 0, '', 0, 0, '', 0, 0, '', 'active', 0),
(4, '4', '3.2800', '39.3700', '1000.0000', '1.0000', 0, 0, '', 0, 0, '', 0, 0, '', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_categories`
--

CREATE TABLE `product_categories` (
  `product_category_id` int(11) NOT NULL,
  `product_category_uniq_id` varchar(100) NOT NULL,
  `product_category_name` varchar(80) NOT NULL,
  `product_category_company_id` int(11) NOT NULL,
  `product_category_added_by` int(11) NOT NULL,
  `product_category_added_on` int(11) NOT NULL,
  `product_category_added_ip` varchar(20) NOT NULL,
  `product_category_modified_by` int(11) NOT NULL,
  `product_category_modified_on` int(11) NOT NULL,
  `product_category_modified_ip` varchar(20) NOT NULL,
  `product_category_deleted_by` int(11) NOT NULL,
  `product_category_deleted_on` int(11) NOT NULL,
  `product_category_deleted_ip` varchar(20) NOT NULL,
  `product_category_active_status` varchar(20) NOT NULL DEFAULT 'active',
  `product_category_deleted_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_categories`
--

INSERT INTO `product_categories` (`product_category_id`, `product_category_uniq_id`, `product_category_name`, `product_category_company_id`, `product_category_added_by`, `product_category_added_on`, `product_category_added_ip`, `product_category_modified_by`, `product_category_modified_on`, `product_category_modified_ip`, `product_category_deleted_by`, `product_category_deleted_on`, `product_category_deleted_ip`, `product_category_active_status`, `product_category_deleted_status`) VALUES
(1, '7c5020604c40fbk1sk75779e67f438399b360b2a', 'Sumsong 0.1', 0, 1, 1504505094, '::1', 0, 0, '', 0, 0, '', 'active', 0),
(2, 'cb0db19dyaccb4dod7qae96e69d9da52cc82fc50', 'Sumsong 1.2', 0, 1, 1504505114, '::1', 0, 0, '', 0, 0, '', 'active', 0),
(3, 'ef8d3a60dg92551v3b602fb764c778b1fc72e663', 'Honor 1.0', 0, 1, 1504505138, '::1', 0, 0, '', 0, 0, '', 'active', 0),
(4, 'e2dcbf493ga288glg3p46f7a43149fb40edbae70', 'Honor 1.5', 0, 1, 1504505147, '::1', 0, 0, '', 0, 0, '', 'active', 0),
(5, '41eb0b82pu96ad2g6qnda394f3d14e962cb899cb', 'Army Rum', 0, 1, 1506497432, '103.25.77.145', 0, 0, '', 0, 0, '', 'active', 0),
(6, '52d71c80xd0587nqxm3be020ca992756b019f180', 'Export Rum', 0, 1, 1506497439, '103.25.77.145', 0, 0, '', 0, 0, '', 'active', 0),
(7, '4ff920ano9954am212ub51425da690c48a86ea2b', 'Mandalay Rum', 0, 1, 1506497446, '103.25.77.145', 0, 0, '', 0, 0, '', 'active', 0),
(8, '6c47f0ah0v1c97acvx353c9e879d3840486172da', 'Roofing', 1, 1, 1510374445, '103.197.196.17', 0, 0, '', 0, 0, '', 'active', 0),
(9, '1bbc5e1ndo944eu80bgad9e66b56afded4d3ee55', 'GI', 1, 1, 1510387336, '103.197.196.17', 0, 0, '', 0, 0, '', 'active', 0),
(10, 'aa0e940ehc20ecafqej5ceaa8286affa39417df2', 'C Channel', 1, 1, 1510548168, '103.197.196.40', 0, 0, '', 0, 0, '', 'active', 0),
(11, '74cfbe4z8i83fbr4qs0b4a4258c8e479fafc4bae', 'Raw Coin', 1, 1, 1512557965, '103.197.196.15', 0, 0, '', 0, 0, '', 'active', 0),
(12, '72753c5iw20aa6ki57s14ed56285b1718addfc51', 'Coin', 1, 1, 1513313200, '203.81.163.231', 0, 0, '', 0, 0, '', 'active', 0),
(13, '1bedf66bg0f536hcjxw8de450c9f42683bb1a4eb', 'OOP', 1, 1, 1513746898, '103.197.196.6', 0, 0, '', 0, 0, '', 'active', 0),
(14, '9219a44vdmd42ayfo3od079b041aaec95033baf8', 'Test Category name', 1, 1, 1514867216, '103.197.196.14', 0, 0, '', 0, 0, '', 'active', 0),
(15, '51e4ab96xna4acbxhd92248f82edb1fb9682f337', 'Raw Material (test)', 1, 1, 1514867550, '103.197.196.14', 0, 0, '', 0, 0, '', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_colours`
--

CREATE TABLE `product_colours` (
  `product_colour_id` int(11) NOT NULL,
  `product_colour_uniq_id` varchar(100) NOT NULL,
  `product_colour_name` varchar(80) NOT NULL,
  `product_colour_company_id` int(11) NOT NULL,
  `product_colour_added_by` int(11) NOT NULL,
  `product_colour_added_on` int(11) NOT NULL,
  `product_colour_added_ip` varchar(20) NOT NULL,
  `product_colour_modified_by` int(11) NOT NULL,
  `product_colour_modified_on` int(11) NOT NULL,
  `product_colour_modified_ip` varchar(20) NOT NULL,
  `product_colour_deleted_by` int(11) NOT NULL,
  `product_colour_deleted_on` int(11) NOT NULL,
  `product_colour_deleted_ip` varchar(20) NOT NULL,
  `product_colour_active_status` varchar(20) NOT NULL DEFAULT 'active',
  `product_colour_deleted_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_colours`
--

INSERT INTO `product_colours` (`product_colour_id`, `product_colour_uniq_id`, `product_colour_name`, `product_colour_company_id`, `product_colour_added_by`, `product_colour_added_on`, `product_colour_added_ip`, `product_colour_modified_by`, `product_colour_modified_on`, `product_colour_modified_ip`, `product_colour_deleted_by`, `product_colour_deleted_on`, `product_colour_deleted_ip`, `product_colour_active_status`, `product_colour_deleted_status`) VALUES
(1, '46a82acw1d55cefnp6a966da448bb75c3282a4df', 'Red', 0, 1, 1507105939, '::1', 0, 0, '', 0, 0, '', 'active', 0),
(2, '99a0669p1n0eb2a1lesa74e002201a53cc6c090a', 'Sea Blue', 1, 1, 1513402071, '203.81.163.238', 0, 0, '', 0, 0, '', 'active', 0),
(3, '909aa1aoqm7e1dj1o2lb82ac5303cbe7da1d1357', 'Show White', 1, 1, 1513402080, '203.81.163.238', 0, 0, '', 0, 0, '', 'active', 0),
(4, 'd6203a9clmbcb991gye69bfc4f8ecbe02c402d78', 'Gray', 1, 1, 1513402107, '203.81.71.134', 0, 0, '', 0, 0, '', 'active', 0),
(5, '3c15b319mmea58gfjp76082362332637d7bc3467', 'blue', 1, 1, 1513402125, '203.81.71.134', 0, 0, '', 0, 0, '', 'active', 0),
(6, 'bdfc30etrpe89ci98jn99a014f1fcab176058bf6', 'Black', 1, 1, 1513402140, '203.81.71.134', 0, 0, '', 0, 0, '', 'active', 0),
(7, '8b8de1cw9b88datnpi29e49af391a1e8ddfb1e84', 'green', 1, 1, 1513402165, '203.81.71.134', 0, 0, '', 0, 0, '', 'active', 0),
(8, '06f9496a490889uza1nc4d48c6044302bc558aff', 'Pink', 1, 1, 1513746759, '103.197.196.6', 0, 0, '', 0, 0, '', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_con_entry`
--

CREATE TABLE `product_con_entry` (
  `product_con_entry_id` int(11) NOT NULL,
  `product_con_entry_uniq_id` varchar(255) NOT NULL,
  `product_con_entry_no` varchar(30) NOT NULL,
  `product_con_entry_date` date NOT NULL,
  `product_con_entry_godown_id` int(11) NOT NULL,
  `product_con_entry_invoice_entry_id` int(11) NOT NULL,
  `product_con_entry_child_length_feet_tot` decimal(12,4) NOT NULL,
  `product_con_entry_company_id` int(11) NOT NULL,
  `product_con_entry_branch_id` int(11) NOT NULL,
  `product_con_entry_financial_year` int(11) NOT NULL,
  `product_con_entry_added_by` int(11) NOT NULL,
  `product_con_entry_added_on` int(11) NOT NULL,
  `product_con_entry_added_ip` varchar(20) NOT NULL,
  `product_con_entry_modified_by` int(11) NOT NULL,
  `product_con_entry_modified_on` int(11) NOT NULL,
  `product_con_entry_modified_ip` varchar(20) NOT NULL,
  `product_con_entry_deleted_by` int(11) NOT NULL,
  `product_con_entry_deleted_on` int(11) NOT NULL,
  `product_con_entry_deleted_ip` varchar(20) NOT NULL,
  `product_con_entry_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_con_entry`
--

INSERT INTO `product_con_entry` (`product_con_entry_id`, `product_con_entry_uniq_id`, `product_con_entry_no`, `product_con_entry_date`, `product_con_entry_godown_id`, `product_con_entry_invoice_entry_id`, `product_con_entry_child_length_feet_tot`, `product_con_entry_company_id`, `product_con_entry_branch_id`, `product_con_entry_financial_year`, `product_con_entry_added_by`, `product_con_entry_added_on`, `product_con_entry_added_ip`, `product_con_entry_modified_by`, `product_con_entry_modified_on`, `product_con_entry_modified_ip`, `product_con_entry_deleted_by`, `product_con_entry_deleted_on`, `product_con_entry_deleted_ip`, `product_con_entry_deleted_status`) VALUES
(1, 'aeb0dcc4oydbff6kzw3aec272b9e3edb97d4a14c', 'PC1312', '2017-12-13', 1, 2, '100.0000', 1, 1, 1, 1, 1513144689, '103.197.196.27', 0, 0, '', 0, 0, '', 0),
(2, '3acd56c8y4c398pinn98686166acc3bcf7df1315', 'product coin 99', '2017-12-13', 1, 2, '1000.0000', 1, 1, 1, 1, 1513145041, '103.197.196.27', 1, 1513145150, '103.197.196.27', 0, 0, '', 0),
(3, '4ecc8b46n46b04qj9uye326ad4b65fcabf5f474c', 'PC1412', '2017-12-14', 1, 4, '1000.0000', 1, 1, 1, 1, 1513238204, '103.197.196.20', 0, 0, '', 0, 0, '', 0),
(4, '4c12523kj3064aokopg44b056d0beb20bbf0b949', '9898test', '2017-12-15', 1, 6, '1000.0000', 1, 1, 1, 1, 1513329929, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(5, '22e6b1eo7je50acm7js5b9201eee45b9a76f5068', 'pct01', '2017-12-16', 1, 8, '100.0000', 1, 1, 1, 1, 1513394013, '203.81.163.238', 0, 0, '', 0, 0, '', 0),
(6, 'e4786b3y4ta1ddt5j1af89c56fc10fe54768245d', 'Product Coin 0000001', '2017-12-16', 1, 9, '1000.0000', 1, 1, 1, 1, 1513399487, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(7, '620e31ezad19603tafrd61f6adb7329dc83ac077', '99009900', '2017-12-17', 1, 11, '39138.0000', 1, 1, 1, 1, 1513403111, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(8, '74fc221xooc94ft75awb13475495fd75b2876427', 'PC161201', '2017-12-16', 2, 12, '10.0000', 1, 1, 1, 1, 1513408085, '203.81.71.134', 0, 0, '', 0, 0, '', 0),
(9, '16e2436wstb4b64q84ae33da3da86d38b8c27043', '9121', '2017-12-16', 2, 12, '10.0000', 1, 1, 1, 1, 1513408193, '103.242.98.48', 0, 0, '', 0, 0, '', 0),
(10, '514f253vu2169d3y1nt772f7fd5063c11aeb498a', 'pc', '2017-12-16', 1, 13, '0.0000', 1, 1, 1, 1, 1513408585, '203.81.71.134', 0, 0, '', 0, 0, '', 0),
(11, '43023bcvp341e966dl862d6e86b5d49779548036', '121', '2017-12-16', 1, 13, '1000.0000', 1, 1, 1, 1, 1513411352, '203.81.71.134', 1, 1513411386, '203.81.71.134', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_con_entry_child_product_details`
--

CREATE TABLE `product_con_entry_child_product_details` (
  `product_con_entry_child_product_detail_id` int(11) NOT NULL,
  `product_con_entry_child_product_detail_uniq_id` varchar(255) NOT NULL,
  `product_con_entry_child_product_detail_product_con_entry_id` int(11) NOT NULL,
  `product_con_entry_child_product_detail_product_id` int(11) NOT NULL,
  `product_con_entry_child_product_detail_code` varchar(255) NOT NULL,
  `product_con_entry_child_product_detail_name` varchar(255) NOT NULL,
  `product_con_entry_child_product_detail_color_id` int(11) NOT NULL,
  `product_con_entry_child_product_detail_thick_ness` decimal(11,0) NOT NULL,
  `product_con_entry_child_product_detail_width_inches` decimal(20,4) NOT NULL,
  `product_con_entry_child_product_detail_width_mm` decimal(20,4) NOT NULL,
  `product_con_entry_child_product_detail_length_mm` decimal(20,4) NOT NULL,
  `product_con_entry_child_product_detail_length_feet` decimal(20,4) NOT NULL,
  `product_con_entry_child_product_detail_total` decimal(20,4) NOT NULL,
  `product_con_entry_child_product_detail_ton_qty` decimal(12,2) NOT NULL,
  `product_con_entry_child_product_detail_kg_qty` decimal(12,2) NOT NULL,
  `product_con_entry_child_product_detail_uom_id` int(11) NOT NULL,
  `product_con_entry_child_product_detail_con_width_inches` decimal(20,4) NOT NULL,
  `product_con_entry_child_product_detail_con_width_mm` decimal(20,4) NOT NULL,
  `product_con_entry_child_product_detail_con_length_feet` decimal(20,4) NOT NULL,
  `product_con_entry_child_product_detail_con_length_mm` decimal(20,4) NOT NULL,
  `product_con_entry_child_product_detail_con_tone` decimal(20,4) NOT NULL,
  `product_con_entry_child_product_detail_invoice_entry_id` int(11) NOT NULL,
  `product_con_entry_child_product_detail_invoice_detail_id` int(11) NOT NULL,
  `product_con_entry_child_product_detail_type` int(11) NOT NULL DEFAULT '1',
  `product_con_entry_child_product_detail_company_id` int(11) NOT NULL,
  `product_con_entry_child_product_detail_branch_id` int(11) NOT NULL,
  `product_con_entry_child_product_detail_financial_year` varchar(20) NOT NULL,
  `product_con_entry_child_product_detail_added_by` int(11) NOT NULL,
  `product_con_entry_child_product_detail_added_on` int(11) NOT NULL,
  `product_con_entry_child_product_detail_added_ip` varchar(20) NOT NULL,
  `product_con_entry_child_product_detail_modified_by` int(11) NOT NULL,
  `product_con_entry_child_product_detail_modified_on` int(11) NOT NULL,
  `product_con_entry_child_product_detail_modified_ip` varchar(20) NOT NULL,
  `product_con_entry_child_product_detail_deleted_by` int(11) NOT NULL,
  `product_con_entry_child_product_detail_deleted_on` int(11) NOT NULL,
  `product_con_entry_child_product_detail_deleted_ip` varchar(20) NOT NULL,
  `product_con_entry_child_product_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_con_entry_child_product_details`
--

INSERT INTO `product_con_entry_child_product_details` (`product_con_entry_child_product_detail_id`, `product_con_entry_child_product_detail_uniq_id`, `product_con_entry_child_product_detail_product_con_entry_id`, `product_con_entry_child_product_detail_product_id`, `product_con_entry_child_product_detail_code`, `product_con_entry_child_product_detail_name`, `product_con_entry_child_product_detail_color_id`, `product_con_entry_child_product_detail_thick_ness`, `product_con_entry_child_product_detail_width_inches`, `product_con_entry_child_product_detail_width_mm`, `product_con_entry_child_product_detail_length_mm`, `product_con_entry_child_product_detail_length_feet`, `product_con_entry_child_product_detail_total`, `product_con_entry_child_product_detail_ton_qty`, `product_con_entry_child_product_detail_kg_qty`, `product_con_entry_child_product_detail_uom_id`, `product_con_entry_child_product_detail_con_width_inches`, `product_con_entry_child_product_detail_con_width_mm`, `product_con_entry_child_product_detail_con_length_feet`, `product_con_entry_child_product_detail_con_length_mm`, `product_con_entry_child_product_detail_con_tone`, `product_con_entry_child_product_detail_invoice_entry_id`, `product_con_entry_child_product_detail_invoice_detail_id`, `product_con_entry_child_product_detail_type`, `product_con_entry_child_product_detail_company_id`, `product_con_entry_child_product_detail_branch_id`, `product_con_entry_child_product_detail_financial_year`, `product_con_entry_child_product_detail_added_by`, `product_con_entry_child_product_detail_added_on`, `product_con_entry_child_product_detail_added_ip`, `product_con_entry_child_product_detail_modified_by`, `product_con_entry_child_product_detail_modified_on`, `product_con_entry_child_product_detail_modified_ip`, `product_con_entry_child_product_detail_deleted_by`, `product_con_entry_child_product_detail_deleted_on`, `product_con_entry_child_product_detail_deleted_ip`, `product_con_entry_child_product_detail_deleted_status`) VALUES
(5, '130c19f06q3a786qvv4ab86ae8ba34e11d9d74ca', 2, 7, 'CH00001', 'C channel1 Red 1mm', 4, '1', '10.0000', '254.0000', '76200.0000', '250.0000', '0.0000', '1.00', '100.00', 2, '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', 0, 0, 1, 0, 0, '', 1, 1514985401, '122.174.33.217', 0, 0, '', 0, 0, '', 0),
(6, '8d5286b4hv614eusff8f78ff9cf95ea3a3087615', 2, 7, 'CH00002', 'C channel1 Red 1mm', 7, '2', '20.0000', '508.0000', '152400.0000', '500.0000', '0.0000', '2.00', '300.00', 5, '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', 0, 0, 1, 0, 0, '', 1, 1514985401, '122.174.33.217', 0, 0, '', 0, 0, '', 0),
(7, 'a7de8a4sgaaf4640uvtca19e989d1f9e6edab5ff', 3, 4, 'CH00001', 'PPGI 1', 6, '1', '36.0000', '914.4000', '304800.0000', '1000.0000', '0.0000', '1500.00', '0.00', 3, '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', 0, 0, 1, 0, 0, '', 1, 1515041361, '103.197.196.14', 1, 1515041416, '103.197.196.14', 0, 0, '', 0),
(8, 'a74a500u0e51ddl7daj8dbe1f483db3c1b4bbc76', 3, 4, 'CH00002', 'PPGI 1', 6, '2', '48.0000', '1219.2000', '304800.0000', '1000.0000', '0.0000', '500.00', '0.00', 3, '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', 0, 0, 1, 0, 0, '', 1, 1515041361, '103.197.196.14', 1, 1515041416, '103.197.196.14', 0, 0, '', 0),
(9, 'd705687ve7ad08niyoz61215773ca773b2666a24', 3, 6, 'CH00001', 'Raw GI', 0, '2', '36.0000', '914.4000', '457200.0000', '1500.0000', '0.0000', '1500.00', '0.00', 3, '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', 0, 0, 1, 0, 0, '', 1, 1515041361, '103.197.196.14', 1, 1515041416, '103.197.196.14', 0, 0, '', 0),
(10, 'cf72bfexs430admh5f97ff10428283be4b84d285', 3, 6, 'CH00002', 'Raw GI', 0, '1', '54.0000', '1371.6000', '457200.0000', '1500.0000', '0.0000', '1500.00', '0.00', 3, '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', 0, 0, 1, 0, 0, '', 1, 1515041361, '103.197.196.14', 1, 1515041416, '103.197.196.14', 0, 0, '', 0),
(11, 'd2a6955p1ge47e20l724135354cfab81d2242f0e', 5, 16, 'CH00001', 'GIPP Coin 1', 5, '2', '45.0000', '1143.0000', '1524000.0000', '5000.0000', '0.0000', '5000.00', '0.00', 3, '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', 0, 0, 1, 0, 0, '', 1, 1515047653, '103.197.196.14', 1, 1515047677, '103.197.196.14', 0, 0, '', 0),
(12, '01dbfaajudfc998ny2l97ed09046fa280fc86d1f', 5, 16, 'CH00002', 'GIPP Coin 1', 5, '3', '36.0000', '914.4000', '1524000.0000', '5000.0000', '0.0000', '5000.00', '0.00', 3, '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', 0, 0, 1, 0, 0, '', 1, 1515047653, '103.197.196.14', 1, 1515047677, '103.197.196.14', 0, 0, '', 0),
(13, 'a5feebb6ylc6e0x9e6b1bdb597322a44776d83b5', 6, 4, 'CH00001', 'PPGI 1', 6, '1', '36.0000', '914.4000', '152400.0000', '500.0000', '0.0000', '500.00', '0.00', 3, '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', 0, 0, 1, 0, 0, '', 1, 1515126441, '103.197.196.24', 1, 1515126482, '103.197.196.24', 0, 0, '', 0),
(14, 'f0df549b3t43f9kb9ezd0ff4cbf16b68d25f76c9', 6, 4, 'CH00002', 'PPGI 1', 5, '2', '36.0000', '914.4000', '152400.0000', '500.0000', '0.0000', '500.00', '0.00', 3, '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', 0, 0, 1, 0, 0, '', 1, 1515126441, '103.197.196.24', 1, 1515126482, '103.197.196.24', 0, 0, '', 0),
(15, 'f258fa9gqzcb5dah6zi7714eab8c32bffb854ef2', 6, 9, 'CH00001', 'GI_Test_02', 0, '3', '45.0000', '1143.0000', '152400.0000', '500.0000', '0.0000', '500.00', '0.00', 3, '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', 0, 0, 1, 0, 0, '', 1, 1515126441, '103.197.196.24', 1, 1515126482, '103.197.196.24', 0, 0, '', 0),
(16, '7283e61ibx3d0bueg7lefe0431d27311a1075628', 6, 9, 'CH00002', 'GI_Test_02', 0, '3', '54.0000', '1371.6000', '152400.0000', '500.0000', '0.0000', '500.00', '0.00', 3, '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', 0, 0, 1, 0, 0, '', 1, 1515126441, '103.197.196.24', 1, 1515126482, '103.197.196.24', 0, 0, '', 0),
(17, '51a2165esi1a67o7ozi292e9f41dcc9df4258a3f', 6, 23, 'CH00001', 'Other Mother Coin', 5, '2', '36.0000', '914.4000', '304800.0000', '1000.0000', '0.0000', '1000.00', '0.00', 3, '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', 0, 0, 1, 0, 0, '', 1, 1515126441, '103.197.196.24', 1, 1515126482, '103.197.196.24', 0, 0, '', 0),
(18, '0ee17c5rt2261a33g2j46fe25bd46d258b2f288d', 6, 23, 'CH00002', 'Other Mother Coin', 5, '2', '36.0000', '914.4000', '304800.0000', '1000.0000', '0.0000', '1000.00', '0.00', 3, '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', 0, 0, 1, 0, 0, '', 1, 1515126441, '103.197.196.24', 1, 1515126482, '103.197.196.24', 0, 0, '', 0),
(19, 'ef30b25fdk2c03o6f8b4988a4bff3b0905258ec5', 8, 28, 'CH00001', 'LT', 2, '1', '36.0000', '914.4000', '30480.0000', '100.0000', '0.0000', '35.00', '5250.00', 3, '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', 0, 0, 1, 0, 0, '', 1, 1515128524, '103.197.196.24', 1, 1515128574, '103.197.196.24', 0, 0, '', 0),
(20, 'e12eff95cs0647arc0397fa31e64ee537e8df199', 8, 28, 'CH00002', 'LT', 5, '1', '36.0000', '914.4000', '30480.0000', '100.0000', '0.0000', '35.00', '5250.00', 3, '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', 0, 0, 1, 0, 0, '', 1, 1515128524, '103.197.196.24', 1, 1515128574, '103.197.196.24', 0, 0, '', 0),
(21, '185ab1cwinf146jzenf054cf3c8e272f2d2fb349', 8, 28, 'CH00003', 'LT', 1, '1', '36.0000', '914.4000', '27432.0000', '90.0000', '0.0000', '30.00', '4500.00', 3, '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', 0, 0, 1, 0, 0, '', 1, 1515128524, '103.197.196.24', 1, 1515128574, '103.197.196.24', 0, 0, '', 0),
(22, 'ad0acc9fzh3ac6d438q8bf27bc5dc9fab7ab13c0', 9, 4, 'CH00001', 'PPGI 1', 1, '1', '36.0000', '914.4000', '30480.0000', '100.0000', '0.0000', '0.00', '0.00', 3, '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', 0, 0, 1, 0, 0, '', 1, 1515129345, '103.197.196.24', 0, 0, '', 0, 0, '', 0),
(23, '9a5957a0vveeca2d9dcfa28cef264d6b35642a8c', 9, 4, 'CH00002', 'PPGI 1', 7, '1', '36.0000', '914.4000', '30480.0000', '100.0000', '0.0000', '10.00', '0.00', 3, '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', 0, 0, 1, 0, 0, '', 1, 1515129345, '103.197.196.24', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_con_entry_product_details`
--

CREATE TABLE `product_con_entry_product_details` (
  `product_con_entry_product_detail_id` int(11) NOT NULL,
  `product_con_entry_product_detail_uniq_id` varchar(255) NOT NULL,
  `product_con_entry_product_detail_product_con_entry_id` int(11) NOT NULL,
  `product_con_entry_product_detail_product_id` int(11) NOT NULL,
  `product_con_entry_product_detail_width_inches` decimal(20,4) NOT NULL,
  `product_con_entry_product_detail_width_mm` decimal(20,4) NOT NULL,
  `product_con_entry_product_detail_length_mm` decimal(20,4) NOT NULL,
  `product_con_entry_product_detail_length_feet` decimal(20,4) NOT NULL,
  `product_con_entry_product_detail_qty` decimal(20,4) NOT NULL,
  `product_con_entry_product_detail_total_qty` decimal(20,4) NOT NULL,
  `product_con_entry_product_detail_invoice_entry_id` int(11) NOT NULL,
  `product_con_entry_product_detail_invoice_detail_id` int(11) NOT NULL,
  `product_con_entry_product_detail_company_id` int(11) NOT NULL,
  `product_con_entry_product_detail_branch_id` int(11) NOT NULL,
  `product_con_entry_product_detail_financial_year` varchar(20) NOT NULL,
  `product_con_entry_product_detail_added_by` int(11) NOT NULL,
  `product_con_entry_product_detail_added_on` int(11) NOT NULL,
  `product_con_entry_product_detail_added_ip` varchar(20) NOT NULL,
  `product_con_entry_product_detail_modified_by` int(11) NOT NULL,
  `product_con_entry_product_detail_modified_on` int(11) NOT NULL,
  `product_con_entry_product_detail_modified_ip` varchar(20) NOT NULL,
  `product_con_entry_product_detail_deleted_by` int(11) NOT NULL,
  `product_con_entry_product_detail_deleted_on` int(11) NOT NULL,
  `product_con_entry_product_detail_deleted_ip` varchar(20) NOT NULL,
  `product_con_entry_product_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_con_entry_product_details`
--

INSERT INTO `product_con_entry_product_details` (`product_con_entry_product_detail_id`, `product_con_entry_product_detail_uniq_id`, `product_con_entry_product_detail_product_con_entry_id`, `product_con_entry_product_detail_product_id`, `product_con_entry_product_detail_width_inches`, `product_con_entry_product_detail_width_mm`, `product_con_entry_product_detail_length_mm`, `product_con_entry_product_detail_length_feet`, `product_con_entry_product_detail_qty`, `product_con_entry_product_detail_total_qty`, `product_con_entry_product_detail_invoice_entry_id`, `product_con_entry_product_detail_invoice_detail_id`, `product_con_entry_product_detail_company_id`, `product_con_entry_product_detail_branch_id`, `product_con_entry_product_detail_financial_year`, `product_con_entry_product_detail_added_by`, `product_con_entry_product_detail_added_on`, `product_con_entry_product_detail_added_ip`, `product_con_entry_product_detail_modified_by`, `product_con_entry_product_detail_modified_on`, `product_con_entry_product_detail_modified_ip`, `product_con_entry_product_detail_deleted_by`, `product_con_entry_product_detail_deleted_on`, `product_con_entry_product_detail_deleted_ip`, `product_con_entry_product_detail_deleted_status`) VALUES
(1, '07d830ejcu3cfdyi3vx28edbaa1333483cc9e0eb', 1, 14, '36.0000', '914.4000', '30480.0000', '100.0000', '1000.0000', '2.0000', 2, 2, 0, 0, '', 1, 1513144689, '103.197.196.27', 0, 0, '', 0, 0, '', 0),
(2, '84ed5f2n6u960ap6srsf8c13cf889b24a94d09f0', 2, 14, '36.0000', '914.4000', '304800.0000', '1000.0000', '1000.0000', '5.0000', 2, 2, 0, 0, '', 1, 1513145041, '103.197.196.27', 1, 1513145150, '103.197.196.27', 0, 0, '', 0),
(3, '45974cfkws6905yp7ym2882bf08539bce3ff5585', 3, 4, '36.0000', '914.4000', '304800.0000', '1000.0000', '1000.0000', '3.0000', 4, 4, 0, 0, '', 1, 1513238205, '103.197.196.20', 0, 0, '', 0, 0, '', 0),
(4, '4b61d16wb8ff80mwhwq93889a2a01cf73c3eb486', 4, 23, '36.0000', '914.4000', '304800.0000', '1000.0000', '100.0000', '2.0000', 6, 6, 0, 0, '', 1, 1513329929, '203.81.163.246', 0, 0, '', 0, 0, '', 0),
(5, '89bcbccj4109717nlnhdb575000ed97fe67b7b24', 5, 11, '36.0000', '914.4000', '30480.0000', '100.0000', '1000.0000', '2.0000', 8, 8, 0, 0, '', 1, 1513394013, '203.81.163.238', 0, 0, '', 0, 0, '', 0),
(6, '36e0103sb8d8901d919f256d50f409ffefde56bd', 6, 21, '36.0000', '914.4000', '304800.0000', '1000.0000', '1000.0000', '5.0000', 9, 9, 0, 0, '', 1, 1513399487, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(7, '11647f3s4j5befrmh0h36174b2b96f44146e8b70', 7, 28, '36.0000', '914.4000', '11930481.6000', '39142.0000', '27.0000', '6.0000', 11, 12, 0, 0, '', 1, 1513403111, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(8, 'f386247dqnce92fsjk2f7f4435635258d1ea144b', 8, 4, '36.0000', '914.4000', '3048.0000', '10.0000', '1000.0000', '1.0000', 12, 13, 0, 0, '', 1, 1513408085, '203.81.71.134', 0, 0, '', 0, 0, '', 0),
(9, '36266142lr44bcbzhrma1ba1ee780493e330ed01', 9, 4, '36.0000', '914.4000', '3048.0000', '10.0000', '1000.0000', '1.0000', 12, 13, 0, 0, '', 1, 1513408193, '103.242.98.48', 0, 0, '', 0, 0, '', 0),
(10, '48e99bcul2fc2d2mgh286d9c1e514f46be1a28c3', 10, 4, '36.0000', '914.4000', '3048.0000', '10.0000', '10.0000', '1.0000', 13, 14, 0, 0, '', 1, 1513408585, '203.81.71.134', 0, 0, '', 0, 0, '', 0),
(11, '47e3f9a1hj4623kmea6611cd51db34b67ede4d26', 11, 4, '36.0000', '914.4000', '304800.0000', '1000.0000', '1000.0000', '1.0000', 13, 14, 0, 0, '', 1, 1513411352, '203.81.71.134', 1, 1513411386, '203.81.71.134', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_details`
--

CREATE TABLE `product_details` (
  `product_detail_id` int(11) NOT NULL,
  `product_detail_product_id` int(11) NOT NULL,
  `product_detail_raw_product_id` int(11) NOT NULL,
  `product_detail_added_by` int(11) NOT NULL,
  `product_detail_added_on` int(11) NOT NULL,
  `product_detail_added_ip` varchar(20) NOT NULL,
  `product_detail_modified_by` int(11) NOT NULL,
  `product_detail_modified_on` int(11) NOT NULL,
  `product_detail_modified_ip` varchar(20) NOT NULL,
  `product_detail_deleted_by` int(11) NOT NULL,
  `product_detail_deleted_on` int(11) NOT NULL,
  `product_detail_deleted_ip` int(20) NOT NULL,
  `product_detail_deleted_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_details`
--

INSERT INTO `product_details` (`product_detail_id`, `product_detail_product_id`, `product_detail_raw_product_id`, `product_detail_added_by`, `product_detail_added_on`, `product_detail_added_ip`, `product_detail_modified_by`, `product_detail_modified_on`, `product_detail_modified_ip`, `product_detail_deleted_by`, `product_detail_deleted_on`, `product_detail_deleted_ip`, `product_detail_deleted_status`) VALUES
(1, 1, 2, 1, 1507521103, '', 1, 1507547348, '', 0, 0, 0, 0),
(2, 1, 3, 1, 1507546934, '', 1, 1507547348, '', 0, 0, 0, 0),
(3, 5, 4, 1, 1510375815, '103.197.196.17', 1, 1513403450, '', 0, 0, 0, 0),
(4, 0, 4, 1, 1510548491, '103.197.196.40', 0, 0, '', 0, 0, 0, 0),
(5, 0, 4, 1, 1510548625, '103.197.196.40', 0, 0, '', 0, 0, 0, 0),
(6, 7, 6, 1, 1510984703, '74.50.213.41', 1, 1513390016, '', 0, 0, 0, 0),
(7, 9, 8, 1, 1510989400, '103.197.196.40', 1, 1510990041, '', 0, 0, 0, 0),
(8, 13, 6, 1, 1512800575, '103.197.196.14', 1, 1513390209, '', 0, 0, 0, 0),
(9, 24, 23, 1, 1513326611, '', 0, 0, '', 0, 0, 0, 0),
(10, 4, 11, 1, 1513332325, '', 1, 1513403398, '', 0, 0, 0, 0),
(11, 18, 21, 1, 1513390157, '', 0, 0, '', 0, 0, 0, 0),
(12, 13, 4, 1, 1513390208, '', 0, 0, '', 0, 0, 0, 0),
(13, 13, 4, 1, 1513390209, '', 0, 0, '', 0, 0, 0, 0),
(14, 12, 4, 1, 1513390250, '', 0, 0, '', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_status`
--

CREATE TABLE `product_status` (
  `product_status_id` int(11) NOT NULL,
  `product_status_uniq_id` varchar(100) NOT NULL,
  `product_status_name` varchar(80) NOT NULL,
  `product_status_company_id` int(11) NOT NULL,
  `product_status_added_by` int(11) NOT NULL,
  `product_status_added_on` int(11) NOT NULL,
  `product_status_added_ip` varchar(20) NOT NULL,
  `product_status_modified_by` int(11) NOT NULL,
  `product_status_modified_on` int(11) NOT NULL,
  `product_status_modified_ip` varchar(20) NOT NULL,
  `product_status_deleted_by` int(11) NOT NULL,
  `product_status_deleted_on` int(11) NOT NULL,
  `product_status_deleted_ip` varchar(20) NOT NULL,
  `product_status_active_status` varchar(20) NOT NULL DEFAULT 'active',
  `product_status_deleted_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_status`
--

INSERT INTO `product_status` (`product_status_id`, `product_status_uniq_id`, `product_status_name`, `product_status_company_id`, `product_status_added_by`, `product_status_added_on`, `product_status_added_ip`, `product_status_modified_by`, `product_status_modified_on`, `product_status_modified_ip`, `product_status_deleted_by`, `product_status_deleted_on`, `product_status_deleted_ip`, `product_status_active_status`, `product_status_deleted_status`) VALUES
(1, '321d8de9se31c984s3kcc1c204a141708369a485', 'teasdas', 0, 1, 1509182385, '192.168.1.5', 0, 0, '', 1, 1509182755, '192.168.1.5', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_uoms`
--

CREATE TABLE `product_uoms` (
  `product_uom_id` int(11) NOT NULL,
  `product_uom_uniq_id` varchar(100) NOT NULL,
  `product_uom_name` varchar(80) NOT NULL,
  `product_uom_company_id` int(11) NOT NULL,
  `product_uom_added_by` int(11) NOT NULL,
  `product_uom_added_on` int(11) NOT NULL,
  `product_uom_added_ip` varchar(20) NOT NULL,
  `product_uom_modified_by` int(11) NOT NULL,
  `product_uom_modified_on` int(11) NOT NULL,
  `product_uom_modified_ip` varchar(20) NOT NULL,
  `product_uom_deleted_by` int(11) NOT NULL,
  `product_uom_deleted_on` int(11) NOT NULL,
  `product_uom_deleted_ip` varchar(20) NOT NULL,
  `product_uom_active_status` varchar(20) NOT NULL DEFAULT 'active',
  `product_uom_deleted_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_uoms`
--

INSERT INTO `product_uoms` (`product_uom_id`, `product_uom_uniq_id`, `product_uom_name`, `product_uom_company_id`, `product_uom_added_by`, `product_uom_added_on`, `product_uom_added_ip`, `product_uom_modified_by`, `product_uom_modified_on`, `product_uom_modified_ip`, `product_uom_deleted_by`, `product_uom_deleted_on`, `product_uom_deleted_ip`, `product_uom_active_status`, `product_uom_deleted_status`) VALUES
(1, '4094fb2j1f16c721cfyad2307e1d86e1f504966b', 'Pcs', 0, 1, 1504505162, '::1', 0, 0, '', 0, 0, '', 'active', 0),
(2, 'f1cb5d8gccf4790kckb1e8af145956c94a54eb7b', 'Cotton Box', 0, 1, 1504505174, '::1', 0, 0, '', 0, 0, '', 'active', 0),
(3, 'c2d7fed3zj81692aajle7aff84629f32d10cdd9e', 'Ton', 1, 1, 1510375119, '103.197.196.17', 1, 1510801582, '', 0, 0, '', 'active', 0),
(4, '3a4ed7ctew46b65nkuqa49e2da530aff52c6b314', 'Ton', 1, 1, 1510387413, '103.197.196.17', 0, 0, '', 0, 0, '', 'active', 0),
(5, '5ce8f25993380cgeg1m4d5a8c53b2a74318091d3', 'Feet', 1, 1, 1510989247, '103.197.196.40', 0, 0, '', 0, 0, '', 'active', 0),
(6, 'b6913a5g66ed055ofh359230023afe39b24de88b', 'FEET', 1, 1, 1510989254, '103.197.196.40', 0, 0, '', 0, 0, '', 'active', 0),
(7, '9d50e296y59965br6e9eaff801fd0377528a1e5d', 'KG', 1, 1, 1512558001, '103.197.196.15', 0, 0, '', 0, 0, '', 'active', 0),
(8, 'e3db3ccj7vb57a1dqql7a30e3953c82cc86b2f13', 'Length', 1, 1, 1513746932, '103.197.196.6', 0, 0, '', 0, 0, '', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_weight_cals`
--

CREATE TABLE `product_weight_cals` (
  `pwc_id` int(11) NOT NULL,
  `pwc_uniq_id` varchar(100) NOT NULL,
  `pwc_product_id` int(11) NOT NULL,
  `pwc_thick_ness` int(11) NOT NULL,
  `pwc_type` int(11) NOT NULL,
  `pwc_weight` decimal(12,2) NOT NULL,
  `pwc_company_id` int(11) NOT NULL,
  `pwc_added_by` int(11) NOT NULL,
  `pwc_added_on` int(11) NOT NULL,
  `pwc_added_ip` varchar(20) NOT NULL,
  `pwc_modified_by` int(11) NOT NULL,
  `pwc_modified_on` int(11) NOT NULL,
  `pwc_modified_ip` varchar(20) NOT NULL,
  `pwc_deleted_by` int(11) NOT NULL,
  `pwc_deleted_on` int(11) NOT NULL,
  `pwc_deleted_ip` varchar(20) NOT NULL,
  `pwc_active_status` varchar(20) NOT NULL DEFAULT 'active',
  `pwc_deleted_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_weight_cals`
--

INSERT INTO `product_weight_cals` (`pwc_id`, `pwc_uniq_id`, `pwc_product_id`, `pwc_thick_ness`, `pwc_type`, `pwc_weight`, `pwc_company_id`, `pwc_added_by`, `pwc_added_on`, `pwc_added_ip`, `pwc_modified_by`, `pwc_modified_on`, `pwc_modified_ip`, `pwc_deleted_by`, `pwc_deleted_on`, `pwc_deleted_ip`, `pwc_active_status`, `pwc_deleted_status`) VALUES
(1, 'be154ff1300733xz9cc1c943ba9e182de3f004a9', 28, 1, 1, '150.00', 1, 1, 1514981414, '122.174.33.217', 0, 0, '', 0, 0, '', 'active', 0),
(2, 'b6d4801xr3fbf0nqgwi44ce32f90ccb7988266e3', 7, 1, 1, '100.00', 1, 1, 1514983335, '122.174.33.217', 0, 0, '', 0, 0, '', 'active', 0),
(3, 'dc77959kru5427pgd3fa927ecc33cc9a8af56ca9', 7, 2, 1, '150.00', 1, 1, 1514983350, '122.174.33.217', 0, 0, '', 0, 0, '', 'active', 0),
(4, 'f73f859n5l5da8v4xyr46ecc9ca8b6911a4702f2', 8, 3, 1, '200.00', 1, 1, 1514983368, '122.174.33.217', 0, 0, '', 0, 0, '', 'active', 0),
(5, '7d33195y24711daesgrc0ad2a3c9c6a9bbcbbeee', 8, 4, 1, '180.00', 1, 1, 1514983384, '122.174.33.217', 0, 0, '', 0, 0, '', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_debit_note`
--

CREATE TABLE `purchase_debit_note` (
  `debitnoteId` int(11) NOT NULL,
  `d_purchaseId` int(11) NOT NULL,
  `d_branchid` int(11) NOT NULL,
  `d_type` int(1) NOT NULL,
  `d_debitdate` date NOT NULL,
  `d_remark` text NOT NULL,
  `d_company_id` int(11) NOT NULL,
  `d_added_by` int(11) NOT NULL,
  `d_added_on` int(11) NOT NULL,
  `d_added_ip` varchar(20) NOT NULL,
  `d_modified_by` int(11) NOT NULL,
  `d_modified_on` datetime NOT NULL,
  `d_modified_ip` varchar(20) NOT NULL,
  `d_deleted_by` int(11) NOT NULL,
  `d_deleted_on` datetime NOT NULL,
  `d_deleted_ip` varchar(20) NOT NULL,
  `d_deleted_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase_debit_note`
--

INSERT INTO `purchase_debit_note` (`debitnoteId`, `d_purchaseId`, `d_branchid`, `d_type`, `d_debitdate`, `d_remark`, `d_company_id`, `d_added_by`, `d_added_on`, `d_added_ip`, `d_modified_by`, `d_modified_on`, `d_modified_ip`, `d_deleted_by`, `d_deleted_on`, `d_deleted_ip`, `d_deleted_status`) VALUES
(1, 4, 4, 1, '2018-01-04', '', 1, 1, 2147483647, '103.197.196.14', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_debit_note_child_products`
--

CREATE TABLE `purchase_debit_note_child_products` (
  `purchase_debit_note_child_product_id` int(11) NOT NULL,
  `purchase_debit_note_child_product_uniq_id` varchar(255) NOT NULL,
  `purchase_debit_note_child_product_grn_id` int(11) NOT NULL,
  `purchase_debit_note_child_product_inv_detail_id` int(11) NOT NULL,
  `purchase_debit_note_child_product_product_id` int(11) NOT NULL,
  `purchase_debit_note_child_product_code` varchar(255) NOT NULL,
  `purchase_debit_note_child_product_name` varchar(255) NOT NULL,
  `purchase_debit_note_child_product_color_id` int(11) NOT NULL,
  `purchase_debit_note_child_product_thick_ness` decimal(12,2) NOT NULL,
  `purchase_debit_note_child_product_width_inches` decimal(20,4) NOT NULL,
  `purchase_debit_note_child_product_width_mm` decimal(20,4) NOT NULL,
  `purchase_debit_note_child_product_length_mm` decimal(20,4) NOT NULL,
  `purchase_debit_note_child_product_length_feet` decimal(20,4) NOT NULL,
  `purchase_debit_note_child_product_ton_qty` decimal(12,2) NOT NULL,
  `purchase_debit_note_child_product_kg_qty` decimal(12,2) NOT NULL,
  `purchase_debit_note_child_product_uom_id` int(11) NOT NULL,
  `purchase_debit_note_child_product_type` int(11) NOT NULL DEFAULT '1',
  `purchase_debit_note_child_product_company_id` int(11) NOT NULL,
  `purchase_debit_note_child_product_branch_id` int(11) NOT NULL,
  `purchase_debit_note_child_product_financial_year` varchar(20) NOT NULL,
  `purchase_debit_note_child_product_added_by` int(11) NOT NULL,
  `purchase_debit_note_child_product_added_on` int(11) NOT NULL,
  `purchase_debit_note_child_product_added_ip` varchar(20) NOT NULL,
  `purchase_debit_note_child_product_modified_by` int(11) NOT NULL,
  `purchase_debit_note_child_product_modified_on` int(11) NOT NULL,
  `purchase_debit_note_child_product_modified_ip` varchar(20) NOT NULL,
  `purchase_debit_note_child_product_deleted_by` int(11) NOT NULL,
  `purchase_debit_note_child_product_deleted_on` int(11) NOT NULL,
  `purchase_debit_note_child_product_deleted_ip` varchar(20) NOT NULL,
  `purchase_debit_note_child_product_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase_debit_note_child_products`
--

INSERT INTO `purchase_debit_note_child_products` (`purchase_debit_note_child_product_id`, `purchase_debit_note_child_product_uniq_id`, `purchase_debit_note_child_product_grn_id`, `purchase_debit_note_child_product_inv_detail_id`, `purchase_debit_note_child_product_product_id`, `purchase_debit_note_child_product_code`, `purchase_debit_note_child_product_name`, `purchase_debit_note_child_product_color_id`, `purchase_debit_note_child_product_thick_ness`, `purchase_debit_note_child_product_width_inches`, `purchase_debit_note_child_product_width_mm`, `purchase_debit_note_child_product_length_mm`, `purchase_debit_note_child_product_length_feet`, `purchase_debit_note_child_product_ton_qty`, `purchase_debit_note_child_product_kg_qty`, `purchase_debit_note_child_product_uom_id`, `purchase_debit_note_child_product_type`, `purchase_debit_note_child_product_company_id`, `purchase_debit_note_child_product_branch_id`, `purchase_debit_note_child_product_financial_year`, `purchase_debit_note_child_product_added_by`, `purchase_debit_note_child_product_added_on`, `purchase_debit_note_child_product_added_ip`, `purchase_debit_note_child_product_modified_by`, `purchase_debit_note_child_product_modified_on`, `purchase_debit_note_child_product_modified_ip`, `purchase_debit_note_child_product_deleted_by`, `purchase_debit_note_child_product_deleted_on`, `purchase_debit_note_child_product_deleted_ip`, `purchase_debit_note_child_product_deleted_status`) VALUES
(1, '9c73db4caq201fn75iu16243a52949a5c96539ac', 1, 0, 26, 'null', 'null', 0, '0.00', '0.0000', '0.0000', '0.0000', '0.0000', '0.00', '0.00', 0, 1, 1, 4, '1', 1, 1515042868, '103.197.196.14', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_debit_note_products`
--

CREATE TABLE `purchase_debit_note_products` (
  `debitProductId` int(11) NOT NULL,
  `dp_debitnoteId` int(11) NOT NULL,
  `dp_product_id` int(11) NOT NULL,
  `dp_poqty` int(11) NOT NULL,
  `dp_rate` decimal(10,0) NOT NULL,
  `dp_qty` int(11) NOT NULL,
  `dp_amount` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase_debit_note_products`
--

INSERT INTO `purchase_debit_note_products` (`debitProductId`, `dp_debitnoteId`, `dp_product_id`, `dp_poqty`, `dp_rate`, `dp_qty`, `dp_amount`) VALUES
(1, 1, 4, 1000, '100', 10, '1'),
(2, 2, 4, 1000, '100', 10, '1'),
(3, 3, 21, 1000, '100000', 1, '1'),
(4, 1, 4, 100, '0', 50, '0');

-- --------------------------------------------------------

--
-- Table structure for table `purchase_invoice`
--

CREATE TABLE `purchase_invoice` (
  `invoiceId` int(11) NOT NULL,
  `invoiceNo` varchar(10) NOT NULL,
  `pI_branchid` int(11) NOT NULL,
  `pI_purchaseId` int(11) NOT NULL,
  `pI_creditamnt` decimal(11,2) NOT NULL,
  `pI_creditdays` int(11) NOT NULL,
  `pI_invoice_date` date NOT NULL,
  `pI_product_type` int(11) NOT NULL,
  `pI_invoicetotal` decimal(11,2) NOT NULL,
  `pI_cashdiscount` decimal(11,2) NOT NULL,
  `pI_net_total` decimal(11,2) NOT NULL,
  `pI_remark` text NOT NULL,
  `pI_company_id` int(11) NOT NULL,
  `pI_added_by` int(11) NOT NULL,
  `pI_added_on` datetime NOT NULL,
  `pI_added_ip` varchar(20) NOT NULL,
  `pI_modified_by` int(11) NOT NULL,
  `pI_modified_on` datetime NOT NULL,
  `pI_modified_ip` varchar(20) NOT NULL,
  `pI_deleted_by` int(11) NOT NULL,
  `pI_deleted_on` datetime NOT NULL,
  `pI_deleted_ip` varchar(20) NOT NULL,
  `pI_deleted_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase_invoice`
--

INSERT INTO `purchase_invoice` (`invoiceId`, `invoiceNo`, `pI_branchid`, `pI_purchaseId`, `pI_creditamnt`, `pI_creditdays`, `pI_invoice_date`, `pI_product_type`, `pI_invoicetotal`, `pI_cashdiscount`, `pI_net_total`, `pI_remark`, `pI_company_id`, `pI_added_by`, `pI_added_on`, `pI_added_ip`, `pI_modified_by`, `pI_modified_on`, `pI_modified_ip`, `pI_deleted_by`, `pI_deleted_on`, `pI_deleted_ip`, `pI_deleted_status`) VALUES
(2, '00001', 3, 1, '0.00', 0, '2018-01-03', 2, '1800.00', '200.00', '1500.00', '', 1, 1, '2018-01-03 18:46:41', '122.174.33.217', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(3, '00001', 4, 2, '0.00', 0, '2018-01-04', 2, '87750000.00', '0.00', '0.00', '', 1, 1, '2018-01-04 10:19:21', '103.197.196.14', 1, '2018-01-04 10:20:16', '103.197.196.14', 0, '0000-00-00 00:00:00', '', 0),
(4, '00002', 4, 2, '0.00', 0, '2018-01-04', 3, '13500000.00', '0.00', '0.00', '', 1, 1, '2018-01-04 10:38:34', '103.197.196.14', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(5, '00003', 4, 3, '0.00', 0, '2018-01-04', 2, '9000000.00', '1000000.00', '8998000.00', '', 1, 1, '2018-01-04 12:04:13', '103.197.196.14', 1, '2018-01-04 12:04:37', '103.197.196.14', 0, '0000-00-00 00:00:00', '', 0),
(6, '00004', 4, 4, '0.00', 0, '2018-01-05', 2, '13030000.00', '0.00', '12980000.00', '', 1, 1, '2018-01-05 09:57:21', '103.197.196.24', 1, '2018-01-05 09:58:02', '103.197.196.24', 0, '0000-00-00 00:00:00', '', 0),
(7, '00005', 4, 4, '0.00', 0, '2018-01-05', 3, '1950000.00', '0.00', '0.00', '', 1, 1, '2018-01-05 10:10:52', '103.197.196.24', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(8, '00001', 1, 5, '0.00', 0, '2018-01-05', 0, '2000000.00', '0.00', '2000000.00', '', 1, 1, '2018-01-05 10:32:04', '103.197.196.24', 1, '2018-01-05 10:32:54', '103.197.196.24', 0, '0000-00-00 00:00:00', '', 0),
(9, '00002', 3, 6, '0.00', 0, '2018-01-05', 2, '13670000.00', '0.00', '0.00', '', 1, 1, '2018-01-05 10:45:45', '103.197.196.24', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_invoice_products`
--

CREATE TABLE `purchase_invoice_products` (
  `invoiceProductId` int(11) NOT NULL,
  `piP_invoiceId` int(11) NOT NULL,
  `piP_product_id` int(11) NOT NULL,
  `piP_po_qty` int(11) NOT NULL,
  `piP_po_ton` decimal(12,2) NOT NULL,
  `piP_po_kg` decimal(12,2) NOT NULL,
  `piP_rate` decimal(11,2) NOT NULL,
  `piP_frgn_rate` decimal(11,2) NOT NULL,
  `piP_dispercent` decimal(5,2) NOT NULL,
  `piP_disamnt` decimal(11,2) NOT NULL,
  `piP_total` decimal(11,2) NOT NULL,
  `piP_frgntotal` decimal(11,2) NOT NULL,
  `piP_deleted_by` int(11) NOT NULL,
  `piP_deleted_on` int(11) NOT NULL,
  `piP_deleted_ip` varchar(20) NOT NULL,
  `piP_deleted_status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase_invoice_products`
--

INSERT INTO `purchase_invoice_products` (`invoiceProductId`, `piP_invoiceId`, `piP_product_id`, `piP_po_qty`, `piP_po_ton`, `piP_po_kg`, `piP_rate`, `piP_frgn_rate`, `piP_dispercent`, `piP_disamnt`, `piP_total`, `piP_frgntotal`, `piP_deleted_by`, `piP_deleted_on`, `piP_deleted_ip`, `piP_deleted_status`) VALUES
(1, 2, 7, 10, '0.00', '0.00', '200.00', '0.00', '10.00', '200.00', '1800.00', '2.00', 0, 0, '', 0),
(2, 3, 2, 0, '2000.00', '2000000.00', '0.00', '10.00', '0.00', '0.00', '27000000.00', '2.00', 0, 0, '', 0),
(3, 3, 3, 0, '3000.00', '3000000.00', '0.00', '15.00', '0.00', '0.00', '60750000.00', '2.00', 0, 0, '', 0),
(4, 4, 26, 100, '0.00', '0.00', '0.00', '100.00', '0.00', '0.00', '13500000.00', '0.00', 0, 0, '', 0),
(5, 5, 5, 0, '10000.00', '10000000.00', '1000.00', '0.00', '10.00', '1000000.00', '9000000.00', '2.00', 0, 0, '', 0),
(6, 6, 6, 0, '1000.00', '1000000.00', '0.00', '10.00', '0.00', '0.00', '13000000.00', '2.00', 0, 0, '', 0),
(7, 6, 7, 0, '1000.00', '1000000.00', '0.00', '10.00', '0.00', '0.00', '10000.00', '2.00', 0, 0, '', 0),
(8, 6, 8, 0, '2000.00', '2000000.00', '0.00', '10.00', '0.00', '0.00', '20000.00', '2.00', 0, 0, '', 0),
(9, 7, 26, 100, '0.00', '0.00', '0.00', '15.00', '0.00', '0.00', '1950000.00', '0.00', 0, 0, '', 0),
(10, 8, 10, 0, '100.00', '100000.00', '20000.00', '0.00', '0.00', '0.00', '2000000.00', '3.00', 0, 0, '', 0),
(11, 9, 4, 0, '100.00', '100000.00', '0.00', '100.00', '0.00', '0.00', '13670000.00', '2.00', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_order`
--

CREATE TABLE `purchase_order` (
  `purchaseId` int(11) NOT NULL,
  `purchase_no` varchar(11) NOT NULL,
  `pR_branchid` int(11) NOT NULL,
  `pR_supplier_location` int(11) NOT NULL,
  `pR_supplier_id` int(11) NOT NULL,
  `pR_currency_id` int(11) NOT NULL,
  `pR_rate` decimal(11,2) NOT NULL,
  `pR_brand_id` int(11) NOT NULL,
  `pR_purchase_date` date NOT NULL,
  `pR_purchase_od_method` varchar(15) NOT NULL,
  `pR_payment_terms` varchar(15) NOT NULL,
  `pR_shipment_id` varchar(15) NOT NULL,
  `pR_arrival_date` date NOT NULL,
  `pR_totalAmnt` decimal(11,2) NOT NULL,
  `pR_advanceAmnt` decimal(11,2) NOT NULL,
  `pR_net_total_amnt` decimal(12,2) NOT NULL,
  `pR_remarks` text NOT NULL,
  `pR_company_id` int(11) NOT NULL,
  `pR_added_by` int(11) NOT NULL,
  `pR_added_on` datetime NOT NULL,
  `pR_added_ip` varchar(20) NOT NULL,
  `pR_modified_by` int(11) NOT NULL,
  `pR_modified_on` datetime NOT NULL,
  `pR_modified_ip` varchar(20) NOT NULL,
  `pR_deleted_by` int(11) NOT NULL,
  `pR_deleted_on` datetime NOT NULL,
  `pR_deleted_ip` varchar(20) NOT NULL,
  `pR_deleted_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase_order`
--

INSERT INTO `purchase_order` (`purchaseId`, `purchase_no`, `pR_branchid`, `pR_supplier_location`, `pR_supplier_id`, `pR_currency_id`, `pR_rate`, `pR_brand_id`, `pR_purchase_date`, `pR_purchase_od_method`, `pR_payment_terms`, `pR_shipment_id`, `pR_arrival_date`, `pR_totalAmnt`, `pR_advanceAmnt`, `pR_net_total_amnt`, `pR_remarks`, `pR_company_id`, `pR_added_by`, `pR_added_on`, `pR_added_ip`, `pR_modified_by`, `pR_modified_on`, `pR_modified_ip`, `pR_deleted_by`, `pR_deleted_on`, `pR_deleted_ip`, `pR_deleted_status`) VALUES
(1, '00001', 2, 1, 1, 0, '0.00', 0, '2018-01-03', '1', '2', 'SP001', '2018-01-31', '5000.00', '300.00', '4700.00', 'Ubenthiran', 1, 1, '2018-01-03 17:57:43', '122.174.33.217', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(2, '00002', 4, 1, 1, 2, '1350.00', 0, '2018-01-04', '1', '1', '', '2018-01-04', '101250000.00', '500000.00', '100750000.00', '', 1, 1, '2018-01-04 10:10:47', '103.197.196.14', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(3, '00003', 4, 1, 1, 0, '0.00', 0, '2018-01-04', '1', '1', 'bhhj', '2018-01-04', '10000000.00', '2000.00', '9998000.00', '', 1, 1, '2018-01-04 12:01:57', '103.197.196.14', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(4, '00004', 4, 1, 1, 2, '1300.00', 0, '2018-01-05', '1', '1', '1', '2018-01-05', '53950000.00', '50000.00', '53900000.00', '', 1, 1, '2018-01-05 09:47:53', '103.197.196.24', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(5, '00005', 1, 1, 7, 0, '0.00', 0, '2018-01-05', '2', '1', 'F 121231', '2018-01-07', '2000000.00', '0.00', '2000000.00', 'Other', 1, 1, '2018-01-05 10:26:19', '103.197.196.24', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(6, '00006', 3, 1, 1, 2, '1367.00', 0, '2018-01-05', '1', '2', 'YU788', '2018-01-05', '13670000.00', '10000000.00', '3670000.00', '', 1, 1, '2018-01-05 10:40:07', '103.197.196.24', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(7, '00007', 2, 1, 1, 2, '100.00', 0, '2018-01-05', '1', '', 'SU0001', '2018-01-05', '30100.00', '100.00', '30000.00', 'Ubenthiran Added', 1, 1, '2018-01-05 12:00:15', '122.174.33.217', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(8, '00008', 4, 1, 1, 2, '1300.00', 0, '2018-01-06', '1', '1', 'wrw', '2018-01-06', '1300000.00', '1000.00', '1299000.00', '', 1, 1, '2018-01-06 11:47:19', '103.197.196.11', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_order_products`
--

CREATE TABLE `purchase_order_products` (
  `purOrdPorductId` int(11) NOT NULL,
  `pRp_purchaseId` int(11) NOT NULL,
  `pRp_product_id` int(11) NOT NULL,
  `pRp_rate` decimal(11,2) NOT NULL,
  `pRp_frignrate` decimal(11,2) NOT NULL,
  `pRp_qty` int(11) NOT NULL,
  `pRp_ton` decimal(12,2) NOT NULL,
  `pRp_kg` decimal(12,2) NOT NULL,
  `pRp_unitprice` decimal(11,2) NOT NULL,
  `pRp_deleted_by` int(11) NOT NULL,
  `pRp_deleted_on` int(11) NOT NULL,
  `pRp_deleted_ip` varchar(20) NOT NULL,
  `pRp_deleted_status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase_order_products`
--

INSERT INTO `purchase_order_products` (`purOrdPorductId`, `pRp_purchaseId`, `pRp_product_id`, `pRp_rate`, `pRp_frignrate`, `pRp_qty`, `pRp_ton`, `pRp_kg`, `pRp_unitprice`, `pRp_deleted_by`, `pRp_deleted_on`, `pRp_deleted_ip`, `pRp_deleted_status`) VALUES
(1, 1, 7, '200.00', '0.00', 10, '0.00', '0.00', '2000.00', 0, 0, '', 0),
(2, 1, 8, '300.00', '0.00', 0, '10.00', '10000.00', '3000.00', 0, 0, '', 0),
(3, 2, 4, '0.00', '10.00', 0, '2000.00', '2000000.00', '27000000.00', 0, 0, '', 0),
(4, 2, 26, '0.00', '100.00', 100, '0.00', '0.00', '13500000.00', 0, 0, '', 0),
(5, 2, 6, '0.00', '15.00', 0, '3000.00', '3000000.00', '60750000.00', 0, 0, '', 0),
(6, 3, 16, '1000.00', '0.00', 0, '10000.00', '10000000.00', '10000000.00', 0, 0, '', 0),
(7, 4, 4, '0.00', '10.00', 0, '1000.00', '1000000.00', '13000000.00', 0, 0, '', 0),
(8, 4, 9, '0.00', '10.00', 0, '1000.00', '1000000.00', '13000000.00', 0, 0, '', 0),
(9, 4, 23, '0.00', '10.00', 0, '2000.00', '2000000.00', '26000000.00', 0, 0, '', 0),
(10, 4, 26, '0.00', '15.00', 100, '0.00', '0.00', '1950000.00', 0, 0, '', 0),
(11, 5, 28, '20000.00', '0.00', 0, '100.00', '100000.00', '2000000.00', 0, 0, '', 0),
(12, 6, 4, '0.00', '100.00', 0, '100.00', '100000.00', '13670000.00', 0, 0, '', 0),
(13, 7, 1, '10.00', '0.00', 10, '0.00', '0.00', '100.00', 0, 0, '', 0),
(14, 7, 2, '0.00', '10.00', 10, '0.00', '0.00', '10000.00', 0, 0, '', 0),
(15, 7, 3, '0.00', '10.00', 0, '20.00', '20000.00', '20000.00', 0, 0, '', 0),
(16, 8, 4, '0.00', '10.00', 0, '100.00', '100000.00', '1300000.00', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_payment`
--

CREATE TABLE `purchase_payment` (
  `paymentId` int(11) NOT NULL,
  `p_branchid` int(11) NOT NULL,
  `p_supplier_location` int(11) NOT NULL,
  `p_supplier_name` int(11) NOT NULL,
  `p_paymentdate` date NOT NULL,
  `p_paymentterm` varchar(10) NOT NULL,
  `p_bankname` varchar(100) NOT NULL,
  `p_acno` varchar(20) NOT NULL,
  `p_company_id` int(11) NOT NULL,
  `p_added_by` int(11) NOT NULL,
  `p_added_on` datetime NOT NULL,
  `p_added_ip` varchar(20) NOT NULL,
  `p_modified_by` int(11) NOT NULL,
  `p_modified_on` datetime NOT NULL,
  `p_modified_ip` varchar(20) NOT NULL,
  `p_deleted_by` int(11) NOT NULL,
  `p_deleted_on` datetime NOT NULL,
  `p_deleted_ip` varchar(20) NOT NULL,
  `p_deleted_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase_payment`
--

INSERT INTO `purchase_payment` (`paymentId`, `p_branchid`, `p_supplier_location`, `p_supplier_name`, `p_paymentdate`, `p_paymentterm`, `p_bankname`, `p_acno`, `p_company_id`, `p_added_by`, `p_added_on`, `p_added_ip`, `p_modified_by`, `p_modified_on`, `p_modified_ip`, `p_deleted_by`, `p_deleted_on`, `p_deleted_ip`, `p_deleted_status`) VALUES
(1, 4, 1, 1, '2018-01-04', '2', '1', '4567899', 1, 1, '2018-01-04 10:35:32', '103.197.196.14', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(2, 4, 1, 1, '2018-01-04', '1', '', '', 1, 1, '2018-01-04 12:06:40', '103.197.196.14', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(3, 4, 1, 1, '2018-01-05', '1', '', '', 1, 1, '2018-01-05 10:06:24', '103.197.196.24', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_payment_details`
--

CREATE TABLE `purchase_payment_details` (
  `paymentInvioiceId` int(11) NOT NULL,
  `pi_paymentId` int(11) NOT NULL,
  `pi_invoiceId` int(11) NOT NULL,
  `pi_purchaseamnt` decimal(11,2) NOT NULL,
  `pi_advanceamnt` decimal(11,2) NOT NULL,
  `pi_paidamnt` decimal(11,2) NOT NULL,
  `pi_amount` decimal(11,2) NOT NULL,
  `pi_balanceamnt` decimal(11,2) NOT NULL,
  `pi_deleted_by` int(11) NOT NULL,
  `pi_deleted_on` int(50) NOT NULL,
  `pi_deleted_ip` varchar(20) NOT NULL,
  `pi_deleted_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase_payment_details`
--

INSERT INTO `purchase_payment_details` (`paymentInvioiceId`, `pi_paymentId`, `pi_invoiceId`, `pi_purchaseamnt`, `pi_advanceamnt`, `pi_paidamnt`, `pi_amount`, `pi_balanceamnt`, `pi_deleted_by`, `pi_deleted_on`, `pi_deleted_ip`, `pi_deleted_status`) VALUES
(1, 1, 2, '1500.00', '0.00', '0.00', '500.00', '1.00', 0, 0, '', 0),
(2, 2, 5, '8998000.00', '0.00', '0.00', '8000.00', '89.00', 0, 0, '', 0),
(3, 3, 6, '12980000.00', '50000.00', '0.00', '80000.00', '1.00', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `quotation_entry`
--

CREATE TABLE `quotation_entry` (
  `quotation_entry_id` int(11) NOT NULL,
  `quotation_entry_uniq_id` varchar(255) NOT NULL,
  `quotation_entry_no` varchar(30) NOT NULL,
  `quotation_entry_date` date NOT NULL,
  `quotation_entry_customer_id` int(11) NOT NULL,
  `quotation_entry_validity_date` date NOT NULL,
  `quotation_entry_type_id` int(11) NOT NULL,
  `quotation_entry_gross_amount` decimal(20,4) NOT NULL,
  `quotation_entry_transport_amount` decimal(20,4) NOT NULL,
  `quotation_entry_tax_per` decimal(20,4) NOT NULL,
  `quotation_entry_tax_amount` decimal(20,4) NOT NULL,
  `quotation_entry_advance_amount` decimal(20,4) NOT NULL,
  `quotation_entry_net_amount` decimal(20,4) NOT NULL,
  `quotation_entry_company_id` int(11) NOT NULL,
  `quotation_entry_branch_id` int(11) NOT NULL,
  `quotation_entry_financial_year` int(11) NOT NULL,
  `quotation_entry_added_by` int(11) NOT NULL,
  `quotation_entry_added_on` int(11) NOT NULL,
  `quotation_entry_added_ip` varchar(20) NOT NULL,
  `quotation_entry_modified_by` int(11) NOT NULL,
  `quotation_entry_modified_on` int(11) NOT NULL,
  `quotation_entry_modified_ip` varchar(20) NOT NULL,
  `quotation_entry_deleted_by` int(11) NOT NULL,
  `quotation_entry_deleted_on` int(11) NOT NULL,
  `quotation_entry_deleted_ip` varchar(20) NOT NULL,
  `quotation_entry_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quotation_entry`
--

INSERT INTO `quotation_entry` (`quotation_entry_id`, `quotation_entry_uniq_id`, `quotation_entry_no`, `quotation_entry_date`, `quotation_entry_customer_id`, `quotation_entry_validity_date`, `quotation_entry_type_id`, `quotation_entry_gross_amount`, `quotation_entry_transport_amount`, `quotation_entry_tax_per`, `quotation_entry_tax_amount`, `quotation_entry_advance_amount`, `quotation_entry_net_amount`, `quotation_entry_company_id`, `quotation_entry_branch_id`, `quotation_entry_financial_year`, `quotation_entry_added_by`, `quotation_entry_added_on`, `quotation_entry_added_ip`, `quotation_entry_modified_by`, `quotation_entry_modified_on`, `quotation_entry_modified_ip`, `quotation_entry_deleted_by`, `quotation_entry_deleted_on`, `quotation_entry_deleted_ip`, `quotation_entry_deleted_status`) VALUES
(1, '587e569vyy6a0c4yxj59b4389034844b67c7355a', 'Uben0001', '2018-01-06', 1, '2018-01-31', 1, '30.0000', '10.0000', '1.0000', '0.3000', '0.3000', '40.0000', 1, 2, 1, 1, 1515222274, '122.174.33.217', 0, 0, '', 0, 0, '', 0),
(2, 'd4befce6zgd797q6z2yb4498a400a95e7dd66749', '11', '2018-01-06', 7, '2018-01-06', 1, '1000.0000', '0.0000', '0.0000', '0.0000', '0.0000', '1000.0000', 1, 4, 1, 1, 1515226239, '103.197.196.11', 0, 0, '', 0, 0, '', 0),
(3, '695dc12taue0dbjxh77a7af54d3d27a8f7488888', 'Uben0002', '2018-01-06', 3, '2018-01-06', 2, '30000.0000', '100.0000', '1.0000', '300.0000', '1000.0000', '29400.0000', 1, 2, 1, 1, 1515229516, '122.174.33.217', 0, 0, '', 0, 0, '', 0),
(4, '16017da6yl4cb7zigrz552ecac27c8e3aa9aeda2', 'QU901', '2018-01-06', 3, '2018-01-13', 1, '1000.0000', '0.0000', '0.0000', '0.0000', '0.0000', '1000.0000', 1, 3, 1, 1, 1515230576, '103.197.196.11', 0, 0, '', 0, 0, '', 0),
(5, '35dd79ees4c9dapnttj453647a0e86189a4b2918', '11', '2018-01-06', 7, '2018-01-06', 1, '1000.0000', '0.0000', '0.0000', '0.0000', '0.0000', '1000.0000', 1, 4, 1, 1, 1515230972, '103.197.196.11', 0, 0, '', 0, 0, '', 0),
(6, 'fd6bcc8ezs96bd6sykh45e650b091fdcd5cfaf68', 'q99121', '2018-01-06', 6, '2018-01-07', 1, '2000.0000', '10.0000', '0.0000', '0.0000', '0.0000', '2010.0000', 1, 1, 1, 1, 1515231232, '103.197.196.11', 0, 0, '', 0, 0, '', 0),
(7, '07de16fnm8d7ac1vga7fdc5145247e1e166dc238', 'QU904', '2018-01-06', 3, '2018-01-13', 2, '100000.0000', '0.0000', '0.0000', '0.0000', '0.0000', '100000.0000', 1, 3, 1, 1, 1515231601, '103.197.196.11', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `quotation_entry_product_details`
--

CREATE TABLE `quotation_entry_product_details` (
  `quotation_entry_product_detail_id` int(11) NOT NULL,
  `quotation_entry_product_detail_uniq_id` varchar(255) NOT NULL,
  `quotation_entry_product_detail_quotation_entry_id` int(11) NOT NULL,
  `quotation_entry_product_detail_product_id` int(11) NOT NULL,
  `quotation_entry_product_detail_product_uom_id` int(11) NOT NULL,
  `quotation_entry_product_detail_product_brand_id` int(11) NOT NULL,
  `quotation_entry_product_detail_product_color_id` int(11) NOT NULL,
  `quotation_entry_product_detail_product_type` int(11) NOT NULL,
  `quotation_entry_product_detail_product_thick` decimal(20,4) NOT NULL,
  `quotation_entry_product_detail_width_inches` decimal(20,4) NOT NULL,
  `quotation_entry_product_detail_width_mm` decimal(20,4) NOT NULL,
  `quotation_entry_product_detail_s_width_inches` decimal(20,4) NOT NULL,
  `quotation_entry_product_detail_s_width_mm` decimal(20,4) NOT NULL,
  `quotation_entry_product_detail_sl_feet` decimal(20,4) NOT NULL,
  `quotation_entry_product_detail_sl_feet_in` decimal(20,4) NOT NULL,
  `quotation_entry_product_detail_sl_feet_mm` decimal(20,4) NOT NULL,
  `quotation_entry_product_detail_s_weight_inches` decimal(20,4) NOT NULL,
  `quotation_entry_product_detail_s_weight_mm` decimal(20,4) NOT NULL,
  `quotation_entry_product_detail_tot_length` decimal(20,4) NOT NULL,
  `quotation_entry_product_detail_rate` decimal(20,4) NOT NULL,
  `quotation_entry_product_detail_total` decimal(20,4) NOT NULL,
  `quotation_entry_product_detail_qty` decimal(20,4) NOT NULL,
  `quotation_entry_product_detail_added_by` int(11) NOT NULL,
  `quotation_entry_product_detail_added_on` int(11) NOT NULL,
  `quotation_entry_product_detail_added_ip` varchar(20) NOT NULL,
  `quotation_entry_product_detail_modified_by` int(11) NOT NULL,
  `quotation_entry_product_detail_modified_on` int(11) NOT NULL,
  `quotation_entry_product_detail_modified_ip` varchar(20) NOT NULL,
  `quotation_entry_product_detail_deleted_by` int(11) NOT NULL,
  `quotation_entry_product_detail_deleted_on` int(11) NOT NULL,
  `quotation_entry_product_detail_deleted_ip` varchar(20) NOT NULL,
  `quotation_entry_product_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quotation_entry_product_details`
--

INSERT INTO `quotation_entry_product_details` (`quotation_entry_product_detail_id`, `quotation_entry_product_detail_uniq_id`, `quotation_entry_product_detail_quotation_entry_id`, `quotation_entry_product_detail_product_id`, `quotation_entry_product_detail_product_uom_id`, `quotation_entry_product_detail_product_brand_id`, `quotation_entry_product_detail_product_color_id`, `quotation_entry_product_detail_product_type`, `quotation_entry_product_detail_product_thick`, `quotation_entry_product_detail_width_inches`, `quotation_entry_product_detail_width_mm`, `quotation_entry_product_detail_s_width_inches`, `quotation_entry_product_detail_s_width_mm`, `quotation_entry_product_detail_sl_feet`, `quotation_entry_product_detail_sl_feet_in`, `quotation_entry_product_detail_sl_feet_mm`, `quotation_entry_product_detail_s_weight_inches`, `quotation_entry_product_detail_s_weight_mm`, `quotation_entry_product_detail_tot_length`, `quotation_entry_product_detail_rate`, `quotation_entry_product_detail_total`, `quotation_entry_product_detail_qty`, `quotation_entry_product_detail_added_by`, `quotation_entry_product_detail_added_on`, `quotation_entry_product_detail_added_ip`, `quotation_entry_product_detail_modified_by`, `quotation_entry_product_detail_modified_on`, `quotation_entry_product_detail_modified_ip`, `quotation_entry_product_detail_deleted_by`, `quotation_entry_product_detail_deleted_on`, `quotation_entry_product_detail_deleted_ip`, `quotation_entry_product_detail_deleted_status`) VALUES
(1, '4d051b5pxm2e2ecmq4s0fa1e0d4557064d9b90b2', 1, 5, 2, 4, 4, 2, '1.0000', '10.0000', '254.0000', '36.0000', '914.4000', '100.0000', '1200.0000', '30480.0000', '0.0000', '0.0000', '720.0000', '10.0000', '20.0000', '2.0000', 1, 1515222274, '122.174.33.217', 0, 0, '', 0, 0, '', 0),
(2, 'de0a909cpfcd29foq9gf2dffe64d393b3e7d96fb', 1, 6, 5, 4, 7, 2, '2.0000', '20.0000', '508.0000', '3.0000', '914.4000', '50.0000', '600.0000', '15240.0000', '0.0000', '0.0000', '7.5000', '10.0000', '10.0000', '1.0000', 1, 1515222274, '122.174.33.217', 0, 0, '', 0, 0, '', 0),
(3, 'b13d744dsi2a78itrhd9e9e4df7adb5e67094854', 2, 7, 3, 4, 6, 2, '1.0000', '36.0000', '914.4000', '0.0000', '457.2000', '100.0000', '1200.0000', '30480.0000', '0.0000', '0.0000', '0.0000', '100.0000', '1000.0000', '10.0000', 1, 1515226239, '103.197.196.11', 0, 0, '', 0, 0, '', 0),
(4, '12844c0rvs31e37lyhx29857220a1e992f691628', 3, 8, 3, 4, 6, 2, '2.0000', '48.0000', '1219.2000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '100.0000', '10000.0000', '100.0000', 1, 1515229517, '122.174.33.217', 0, 0, '', 0, 0, '', 0),
(5, '691d25bmay8909fr2ox7ca48918d0aca4d33b4ae', 3, 9, 3, 6, 0, 2, '2.0000', '36.0000', '914.4000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '100.0000', '0.0000', '0.0000', '100.0000', '20000.0000', '200.0000', 1, 1515229517, '122.174.33.217', 0, 0, '', 0, 0, '', 0),
(6, '4af9a2carx8c43hrx334896356464566aa7d252e', 4, 5, 2, 4, 4, 2, '1.0000', '10.0000', '254.0000', '0.0000', '914.4000', '10.0000', '120.0000', '3048.0000', '0.0000', '0.0000', '0.0000', '1000.0000', '1000.0000', '1.0000', 1, 1515230576, '103.197.196.11', 0, 0, '', 0, 0, '', 0),
(7, 'dfd92f554w61fe0wvw8274154f90d6f6b142a993', 5, 5, 2, 4, 4, 2, '1.0000', '10.0000', '254.0000', '36.0000', '914.4000', '100.0000', '1200.0000', '30480.0000', '0.0000', '0.0000', '3600.0000', '100.0000', '1000.0000', '10.0000', 1, 1515230972, '103.197.196.11', 0, 0, '', 0, 0, '', 0),
(8, '5e76cf9a461248v7t0ze0e010681eefb7b112323', 6, 14, 3, 4, 5, 2, '2.0000', '36.0000', '914.4000', '18.0000', '457.2003', '100.0000', '1200.0000', '30480.0000', '0.0000', '0.0000', '100.0000', '1000.0000', '2000.0000', '2.0000', 1, 1515231232, '103.197.196.11', 0, 0, '', 0, 0, '', 0),
(9, 'b45babdwgta750j95pk09fa2d4f3bd6fc1b0bd01', 7, 8, 3, 4, 6, 2, '2.0000', '48.0000', '1219.2000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '10.0000', '0.0000', '0.0000', '100000.0000', '100000.0000', '1.0000', 1, 1515231601, '103.197.196.11', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `recycle_entry`
--

CREATE TABLE `recycle_entry` (
  `recycle_entry_id` int(11) NOT NULL,
  `recycle_entry_uniq_id` varchar(255) NOT NULL,
  `recycle_entry_no` varchar(30) NOT NULL,
  `recycle_entry_date` date NOT NULL,
  `recycle_entry_godown_id` int(11) NOT NULL,
  `recycle_entry_type` varchar(30) NOT NULL,
  `recycle_entry_status` int(11) NOT NULL DEFAULT '1',
  `recycle_entry_company_id` int(11) NOT NULL,
  `recycle_entry_branch_id` int(11) NOT NULL,
  `recycle_entry_financial_year` int(11) NOT NULL,
  `recycle_entry_added_by` int(11) NOT NULL,
  `recycle_entry_added_on` int(11) NOT NULL,
  `recycle_entry_added_ip` varchar(20) NOT NULL,
  `recycle_entry_modified_by` int(11) NOT NULL,
  `recycle_entry_modified_on` int(11) NOT NULL,
  `recycle_entry_modified_ip` varchar(20) NOT NULL,
  `recycle_entry_deleted_by` int(11) NOT NULL,
  `recycle_entry_deleted_on` int(11) NOT NULL,
  `recycle_entry_deleted_ip` varchar(20) NOT NULL,
  `recycle_entry_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `recycle_entry`
--

INSERT INTO `recycle_entry` (`recycle_entry_id`, `recycle_entry_uniq_id`, `recycle_entry_no`, `recycle_entry_date`, `recycle_entry_godown_id`, `recycle_entry_type`, `recycle_entry_status`, `recycle_entry_company_id`, `recycle_entry_branch_id`, `recycle_entry_financial_year`, `recycle_entry_added_by`, `recycle_entry_added_on`, `recycle_entry_added_ip`, `recycle_entry_modified_by`, `recycle_entry_modified_on`, `recycle_entry_modified_ip`, `recycle_entry_deleted_by`, `recycle_entry_deleted_on`, `recycle_entry_deleted_ip`, `recycle_entry_deleted_status`) VALUES
(1, 'bf8de79gzc3d75he3dp180f91b0718444f1b6244', '00001', '2017-12-14', 1, '1', 1, 1, 1, 1, 1, 1513238817, '103.197.196.20', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `recycle_entry_product_details`
--

CREATE TABLE `recycle_entry_product_details` (
  `recycle_entry_product_detail_id` int(11) NOT NULL,
  `recycle_entry_product_detail_uniq_id` varchar(255) NOT NULL,
  `recycle_entry_product_detail_recycle_entry_id` int(11) NOT NULL,
  `recycle_entry_product_detail_product_id` int(11) NOT NULL,
  `recycle_entry_product_detail_width_inches` decimal(20,4) NOT NULL,
  `recycle_entry_product_detail_width_mm` decimal(20,4) NOT NULL,
  `recycle_entry_product_detail_length_feet` decimal(20,4) NOT NULL,
  `recycle_entry_product_detail_length_mm` decimal(20,4) NOT NULL,
  `recycle_entry_product_detail_qty` decimal(20,4) NOT NULL,
  `recycle_entry_product_detail_type` int(11) NOT NULL,
  `recycle_entry_product_detail_company_id` int(11) NOT NULL,
  `recycle_entry_product_detail_branch_id` int(11) NOT NULL,
  `recycle_entry_product_detail_financial_year` varchar(20) NOT NULL,
  `recycle_entry_product_detail_added_by` int(11) NOT NULL,
  `recycle_entry_product_detail_added_on` int(11) NOT NULL,
  `recycle_entry_product_detail_added_ip` varchar(20) NOT NULL,
  `recycle_entry_product_detail_modified_by` int(11) NOT NULL,
  `recycle_entry_product_detail_modified_on` int(11) NOT NULL,
  `recycle_entry_product_detail_modified_ip` varchar(20) NOT NULL,
  `recycle_entry_product_detail_deleted_by` int(11) NOT NULL,
  `recycle_entry_product_detail_deleted_on` int(11) NOT NULL,
  `recycle_entry_product_detail_deleted_ip` varchar(20) NOT NULL,
  `recycle_entry_product_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `recycle_entry_product_details`
--

INSERT INTO `recycle_entry_product_details` (`recycle_entry_product_detail_id`, `recycle_entry_product_detail_uniq_id`, `recycle_entry_product_detail_recycle_entry_id`, `recycle_entry_product_detail_product_id`, `recycle_entry_product_detail_width_inches`, `recycle_entry_product_detail_width_mm`, `recycle_entry_product_detail_length_feet`, `recycle_entry_product_detail_length_mm`, `recycle_entry_product_detail_qty`, `recycle_entry_product_detail_type`, `recycle_entry_product_detail_company_id`, `recycle_entry_product_detail_branch_id`, `recycle_entry_product_detail_financial_year`, `recycle_entry_product_detail_added_by`, `recycle_entry_product_detail_added_on`, `recycle_entry_product_detail_added_ip`, `recycle_entry_product_detail_modified_by`, `recycle_entry_product_detail_modified_on`, `recycle_entry_product_detail_modified_ip`, `recycle_entry_product_detail_deleted_by`, `recycle_entry_product_detail_deleted_on`, `recycle_entry_product_detail_deleted_ip`, `recycle_entry_product_detail_deleted_status`) VALUES
(1, '299ca2c4wfe2b7zmawue839cf1098f19995d2b1f', 1, 51, '9.0000', '228.6000', '100.0000', '30480.0000', '100.0000', 0, 0, 0, '', 1, 1513238817, '103.197.196.20', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `recycle_entry_width_details`
--

CREATE TABLE `recycle_entry_width_details` (
  `recycle_entry_width_detail_id` int(11) NOT NULL,
  `recycle_entry_width_detail_uniq_id` varchar(255) NOT NULL,
  `recycle_entry_width_detail_recycle_entry_id` int(11) NOT NULL,
  `recycle_entry_width_detail_name` varchar(255) NOT NULL,
  `recycle_entry_width_detail_product_id` int(11) NOT NULL,
  `recycle_entry_width_detail_width_inches_one` decimal(20,4) NOT NULL,
  `recycle_entry_width_detail_width_inches_two` decimal(20,4) NOT NULL,
  `recycle_entry_width_detail_width_inches_three` decimal(20,4) NOT NULL,
  `recycle_entry_width_detail_width_inches_four` decimal(20,4) NOT NULL,
  `recycle_entry_width_detail_inches_qty` decimal(20,4) NOT NULL,
  `recycle_entry_width_detail_length` decimal(20,4) NOT NULL,
  `recycle_entry_width_detail_length_qty` decimal(12,3) NOT NULL,
  `recycle_entry_width_detail_type` int(11) NOT NULL,
  `recycle_entry_width_detail_company_id` int(11) NOT NULL,
  `recycle_entry_width_detail_branch_id` int(11) NOT NULL,
  `recycle_entry_width_detail_financial_year` varchar(20) NOT NULL,
  `recycle_entry_width_detail_added_by` int(11) NOT NULL,
  `recycle_entry_width_detail_added_on` int(11) NOT NULL,
  `recycle_entry_width_detail_added_ip` varchar(20) NOT NULL,
  `recycle_entry_width_detail_modified_by` int(11) NOT NULL,
  `recycle_entry_width_detail_modified_on` int(11) NOT NULL,
  `recycle_entry_width_detail_modified_ip` varchar(20) NOT NULL,
  `recycle_entry_width_detail_deleted_by` int(11) NOT NULL,
  `recycle_entry_width_detail_deleted_on` int(11) NOT NULL,
  `recycle_entry_width_detail_deleted_ip` varchar(20) NOT NULL,
  `recycle_entry_width_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `recycle_entry_width_details`
--

INSERT INTO `recycle_entry_width_details` (`recycle_entry_width_detail_id`, `recycle_entry_width_detail_uniq_id`, `recycle_entry_width_detail_recycle_entry_id`, `recycle_entry_width_detail_name`, `recycle_entry_width_detail_product_id`, `recycle_entry_width_detail_width_inches_one`, `recycle_entry_width_detail_width_inches_two`, `recycle_entry_width_detail_width_inches_three`, `recycle_entry_width_detail_width_inches_four`, `recycle_entry_width_detail_inches_qty`, `recycle_entry_width_detail_length`, `recycle_entry_width_detail_length_qty`, `recycle_entry_width_detail_type`, `recycle_entry_width_detail_company_id`, `recycle_entry_width_detail_branch_id`, `recycle_entry_width_detail_financial_year`, `recycle_entry_width_detail_added_by`, `recycle_entry_width_detail_added_on`, `recycle_entry_width_detail_added_ip`, `recycle_entry_width_detail_modified_by`, `recycle_entry_width_detail_modified_on`, `recycle_entry_width_detail_modified_ip`, `recycle_entry_width_detail_deleted_by`, `recycle_entry_width_detail_deleted_on`, `recycle_entry_width_detail_deleted_ip`, `recycle_entry_width_detail_deleted_status`) VALUES
(1, '10c8027i2xacf6n3hc0c78c7db41d5e7641d0bec', 1, 'WIDTH1', 51, '3.0000', '6.0000', '0.0000', '0.0000', '2.0000', '50.0000', '2.000', 0, 0, 0, '', 1, 1513238817, '103.197.196.20', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `reserve_entry`
--

CREATE TABLE `reserve_entry` (
  `reserve_entry_id` int(11) NOT NULL,
  `reserve_entry_uniq_id` varchar(255) NOT NULL,
  `reserve_entry_no` varchar(30) NOT NULL,
  `reserve_entry_date` date NOT NULL,
  `reserve_entry_from_date` date NOT NULL,
  `reserve_entry_to_date` date NOT NULL,
  `reserve_entry_godown_id` int(11) NOT NULL,
  `reserve_entry_company_id` int(11) NOT NULL,
  `reserve_entry_branch_id` int(11) NOT NULL,
  `reserve_entry_financial_year` int(11) NOT NULL,
  `reserve_entry_added_by` int(11) NOT NULL,
  `reserve_entry_added_on` int(11) NOT NULL,
  `reserve_entry_added_ip` varchar(20) NOT NULL,
  `reserve_entry_modified_by` int(11) NOT NULL,
  `reserve_entry_modified_on` int(11) NOT NULL,
  `reserve_entry_modified_ip` varchar(20) NOT NULL,
  `reserve_entry_deleted_by` int(11) NOT NULL,
  `reserve_entry_deleted_on` int(11) NOT NULL,
  `reserve_entry_deleted_ip` varchar(20) NOT NULL,
  `reserve_entry_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reserve_entry`
--

INSERT INTO `reserve_entry` (`reserve_entry_id`, `reserve_entry_uniq_id`, `reserve_entry_no`, `reserve_entry_date`, `reserve_entry_from_date`, `reserve_entry_to_date`, `reserve_entry_godown_id`, `reserve_entry_company_id`, `reserve_entry_branch_id`, `reserve_entry_financial_year`, `reserve_entry_added_by`, `reserve_entry_added_on`, `reserve_entry_added_ip`, `reserve_entry_modified_by`, `reserve_entry_modified_on`, `reserve_entry_modified_ip`, `reserve_entry_deleted_by`, `reserve_entry_deleted_on`, `reserve_entry_deleted_ip`, `reserve_entry_deleted_status`) VALUES
(1, '569cc81z7peeceilvflaaa81c3a1ee7923cc9fac', '00001', '2017-12-16', '2017-12-16', '2017-12-17', 2, 1, 1, 1, 1, 1513407937, '203.81.71.134', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `reserve_entry_product_details`
--

CREATE TABLE `reserve_entry_product_details` (
  `reserve_entry_product_detail_id` int(11) NOT NULL,
  `reserve_entry_product_detail_uniq_id` varchar(255) NOT NULL,
  `reserve_entry_product_detail_reserve_entry_id` int(11) NOT NULL,
  `reserve_entry_product_detail_product_id` int(11) NOT NULL,
  `reserve_entry_product_detail_qty` decimal(20,4) NOT NULL,
  `reserve_entry_product_detail_mode` int(11) NOT NULL,
  `reserve_entry_product_detail_customer_id` int(11) NOT NULL,
  `reserve_entry_product_detail_company_id` int(11) NOT NULL,
  `reserve_entry_product_detail_branch_id` int(11) NOT NULL,
  `reserve_entry_product_detail_financial_year` varchar(20) NOT NULL,
  `reserve_entry_product_detail_added_by` int(11) NOT NULL,
  `reserve_entry_product_detail_added_on` int(11) NOT NULL,
  `reserve_entry_product_detail_added_ip` varchar(20) NOT NULL,
  `reserve_entry_product_detail_modified_by` int(11) NOT NULL,
  `reserve_entry_product_detail_modified_on` int(11) NOT NULL,
  `reserve_entry_product_detail_modified_ip` varchar(20) NOT NULL,
  `reserve_entry_product_detail_deleted_by` int(11) NOT NULL,
  `reserve_entry_product_detail_deleted_on` int(11) NOT NULL,
  `reserve_entry_product_detail_deleted_ip` varchar(20) NOT NULL,
  `reserve_entry_product_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reserve_entry_product_details`
--

INSERT INTO `reserve_entry_product_details` (`reserve_entry_product_detail_id`, `reserve_entry_product_detail_uniq_id`, `reserve_entry_product_detail_reserve_entry_id`, `reserve_entry_product_detail_product_id`, `reserve_entry_product_detail_qty`, `reserve_entry_product_detail_mode`, `reserve_entry_product_detail_customer_id`, `reserve_entry_product_detail_company_id`, `reserve_entry_product_detail_branch_id`, `reserve_entry_product_detail_financial_year`, `reserve_entry_product_detail_added_by`, `reserve_entry_product_detail_added_on`, `reserve_entry_product_detail_added_ip`, `reserve_entry_product_detail_modified_by`, `reserve_entry_product_detail_modified_on`, `reserve_entry_product_detail_modified_ip`, `reserve_entry_product_detail_deleted_by`, `reserve_entry_product_detail_deleted_on`, `reserve_entry_product_detail_deleted_ip`, `reserve_entry_product_detail_deleted_status`) VALUES
(1, '72214735gxc24ar4pjgfe649ff13f19e36c1b4b3', 1, 4, '10.0000', 1, 0, 1, 1, '1', 1, 1513407937, '203.81.71.134', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `salesmans`
--

CREATE TABLE `salesmans` (
  `salesman_id` int(11) NOT NULL,
  `salesman_uniq_id` varchar(100) NOT NULL,
  `salesman_name` varchar(255) NOT NULL,
  `salesman_contact_no` varchar(40) NOT NULL,
  `salesman_mobile_no` varchar(40) NOT NULL,
  `salesman_line_phone` varchar(40) NOT NULL,
  `salesman_commission_type` int(11) NOT NULL,
  `salesman_commission` decimal(12,3) NOT NULL,
  `salesman_company_id` int(11) NOT NULL,
  `salesman_added_by` int(11) NOT NULL,
  `salesman_added_on` int(11) NOT NULL,
  `salesman_added_ip` varchar(20) NOT NULL,
  `salesman_modified_by` int(11) NOT NULL,
  `salesman_modified_on` int(11) NOT NULL,
  `salesman_modified_ip` varchar(20) NOT NULL,
  `salesman_deleted_by` int(11) NOT NULL,
  `salesman_deleted_on` int(11) NOT NULL,
  `salesman_deleted_ip` varchar(20) NOT NULL,
  `salesman_active_status` varchar(20) NOT NULL DEFAULT 'active',
  `salesman_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `salesmans`
--

INSERT INTO `salesmans` (`salesman_id`, `salesman_uniq_id`, `salesman_name`, `salesman_contact_no`, `salesman_mobile_no`, `salesman_line_phone`, `salesman_commission_type`, `salesman_commission`, `salesman_company_id`, `salesman_added_by`, `salesman_added_on`, `salesman_added_ip`, `salesman_modified_by`, `salesman_modified_on`, `salesman_modified_ip`, `salesman_deleted_by`, `salesman_deleted_on`, `salesman_deleted_ip`, `salesman_active_status`, `salesman_deleted_status`) VALUES
(1, '1de05d2zya6a0d5vbqcf319101922846aaf7eccd', 'Pandurangon', '7886482005', '8860662347', '123654', 1, '10.000', 0, 1, 1504506765, '::1', 0, 0, '', 0, 0, '', 'active', 0),
(2, '5afa142j84d868h5bgl2d9553ada853750c03db5', 'Sathish', '7886845001', '9884689225', '654987', 2, '2500.000', 0, 1, 1504506806, '::1', 0, 0, '', 0, 0, '', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `salesmodes`
--

CREATE TABLE `salesmodes` (
  `salesmode_id` int(11) NOT NULL,
  `salesmode_uniq_id` varchar(100) NOT NULL,
  `salesmode_name` varchar(255) NOT NULL,
  `salesmode_contact_no` varchar(40) NOT NULL,
  `salesmode_mobile_no` varchar(40) NOT NULL,
  `salesmode_line_phone` varchar(40) NOT NULL,
  `salesmode_commission_type` int(11) NOT NULL,
  `salesmode_commission` decimal(12,3) NOT NULL,
  `salesmode_company_id` int(11) NOT NULL,
  `salesmode_added_by` int(11) NOT NULL,
  `salesmode_added_on` int(11) NOT NULL,
  `salesmode_added_ip` varchar(20) NOT NULL,
  `salesmode_modified_by` int(11) NOT NULL,
  `salesmode_modified_on` int(11) NOT NULL,
  `salesmode_modified_ip` varchar(20) NOT NULL,
  `salesmode_deleted_by` int(11) NOT NULL,
  `salesmode_deleted_on` int(11) NOT NULL,
  `salesmode_deleted_ip` varchar(20) NOT NULL,
  `salesmode_active_status` varchar(20) NOT NULL DEFAULT 'active',
  `salesmode_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `salesmodes`
--

INSERT INTO `salesmodes` (`salesmode_id`, `salesmode_uniq_id`, `salesmode_name`, `salesmode_contact_no`, `salesmode_mobile_no`, `salesmode_line_phone`, `salesmode_commission_type`, `salesmode_commission`, `salesmode_company_id`, `salesmode_added_by`, `salesmode_added_on`, `salesmode_added_ip`, `salesmode_modified_by`, `salesmode_modified_on`, `salesmode_modified_ip`, `salesmode_deleted_by`, `salesmode_deleted_on`, `salesmode_deleted_ip`, `salesmode_active_status`, `salesmode_deleted_status`) VALUES
(1, '07476abfx52d674jkzh869ed0c5b6c91b554146a', 'Shopper', '', '', '', 0, '0.000', 0, 1, 1504505259, '::1', 0, 0, '', 0, 0, '', 'active', 0),
(2, 'b1ff219eqo8350p2iefc5d2d5db16973f2c7b22c', 'Dealer', '', '', '', 0, '0.000', 0, 1, 1504505271, '::1', 0, 0, '', 0, 0, '', 'active', 0),
(3, 'e1acafai8y605d6pi1cd8fea05df091a83be0898', 'Retail', '', '', '', 0, '0.000', 0, 1, 1504505281, '::1', 0, 0, '', 0, 0, '', 'active', 0),
(4, '58def05r3tfae2711s11b640a6588b3074fcd255', 'Whole Sales', '', '', '', 0, '0.000', 0, 1, 1504505338, '::1', 0, 0, '', 1, 1509182797, '192.168.1.5', 'active', 1);

-- --------------------------------------------------------

--
-- Table structure for table `so_entry`
--

CREATE TABLE `so_entry` (
  `so_entry_id` int(11) NOT NULL,
  `so_entry_uniq_id` varchar(255) NOT NULL,
  `so_entry_no` varchar(30) NOT NULL,
  `so_entry_date` date NOT NULL,
  `so_entry_customer_id` int(11) NOT NULL,
  `so_entry_sales_type` int(11) NOT NULL,
  `so_entry_delivery_by` int(11) NOT NULL,
  `so_entry_salesmode_id` int(11) NOT NULL,
  `so_entry_so_type` int(11) NOT NULL,
  `so_entry_commercial_tax_status` int(11) NOT NULL,
  `so_entry_wholding_tax_status` int(11) NOT NULL,
  `so_entry_income_tax_status` int(11) NOT NULL,
  `so_entry_brand_id` int(11) NOT NULL,
  `so_entry_product_category_id` int(11) NOT NULL,
  `so_entry_promotion_id` int(11) NOT NULL,
  `so_entry_promotion_type` int(11) NOT NULL,
  `so_entry_commission_status` int(11) NOT NULL,
  `so_entry_salesman_id` int(11) NOT NULL,
  `so_entry_gross_amount` decimal(20,4) NOT NULL,
  `so_entry_lo_ul_amount` decimal(20,4) NOT NULL,
  `so_entry_tax_per` decimal(20,4) NOT NULL,
  `so_entry_tax_amount` decimal(20,4) NOT NULL,
  `so_entry_comm_tax_per` decimal(20,4) NOT NULL,
  `so_entry_comm_tax_amount` decimal(20,4) NOT NULL,
  `so_entry_withhld_tax_per` decimal(20,4) NOT NULL,
  `so_entry_withhld_tax_amount` decimal(20,4) NOT NULL,
  `so_entry_income_tax_per` decimal(20,4) NOT NULL,
  `so_entry_income_tax_amount` decimal(20,4) NOT NULL,
  `so_entry_freight_amount` decimal(20,4) NOT NULL,
  `so_entry_advance_amount` decimal(20,4) NOT NULL,
  `so_entry_net_amount` decimal(20,4) NOT NULL,
  `so_entry_remarks` text NOT NULL,
  `so_entry_company_id` int(11) NOT NULL,
  `so_entry_branch_id` int(11) NOT NULL,
  `so_entry_financial_year` int(11) NOT NULL,
  `so_entry_added_by` int(11) NOT NULL,
  `so_entry_added_on` int(11) NOT NULL,
  `so_entry_added_ip` varchar(20) NOT NULL,
  `so_entry_modified_by` int(11) NOT NULL,
  `so_entry_modified_on` int(11) NOT NULL,
  `so_entry_modified_ip` varchar(20) NOT NULL,
  `so_entry_deleted_by` int(11) NOT NULL,
  `so_entry_deleted_on` int(11) NOT NULL,
  `so_entry_deleted_ip` varchar(20) NOT NULL,
  `so_entry_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `so_entry`
--

INSERT INTO `so_entry` (`so_entry_id`, `so_entry_uniq_id`, `so_entry_no`, `so_entry_date`, `so_entry_customer_id`, `so_entry_sales_type`, `so_entry_delivery_by`, `so_entry_salesmode_id`, `so_entry_so_type`, `so_entry_commercial_tax_status`, `so_entry_wholding_tax_status`, `so_entry_income_tax_status`, `so_entry_brand_id`, `so_entry_product_category_id`, `so_entry_promotion_id`, `so_entry_promotion_type`, `so_entry_commission_status`, `so_entry_salesman_id`, `so_entry_gross_amount`, `so_entry_lo_ul_amount`, `so_entry_tax_per`, `so_entry_tax_amount`, `so_entry_comm_tax_per`, `so_entry_comm_tax_amount`, `so_entry_withhld_tax_per`, `so_entry_withhld_tax_amount`, `so_entry_income_tax_per`, `so_entry_income_tax_amount`, `so_entry_freight_amount`, `so_entry_advance_amount`, `so_entry_net_amount`, `so_entry_remarks`, `so_entry_company_id`, `so_entry_branch_id`, `so_entry_financial_year`, `so_entry_added_by`, `so_entry_added_on`, `so_entry_added_ip`, `so_entry_modified_by`, `so_entry_modified_on`, `so_entry_modified_ip`, `so_entry_deleted_by`, `so_entry_deleted_on`, `so_entry_deleted_ip`, `so_entry_deleted_status`) VALUES
(1, 'ad9dc78fnb38a7o4cdj70871fbfcb17edda5e563', '00001', '2017-09-01', 1, 2, 2, 2, 1, 2, 1, 2, 2, 0, 0, 0, 2, 0, '212250.0000', '2250.0000', '5.0000', '10612.5000', '0.0000', '0.0000', '5.0000', '10612.5000', '0.0000', '0.0000', '275.0000', '0.0000', '236000.0000', 'Ubenthiran', 0, 1, 1, 1, 1506077040, '::1', 0, 0, '', 0, 0, '', 0),
(2, '829e682xi34fe5r757h7416d4635ad84ed8686a8', '00002', '2017-09-04', 2, 2, 2, 3, 1, 1, 0, 1, 1, 0, 0, 0, 1, 1, '153000.0000', '7000.0000', '2.0000', '3060.0000', '3.0000', '4590.0000', '0.0000', '0.0000', '3.0000', '4590.0000', '760.0000', '0.0000', '173000.0000', 'Added Ubenthiran', 0, 1, 1, 1, 1506077212, '::1', 0, 0, '', 0, 0, '', 0),
(3, '076b906gibda5cwt6790fd7f7e349eaaaf6583e4', '00003', '2017-09-01', 2, 2, 2, 1, 2, 1, 0, 1, 2, 0, 0, 0, 2, 0, '372204.0000', '1500.0000', '2.0000', '7444.0800', '3.0000', '11166.1200', '0.0000', '0.0000', '1.0000', '3722.0400', '3000.0000', '0.0000', '399036.2400', '', 0, 1, 1, 1, 1506077533, '::1', 0, 0, '', 0, 0, '', 0),
(4, 'f41bd6amn26536di6mv1b895fd153bec34854a0d', '00004', '2017-09-07', 1, 2, 2, 1, 1, 2, 1, 2, 0, 0, 0, 0, 1, 2, '674550.0000', '5550.0000', '1.0000', '6745.5000', '0.0000', '0.0000', '2.0000', '13491.0000', '0.0000', '0.0000', '1250.0000', '0.0000', '701586.5000', 'Ubenthiran', 0, 1, 1, 1, 1506077882, '::1', 0, 0, '', 0, 0, '', 0),
(5, '42e529bele343c53f4r3d22fa34b612674fbcad1', '00005', '2017-09-13', 2, 2, 3, 1, 3, 1, 2, 1, 0, 0, 0, 0, 1, 1, '63205.0000', '2500.0000', '1.0000', '632.0500', '2.0000', '1264.1000', '0.0000', '0.0000', '4.0000', '2528.2000', '2500.0000', '0.0000', '72629.3500', 'Shankar', 0, 1, 1, 1, 1506078016, '::1', 0, 0, '', 0, 0, '', 0),
(6, 'f8e24ec27cf750b79za13fdfb2a7246ae4a2fe05', '00001', '2017-09-02', 1, 2, 2, 2, 3, 1, 2, 2, 0, 0, 0, 0, 0, 0, '7920.0000', '0.0000', '1.0000', '79.2000', '1.0000', '79.2000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '8078.4000', 'ew', 0, 2, 1, 1, 1506334605, '::1', 0, 0, '', 0, 0, '', 0),
(7, '575aa2cd3p48c605i4xebfa221af74812d0677f5', '00006', '2017-09-29', 1, 2, 3, 2, 1, 2, 1, 1, 0, 0, 0, 0, 0, 1, '114000.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '2.0000', '2280.0000', '5.0000', '5700.0000', '0.0000', '0.0000', '121980.0000', '', 0, 1, 1, 1, 1506681683, '103.25.77.15', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `so_entry_product_details`
--

CREATE TABLE `so_entry_product_details` (
  `so_entry_product_detail_id` int(11) NOT NULL,
  `so_entry_product_detail_uniq_id` varchar(255) NOT NULL,
  `so_entry_product_detail_so_entry_id` int(11) NOT NULL,
  `so_entry_product_detail_product_id` int(11) NOT NULL,
  `so_entry_product_detail_qty` decimal(20,4) NOT NULL,
  `so_entry_product_detail_rate` decimal(20,4) NOT NULL,
  `so_entry_product_detail_amount` decimal(20,4) NOT NULL,
  `so_entry_product_detail_discount_per` decimal(20,4) NOT NULL,
  `so_entry_product_detail_discount_amount` decimal(20,4) NOT NULL,
  `so_entry_product_detail_company_id` int(11) NOT NULL,
  `so_entry_product_detail_branch_id` int(11) NOT NULL,
  `so_entry_product_detail_financial_year` varchar(20) NOT NULL,
  `so_entry_product_detail_added_by` int(11) NOT NULL,
  `so_entry_product_detail_added_on` int(11) NOT NULL,
  `so_entry_product_detail_added_ip` varchar(20) NOT NULL,
  `so_entry_product_detail_modified_by` int(11) NOT NULL,
  `so_entry_product_detail_modified_on` int(11) NOT NULL,
  `so_entry_product_detail_modified_ip` varchar(20) NOT NULL,
  `so_entry_product_detail_deleted_by` int(11) NOT NULL,
  `so_entry_product_detail_deleted_on` int(11) NOT NULL,
  `so_entry_product_detail_deleted_ip` varchar(20) NOT NULL,
  `so_entry_product_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `so_entry_product_details`
--

INSERT INTO `so_entry_product_details` (`so_entry_product_detail_id`, `so_entry_product_detail_uniq_id`, `so_entry_product_detail_so_entry_id`, `so_entry_product_detail_product_id`, `so_entry_product_detail_qty`, `so_entry_product_detail_rate`, `so_entry_product_detail_amount`, `so_entry_product_detail_discount_per`, `so_entry_product_detail_discount_amount`, `so_entry_product_detail_company_id`, `so_entry_product_detail_branch_id`, `so_entry_product_detail_financial_year`, `so_entry_product_detail_added_by`, `so_entry_product_detail_added_on`, `so_entry_product_detail_added_ip`, `so_entry_product_detail_modified_by`, `so_entry_product_detail_modified_on`, `so_entry_product_detail_modified_ip`, `so_entry_product_detail_deleted_by`, `so_entry_product_detail_deleted_on`, `so_entry_product_detail_deleted_ip`, `so_entry_product_detail_deleted_status`) VALUES
(1, '065a0dfsbs7788ripdd556cd799d77c6cd071a9c', 1, 1, '10.0000', '9000.0000', '87300.0000', '3.0000', '2700.0000', 0, 0, '', 1, 1506077041, '::1', 0, 0, '', 0, 0, '', 0),
(2, '73b1a6ew9h7d9eu28y3613979f641f7330dd16b7', 1, 2, '15.0000', '8500.0000', '124950.0000', '2.0000', '2550.0000', 0, 0, '', 1, 1506077041, '::1', 0, 0, '', 0, 0, '', 0),
(3, '5360fc62ag1b9dbiilm72782e72de43b3d169049', 2, 4, '5.0000', '14000.0000', '63000.0000', '10.0000', '7000.0000', 0, 0, '', 1, 1506077212, '::1', 0, 0, '', 0, 0, '', 0),
(4, '25ed460zyrd8d97g6rg8caf99c0b940cbbf72b45', 2, 3, '5.0000', '20000.0000', '90000.0000', '10.0000', '10000.0000', 0, 0, '', 1, 1506077212, '::1', 0, 0, '', 0, 0, '', 0),
(5, 'b3a8bdfa801654xctypb1d32dcb1bc7f0a3dcf9c', 3, 1, '12.0000', '8900.0000', '104664.0000', '2.0000', '2136.0000', 0, 0, '', 1, 1506077533, '::1', 0, 0, '', 0, 0, '', 0),
(6, 'ad96e2ayhr5849xmcmg9e8df4fcf80fd73d60a4f', 3, 2, '13.0000', '21000.0000', '267540.0000', '2.0000', '5460.0000', 0, 0, '', 1, 1506077533, '::1', 0, 0, '', 0, 0, '', 0),
(7, 'a8e042bhbi128ebz5zkd504eed93352359eb31ae', 4, 1, '30.0000', '12000.0000', '352800.0000', '2.0000', '7200.0000', 0, 0, '', 1, 1506077882, '::1', 0, 0, '', 0, 0, '', 0),
(8, '32cd42dzaqb106yys0cfe3354edc3f72b91f4bae', 4, 3, '25.0000', '13000.0000', '321750.0000', '1.0000', '3250.0000', 0, 0, '', 1, 1506077882, '::1', 0, 0, '', 0, 0, '', 0),
(9, '1e687cbdfn3c65ahiwdc324ccfeb97826bd9fce6', 5, 2, '5.0000', '6500.0000', '31525.0000', '3.0000', '975.0000', 0, 0, '', 1, 1506078016, '::1', 0, 0, '', 0, 0, '', 0),
(10, 'bffd6355zd79f53kp10d4a8b4f5b891a6a0af6c0', 5, 3, '6.0000', '5500.0000', '31680.0000', '4.0000', '1320.0000', 0, 0, '', 1, 1506078016, '::1', 0, 0, '', 0, 0, '', 0),
(11, 'bd8014fqk864b60i1q8e1b5e62a1b59da46732cd', 6, 1, '1.0000', '3000.0000', '2970.0000', '1.0000', '30.0000', 0, 0, '', 1, 1506334605, '::1', 0, 0, '', 0, 0, '', 0),
(12, '6b9a936v6j2cfa5ox9hfe70cc677b7f688b050ec', 6, 2, '1.0000', '5000.0000', '4950.0000', '1.0000', '50.0000', 0, 0, '', 1, 1506334606, '::1', 0, 0, '', 0, 0, '', 0),
(13, 'f12c0f379vc0b4uoqes87c269f717a2756645731', 7, 5, '12.0000', '10000.0000', '114000.0000', '5.0000', '6000.0000', 0, 0, '', 1, 1506681683, '103.25.77.15', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `state_id` int(11) NOT NULL,
  `state_name` varchar(255) NOT NULL,
  `state_country_id` int(11) NOT NULL,
  `state_added_by` int(11) NOT NULL,
  `state_added_on` int(11) NOT NULL,
  `state_added_ip` varchar(20) NOT NULL,
  `state_modified_by` int(11) NOT NULL,
  `state_modified_on` int(11) NOT NULL,
  `state_modified_ip` varchar(20) NOT NULL,
  `state_deleted_by` int(11) NOT NULL,
  `state_deleted_on` int(11) NOT NULL,
  `state_deleted_ip` varchar(20) NOT NULL,
  `state_active_status` varchar(20) NOT NULL,
  `state_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`state_id`, `state_name`, `state_country_id`, `state_added_by`, `state_added_on`, `state_added_ip`, `state_modified_by`, `state_modified_on`, `state_modified_ip`, `state_deleted_by`, `state_deleted_on`, `state_deleted_ip`, `state_active_status`, `state_deleted_status`) VALUES
(1, 'Yangon', 1, 0, 0, '', 1, 1465888012, '192.168.1.2', 0, 0, '', 'active', 0),
(2, 'á€•á€²á€á€°á€¸', 1, 0, 0, '', 1, 1465888006, '192.168.1.2', 0, 0, '', 'active', 0),
(3, 'Tamil Nadu', 2, 1, 1506310491, '::1', 0, 0, '', 0, 0, '', 'active', 0),
(4, 'Bago', 1, 1, 1506745623, '103.25.77.148', 0, 0, '', 0, 0, '', 'active', 0),
(5, 'Mandalay', 1, 1, 1506745666, '103.25.77.148', 0, 0, '', 0, 0, '', 'active', 0),
(6, 'Hong Kong', 3, 1, 1512558316, '103.197.196.15', 0, 0, '', 0, 0, '', 'active', 0),
(7, 'Bangkok', 4, 1, 1513142701, '103.197.196.27', 0, 0, '', 0, 0, '', 'active', 0),
(8, 'Mawlamyaing', 1, 1, 1513745882, '103.197.196.6', 0, 0, '', 0, 0, '', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `stock_ledger`
--

CREATE TABLE `stock_ledger` (
  `stock_ledger_id` int(11) NOT NULL,
  `stock_ledger_type` varchar(50) NOT NULL,
  `stock_ledger_entry_id` int(11) NOT NULL,
  `stock_ledger_entry_detail_id` int(11) NOT NULL,
  `stock_ledger_product_id` int(11) NOT NULL,
  `stock_ledger_date` date NOT NULL,
  `stock_ledger_godown_id` int(11) NOT NULL,
  `stock_ledger_product_quantity` decimal(12,3) NOT NULL,
  `stock_ledger_trans_no` varchar(40) NOT NULL,
  `stock_ledger_entry_type` varchar(100) NOT NULL,
  `stock_ledger_prd_type` int(11) NOT NULL,
  `stock_ledger_product_length_inches` decimal(12,3) NOT NULL,
  `stock_ledger_product_width_inches` decimal(12,3) NOT NULL,
  `stock_ledger_customer_id` int(11) NOT NULL,
  `stock_ledger_company_id` int(11) NOT NULL,
  `stock_ledger_branch_id` int(11) NOT NULL,
  `stock_ledger_financial_year` varchar(20) NOT NULL,
  `stock_ledger_added_by` int(11) NOT NULL,
  `stock_ledger_added_on` int(11) NOT NULL,
  `stock_ledger_added_ip` varchar(20) NOT NULL,
  `stock_ledger_modified_by` int(11) NOT NULL,
  `stock_ledger_modified_on` int(11) NOT NULL,
  `stock_ledger_modified_ip` varchar(20) NOT NULL,
  `stock_ledger_deleted_by` int(11) NOT NULL,
  `stock_ledger_deleted_on` int(11) NOT NULL,
  `stock_ledger_deleted_ip` varchar(20) NOT NULL,
  `stock_ledger_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock_ledger`
--

INSERT INTO `stock_ledger` (`stock_ledger_id`, `stock_ledger_type`, `stock_ledger_entry_id`, `stock_ledger_entry_detail_id`, `stock_ledger_product_id`, `stock_ledger_date`, `stock_ledger_godown_id`, `stock_ledger_product_quantity`, `stock_ledger_trans_no`, `stock_ledger_entry_type`, `stock_ledger_prd_type`, `stock_ledger_product_length_inches`, `stock_ledger_product_width_inches`, `stock_ledger_customer_id`, `stock_ledger_company_id`, `stock_ledger_branch_id`, `stock_ledger_financial_year`, `stock_ledger_added_by`, `stock_ledger_added_on`, `stock_ledger_added_ip`, `stock_ledger_modified_by`, `stock_ledger_modified_on`, `stock_ledger_modified_ip`, `stock_ledger_deleted_by`, `stock_ledger_deleted_on`, `stock_ledger_deleted_ip`, `stock_ledger_status`) VALUES
(1, 'in', 10, 10, 21, '2017-12-16', 1, '500.000', '', 'purchase-grn', 1, '1.000', '1.000', 1, 1, 1, '1', 1, 1513398753, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(2, 'in', 10, 10, 21, '2017-12-16', 2, '500.000', '', 'purchase-grn', 1, '1.000', '1.000', 2, 1, 1, '1', 1, 1513398753, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(3, 'in', 11, 11, 21, '2017-12-16', 1, '300.000', '', 'purchase-grn', 1, '1.000', '1.000', 1, 1, 1, '1', 1, 1513398802, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(4, 'in', 11, 11, 21, '2017-12-16', 2, '300.000', '', 'purchase-grn', 1, '1.000', '1.000', 2, 1, 1, '1', 1, 1513398802, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(5, 'out', 6, 6, 21, '2017-12-16', 1, '-1000.000', 'Product Coin 0000001', 'product-con-detail', 1, '1.000', '1.000', 1, 1, 1, '1', 1, 1513399488, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(6, 'out', 6, 6, 21, '2017-12-16', 2, '-1000.000', 'Product Coin 0000001', 'product-con-detail', 1, '1.000', '1.000', 2, 1, 1, '1', 1, 1513399488, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(7, 'in', 6, 67, 67, '2017-12-16', 1, '1.000', 'Product Coin 0000001', 'product-con-entry', 2, '200.000', '36.000', 1, 1, 1, '1', 1, 1513399488, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(8, 'in', 6, 67, 67, '2017-12-16', 2, '1.000', 'Product Coin 0000001', 'product-con-entry', 2, '200.000', '36.000', 2, 1, 1, '1', 1, 1513399488, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(9, 'in', 6, 68, 68, '2017-12-16', 1, '1.000', 'Product Coin 0000001', 'product-con-entry', 2, '300.000', '36.000', 1, 1, 1, '1', 1, 1513399488, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(10, 'in', 6, 68, 68, '2017-12-16', 2, '1.000', 'Product Coin 0000001', 'product-con-entry', 2, '300.000', '36.000', 2, 1, 1, '1', 1, 1513399488, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(11, 'in', 6, 69, 69, '2017-12-16', 1, '1.000', 'Product Coin 0000001', 'product-con-entry', 2, '200.000', '36.000', 1, 1, 1, '1', 1, 1513399488, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(12, 'in', 6, 69, 69, '2017-12-16', 2, '1.000', 'Product Coin 0000001', 'product-con-entry', 2, '200.000', '36.000', 2, 1, 1, '1', 1, 1513399488, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(13, 'in', 6, 70, 70, '2017-12-16', 1, '1.000', 'Product Coin 0000001', 'product-con-entry', 2, '150.000', '36.000', 1, 1, 1, '1', 1, 1513399488, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(14, 'in', 6, 70, 70, '2017-12-16', 2, '1.000', 'Product Coin 0000001', 'product-con-entry', 2, '150.000', '36.000', 2, 1, 1, '1', 1, 1513399488, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(15, 'in', 6, 71, 71, '2017-12-16', 1, '1.000', 'Product Coin 0000001', 'product-con-entry', 2, '150.000', '36.000', 1, 1, 1, '1', 1, 1513399488, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(16, 'in', 6, 71, 71, '2017-12-16', 2, '1.000', 'Product Coin 0000001', 'product-con-entry', 2, '150.000', '36.000', 2, 1, 1, '1', 1, 1513399488, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(17, 'in', 12, 12, 21, '2017-12-16', 1, '200.000', '', 'purchase-grn', 1, '1.000', '1.000', 1, 1, 1, '1', 1, 1513399594, '203.81.71.134', 0, 0, '', 0, 0, '', 0),
(18, 'in', 12, 12, 21, '2017-12-16', 2, '200.000', '', 'purchase-grn', 1, '1.000', '1.000', 2, 1, 1, '1', 1, 1513399594, '203.81.71.134', 0, 0, '', 0, 0, '', 0),
(19, 'in', 13, 13, 26, '2017-12-16', 1, '10.000', '', 'purchase-grn', 1, '1.000', '1.000', 1, 1, 1, '1', 1, 1513400555, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(20, 'in', 13, 13, 26, '2017-12-16', 2, '10.000', '', 'purchase-grn', 1, '1.000', '1.000', 2, 1, 1, '1', 1, 1513400555, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(21, 'in', 14, 14, 4, '2017-12-16', 1, '1000.000', '', 'purchase-grn', 1, '1.000', '1.000', 1, 1, 1, '1', 1, 1513400871, '203.81.71.134', 0, 0, '', 0, 0, '', 0),
(22, 'in', 14, 14, 4, '2017-12-16', 2, '1000.000', '', 'purchase-grn', 1, '1.000', '1.000', 2, 1, 1, '1', 1, 1513400871, '203.81.71.134', 0, 0, '', 0, 0, '', 0),
(23, 'in', 14, 15, 22, '2017-12-16', 1, '2000.000', '', 'purchase-grn', 1, '1.000', '1.000', 1, 1, 1, '1', 1, 1513400871, '203.81.71.134', 0, 0, '', 0, 0, '', 0),
(24, 'in', 14, 15, 22, '2017-12-16', 2, '2000.000', '', 'purchase-grn', 1, '1.000', '1.000', 2, 1, 1, '1', 1, 1513400871, '203.81.71.134', 0, 0, '', 0, 0, '', 0),
(25, 'out', 8, 10, 67, '2017-12-16', 2, '-10.000', 'ad1612', 'advance', 0, '1.000', '3.000', 7, 1, 1, '1', 1, 1513402469, '203.81.71.134', 0, 0, '', 0, 0, '', 0),
(26, 'in', 15, 16, 28, '2017-12-17', 1, '27.000', '', 'purchase-grn', 1, '1.000', '1.000', 1, 1, 1, '1', 1, 1513402711, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(27, 'in', 15, 16, 28, '2017-12-17', 2, '27.000', '', 'purchase-grn', 1, '1.000', '1.000', 2, 1, 1, '1', 1, 1513402711, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(28, 'out', 19, 25, 67, '2017-12-16', 2, '-10.000', 'PO161201', 'production-order-sale', 1, '1.000', '0.000', 7, 1, 1, '1', 1, 1513402769, '203.81.71.134', 0, 0, '', 0, 0, '', 0),
(29, 'in', 16, 17, 4, '2017-12-16', 1, '1000.000', '', 'purchase-grn', 1, '1.000', '1.000', 1, 1, 1, '1', 1, 1513403050, '203.81.71.134', 0, 0, '', 0, 0, '', 0),
(30, 'in', 16, 17, 4, '2017-12-16', 2, '1000.000', '', 'purchase-grn', 1, '1.000', '1.000', 2, 1, 1, '1', 1, 1513403050, '203.81.71.134', 0, 0, '', 0, 0, '', 0),
(31, 'out', 7, 7, 28, '2017-12-17', 1, '-27.000', '99009900', 'product-con-detail', 1, '1.000', '1.000', 1, 1, 1, '1', 1, 1513403111, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(32, 'out', 7, 7, 28, '2017-12-17', 2, '-27.000', '99009900', 'product-con-detail', 1, '1.000', '1.000', 2, 1, 1, '1', 1, 1513403111, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(33, 'in', 7, 72, 72, '2017-12-17', 1, '1.000', '99009900', 'product-con-entry', 2, '6523.000', '36.000', 1, 1, 1, '1', 1, 1513403111, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(34, 'in', 7, 72, 72, '2017-12-17', 2, '1.000', '99009900', 'product-con-entry', 2, '6523.000', '36.000', 2, 1, 1, '1', 1, 1513403111, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(35, 'in', 7, 73, 73, '2017-12-17', 1, '1.000', '99009900', 'product-con-entry', 2, '6523.000', '36.000', 1, 1, 1, '1', 1, 1513403111, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(36, 'in', 7, 73, 73, '2017-12-17', 2, '1.000', '99009900', 'product-con-entry', 2, '6523.000', '36.000', 2, 1, 1, '1', 1, 1513403111, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(37, 'in', 7, 74, 74, '2017-12-17', 1, '1.000', '99009900', 'product-con-entry', 2, '6523.000', '36.000', 1, 1, 1, '1', 1, 1513403111, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(38, 'in', 7, 74, 74, '2017-12-17', 2, '1.000', '99009900', 'product-con-entry', 2, '6523.000', '36.000', 2, 1, 1, '1', 1, 1513403111, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(39, 'in', 7, 75, 75, '2017-12-17', 1, '1.000', '99009900', 'product-con-entry', 2, '6523.000', '36.000', 1, 1, 1, '1', 1, 1513403111, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(40, 'in', 7, 75, 75, '2017-12-17', 2, '1.000', '99009900', 'product-con-entry', 2, '6523.000', '36.000', 2, 1, 1, '1', 1, 1513403111, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(41, 'in', 7, 76, 76, '2017-12-17', 1, '1.000', '99009900', 'product-con-entry', 2, '6523.000', '36.000', 1, 1, 1, '1', 1, 1513403111, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(42, 'in', 7, 76, 76, '2017-12-17', 2, '1.000', '99009900', 'product-con-entry', 2, '6523.000', '36.000', 2, 1, 1, '1', 1, 1513403111, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(43, 'in', 7, 77, 77, '2017-12-17', 1, '1.000', '99009900', 'product-con-entry', 2, '6523.000', '36.000', 1, 1, 1, '1', 1, 1513403111, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(44, 'in', 7, 77, 77, '2017-12-17', 2, '1.000', '99009900', 'product-con-entry', 2, '6523.000', '36.000', 2, 1, 1, '1', 1, 1513403111, '103.242.98.226', 0, 0, '', 0, 0, '', 0),
(45, 'out', 20, 26, 5, '2017-12-16', 2, '-10.000', 'PO161202', 'production-order-sale', 1, '100.000', '432.000', 7, 1, 1, '1', 1, 1513403230, '203.81.71.134', 1, 1513403483, '203.81.71.134', 0, 0, '', 0),
(46, 'out', 8, 8, 4, '2017-12-16', 1, '-1000.000', 'PC161201', 'product-con-detail', 1, '1.000', '1.000', 1, 1, 1, '1', 1, 1513408085, '203.81.71.134', 0, 0, '', 0, 0, '', 0),
(47, 'out', 8, 8, 4, '2017-12-16', 2, '-1000.000', 'PC161201', 'product-con-detail', 1, '1.000', '1.000', 2, 1, 1, '1', 1, 1513408085, '203.81.71.134', 0, 0, '', 0, 0, '', 0),
(48, 'in', 8, 78, 78, '2017-12-16', 1, '1.000', 'PC161201', 'product-con-entry', 2, '10.000', '36.000', 1, 1, 1, '1', 1, 1513408085, '203.81.71.134', 0, 0, '', 0, 0, '', 0),
(49, 'in', 8, 78, 78, '2017-12-16', 2, '1.000', 'PC161201', 'product-con-entry', 2, '10.000', '36.000', 2, 1, 1, '1', 1, 1513408085, '203.81.71.134', 0, 0, '', 0, 0, '', 0),
(50, 'out', 9, 9, 4, '2017-12-16', 1, '-1000.000', '9121', 'product-con-detail', 1, '1.000', '1.000', 1, 1, 1, '1', 1, 1513408193, '103.242.98.48', 0, 0, '', 0, 0, '', 0),
(51, 'out', 9, 9, 4, '2017-12-16', 2, '-1000.000', '9121', 'product-con-detail', 1, '1.000', '1.000', 2, 1, 1, '1', 1, 1513408193, '103.242.98.48', 0, 0, '', 0, 0, '', 0),
(52, 'in', 9, 79, 79, '2017-12-16', 1, '1.000', '9121', 'product-con-entry', 2, '10.000', '36.000', 1, 1, 1, '1', 1, 1513408193, '103.242.98.48', 0, 0, '', 0, 0, '', 0),
(53, 'in', 9, 79, 79, '2017-12-16', 2, '1.000', '9121', 'product-con-entry', 2, '10.000', '36.000', 2, 1, 1, '1', 1, 1513408193, '103.242.98.48', 0, 0, '', 0, 0, '', 0),
(54, 'in', 17, 18, 4, '2017-12-16', 1, '5000.000', '', 'purchase-grn', 1, '1.000', '1.000', 1, 1, 1, '1', 1, 1513408277, '203.81.71.134', 1, 1513408361, '203.81.71.134', 0, 0, '', 0),
(55, 'in', 17, 18, 4, '2017-12-16', 2, '5000.000', '', 'purchase-grn', 1, '1.000', '1.000', 2, 1, 1, '1', 1, 1513408277, '203.81.71.134', 1, 1513408361, '203.81.71.134', 0, 0, '', 0),
(56, 'out', 10, 10, 4, '2017-12-16', 1, '-10.000', 'pc', 'product-con-detail', 1, '1.000', '1.000', 1, 1, 1, '1', 1, 1513408585, '203.81.71.134', 0, 0, '', 0, 0, '', 0),
(57, 'out', 10, 10, 4, '2017-12-16', 2, '-10.000', 'pc', 'product-con-detail', 1, '1.000', '1.000', 2, 1, 1, '1', 1, 1513408585, '203.81.71.134', 0, 0, '', 0, 0, '', 0),
(58, 'out', 11, 11, 4, '2017-12-16', 1, '-1000.000', '121', 'product-con-detail', 1, '1.000', '1.000', 1, 1, 1, '1', 1, 1513411352, '203.81.71.134', 1, 1513411386, '203.81.71.134', 0, 0, '', 0),
(59, 'out', 11, 11, 4, '2017-12-16', 2, '-1000.000', '121', 'product-con-detail', 1, '1.000', '1.000', 2, 1, 1, '1', 1, 1513411352, '203.81.71.134', 1, 1513411386, '203.81.71.134', 0, 0, '', 0),
(60, 'in', 11, 80, 80, '2017-12-16', 1, '1.000', '121', 'product-con-entry', 2, '1000.000', '36.000', 1, 1, 1, '1', 1, 1513411352, '203.81.71.134', 1, 1513411386, '203.81.71.134', 0, 0, '', 0),
(61, 'in', 11, 80, 80, '2017-12-16', 2, '1.000', '121', 'product-con-entry', 2, '1000.000', '36.000', 2, 1, 1, '1', 1, 1513411352, '203.81.71.134', 1, 1513411386, '203.81.71.134', 0, 0, '', 0),
(62, 'in', 15, 1, 0, '0000-00-00', 1, '1.000', '00001', 'invoice-entry', 2, '1000.000', '36.000', 1, 1, 4, '1', 1, 1514866744, '122.174.33.217', 0, 0, '', 0, 0, '', 0),
(63, 'in', 15, 2, 0, '0000-00-00', 1, '1.000', '00001', 'invoice-entry', 2, '2000.000', '36.000', 1, 1, 4, '1', 1, 1514866744, '122.174.33.217', 0, 0, '', 0, 0, '', 0),
(64, 'in', 16, 3, 0, '0000-00-00', 1, '1.000', '00001', 'invoice-entry', 2, '1000.000', '36.000', 1, 1, 3, '1', 1, 1514866787, '103.197.196.14', 0, 0, '', 0, 0, '', 0),
(65, 'in', 16, 4, 0, '0000-00-00', 1, '1.000', '00001', 'invoice-entry', 2, '2000.000', '48.000', 1, 1, 3, '1', 1, 1514866787, '103.197.196.14', 0, 0, '', 0, 0, '', 0),
(66, 'in', 18, 5, 0, '0000-00-00', 1, '1.000', '00015', 'invoice-entry', 2, '100.000', '36.000', 1, 1, 1, '1', 1, 1514870213, '103.197.196.14', 0, 0, '', 0, 0, '', 0),
(67, 'in', 18, 6, 0, '0000-00-00', 1, '1.000', '00015', 'invoice-entry', 2, '200.000', '36.000', 1, 1, 1, '1', 1, 1514870213, '103.197.196.14', 0, 0, '', 0, 0, '', 0),
(68, 'in', 18, 7, 0, '0000-00-00', 1, '1.000', '00015', 'invoice-entry', 2, '100.000', '36.000', 1, 1, 1, '1', 1, 1514870213, '103.197.196.14', 0, 0, '', 0, 0, '', 0),
(69, 'in', 19, 8, 0, '0000-00-00', 1, '1.000', '00016', 'invoice-entry', 2, '100.000', '36.000', 1, 1, 1, '1', 1, 1514870493, '103.197.196.14', 0, 0, '', 0, 0, '', 0),
(70, 'in', 19, 9, 0, '0000-00-00', 1, '1.000', '00016', 'invoice-entry', 2, '100.000', '36.000', 1, 1, 1, '1', 1, 1514870494, '103.197.196.14', 0, 0, '', 0, 0, '', 0),
(71, 'in', 19, 10, 0, '0000-00-00', 1, '1.000', '00016', 'invoice-entry', 2, '100.000', '36.000', 1, 1, 1, '1', 1, 1514870494, '103.197.196.14', 0, 0, '', 0, 0, '', 0),
(72, 'in', 1, 1, 7, '2018-01-03', 1, '4.000', '', 'purchase-grn-product', 1, '1.000', '1.000', 1, 1, 2, '1', 1, 1514985698, '122.174.33.217', 0, 0, '', 0, 0, '', 0),
(73, 'in', 1, 1, 7, '2018-01-03', 2, '4.000', '', 'purchase-grn-product', 1, '1.000', '1.000', 2, 1, 2, '1', 1, 1514985698, '122.174.33.217', 0, 0, '', 0, 0, '', 0),
(74, 'in', 1, 1, 5, '2018-01-03', 1, '1.000', '00001', 'purchase-grn', 2, '0.000', '0.000', 1, 1, 2, '1', 1, 1514985698, '122.174.33.217', 0, 0, '', 0, 0, '', 0),
(75, 'in', 1, 1, 7, '2018-01-04', 1, '1.000', '00001', 'purchase-grn', 2, '0.000', '0.000', 1, 1, 4, '1', 1, 1515041573, '103.197.196.14', 0, 0, '', 0, 0, '', 0),
(76, 'in', 1, 2, 8, '2018-01-04', 1, '1.000', '00001', 'purchase-grn', 2, '0.000', '0.000', 1, 1, 4, '1', 1, 1515041573, '103.197.196.14', 0, 0, '', 0, 0, '', 0),
(77, 'in', 1, 3, 9, '2018-01-04', 1, '1.000', '00001', 'purchase-grn', 2, '0.000', '0.000', 1, 1, 4, '1', 1, 1515041573, '103.197.196.14', 0, 0, '', 0, 0, '', 0),
(78, 'in', 1, 4, 10, '2018-01-04', 1, '1.000', '00001', 'purchase-grn', 2, '0.000', '0.000', 1, 1, 4, '1', 1, 1515041573, '103.197.196.14', 0, 0, '', 0, 0, '', 0),
(79, 'out', 1, 1, 1, '2018-01-04', 1, '-1.000', '', 'debit-note-entry', 2, '0.000', '0.000', 1, 1, 4, '1', 1, 1515042868, '103.197.196.14', 0, 0, '', 0, 0, '', 0),
(80, 'out', 9, 11, 5, '2018-01-04', 2, '-100.000', 'Ad14', 'advance', 0, '200.000', '3.000', 7, 1, 4, '1', 1, 1515043182, '103.197.196.14', 0, 0, '', 0, 0, '', 0),
(81, 'in', 2, 5, 11, '2018-01-04', 1, '1.000', '00002', 'purchase-grn', 2, '0.000', '0.000', 1, 1, 4, '1', 1, 1515047749, '103.197.196.14', 0, 0, '', 0, 0, '', 0),
(82, 'in', 2, 6, 12, '2018-01-04', 1, '1.000', '00002', 'purchase-grn', 2, '0.000', '0.000', 1, 1, 4, '1', 1, 1515047749, '103.197.196.14', 0, 0, '', 0, 0, '', 0),
(83, 'in', 3, 7, 13, '2018-01-05', 1, '1.000', '00003', 'purchase-grn', 2, '0.000', '0.000', 1, 1, 4, '1', 1, 1515126668, '103.197.196.24', 0, 0, '', 0, 0, '', 0),
(84, 'in', 3, 8, 14, '2018-01-05', 1, '1.000', '00003', 'purchase-grn', 2, '0.000', '0.000', 1, 1, 4, '1', 1, 1515126668, '103.197.196.24', 0, 0, '', 0, 0, '', 0),
(85, 'in', 3, 9, 15, '2018-01-05', 1, '1.000', '00003', 'purchase-grn', 2, '0.000', '0.000', 1, 1, 4, '1', 1, 1515126668, '103.197.196.24', 0, 0, '', 0, 0, '', 0),
(86, 'in', 3, 10, 16, '2018-01-05', 1, '1.000', '00003', 'purchase-grn', 2, '0.000', '0.000', 1, 1, 4, '1', 1, 1515126668, '103.197.196.24', 0, 0, '', 0, 0, '', 0),
(87, 'in', 3, 11, 17, '2018-01-05', 1, '1.000', '00003', 'purchase-grn', 2, '0.000', '0.000', 1, 1, 4, '1', 1, 1515126668, '103.197.196.24', 0, 0, '', 0, 0, '', 0),
(88, 'in', 3, 12, 18, '2018-01-05', 1, '1.000', '00003', 'purchase-grn', 2, '0.000', '0.000', 1, 1, 4, '1', 1, 1515126668, '103.197.196.24', 0, 0, '', 0, 0, '', 0),
(89, 'in', 4, 1, 26, '2018-01-05', 1, '100.000', '', 'purchase-grn-product', 1, '1.000', '1.000', 1, 1, 4, '1', 1, 1515127313, '103.197.196.24', 0, 0, '', 0, 0, '', 0),
(90, 'in', 4, 1, 26, '2018-01-05', 2, '100.000', '', 'purchase-grn-product', 1, '1.000', '1.000', 2, 1, 4, '1', 1, 1515127313, '103.197.196.24', 0, 0, '', 0, 0, '', 0),
(91, 'in', 5, 13, 19, '2018-01-05', 1, '1.000', '00005', 'purchase-grn', 2, '0.000', '0.000', 1, 1, 1, '1', 1, 1515129086, '103.197.196.24', 0, 0, '', 0, 0, '', 0),
(92, 'in', 5, 14, 20, '2018-01-05', 1, '1.000', '00005', 'purchase-grn', 2, '0.000', '0.000', 1, 1, 1, '1', 1, 1515129086, '103.197.196.24', 0, 0, '', 0, 0, '', 0),
(93, 'in', 5, 15, 21, '2018-01-05', 1, '1.000', '00005', 'purchase-grn', 2, '0.000', '0.000', 1, 1, 1, '1', 1, 1515129086, '103.197.196.24', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `stock_ledger_sales`
--

CREATE TABLE `stock_ledger_sales` (
  `stock_ledger_id` int(11) NOT NULL,
  `stock_ledger_type` varchar(50) NOT NULL,
  `stock_ledger_entry_id` int(11) NOT NULL,
  `stock_ledger_entry_detail_id` int(11) NOT NULL,
  `stock_ledger_product_id` int(11) NOT NULL,
  `stock_ledger_date` date NOT NULL,
  `stock_ledger_godown_id` int(11) NOT NULL,
  `stock_ledger_product_quantity` decimal(12,3) NOT NULL,
  `stock_ledger_trans_no` varchar(40) NOT NULL,
  `stock_ledger_entry_type` varchar(100) NOT NULL,
  `stock_ledger_prd_type` int(11) NOT NULL,
  `stock_ledger_product_length_inches` decimal(12,3) NOT NULL,
  `stock_ledger_product_width_inches` decimal(12,3) NOT NULL,
  `stock_ledger_customer_id` int(11) NOT NULL,
  `stock_ledger_company_id` int(11) NOT NULL,
  `stock_ledger_branch_id` int(11) NOT NULL,
  `stock_ledger_financial_year` varchar(20) NOT NULL,
  `stock_ledger_added_by` int(11) NOT NULL,
  `stock_ledger_added_on` int(11) NOT NULL,
  `stock_ledger_added_ip` varchar(20) NOT NULL,
  `stock_ledger_modified_by` int(11) NOT NULL,
  `stock_ledger_modified_on` int(11) NOT NULL,
  `stock_ledger_modified_ip` varchar(20) NOT NULL,
  `stock_ledger_deleted_by` int(11) NOT NULL,
  `stock_ledger_deleted_on` int(11) NOT NULL,
  `stock_ledger_deleted_ip` varchar(20) NOT NULL,
  `stock_ledger_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `stock_transfer`
--

CREATE TABLE `stock_transfer` (
  `stock_transfer_id` int(11) NOT NULL,
  `stock_transfer_uniq_id` varchar(255) NOT NULL,
  `stock_transfer_no` varchar(30) NOT NULL,
  `stock_transfer_date` date NOT NULL,
  `stock_transfer_from_godown_id` int(11) NOT NULL,
  `stock_transfer_to_godown_id` int(11) NOT NULL,
  `stock_transfer_company_id` int(11) NOT NULL,
  `stock_transfer_branch_id` int(11) NOT NULL,
  `stock_transfer_financial_year` int(11) NOT NULL,
  `stock_transfer_added_by` int(11) NOT NULL,
  `stock_transfer_added_on` int(11) NOT NULL,
  `stock_transfer_added_ip` varchar(20) NOT NULL,
  `stock_transfer_modified_by` int(11) NOT NULL,
  `stock_transfer_modified_on` int(11) NOT NULL,
  `stock_transfer_modified_ip` varchar(20) NOT NULL,
  `stock_transfer_deleted_by` int(11) NOT NULL,
  `stock_transfer_deleted_on` int(11) NOT NULL,
  `stock_transfer_deleted_ip` varchar(20) NOT NULL,
  `stock_transfer_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `stock_transfer_product_details`
--

CREATE TABLE `stock_transfer_product_details` (
  `stock_transfer_product_detail_id` int(11) NOT NULL,
  `stock_transfer_product_detail_uniq_id` varchar(255) NOT NULL,
  `stock_transfer_product_detail_stock_transfer_id` int(11) NOT NULL,
  `stock_transfer_product_detail_product_id` int(11) NOT NULL,
  `stock_transfer_product_detail_uom2` int(11) NOT NULL,
  `stock_transfer_product_detail_qty` decimal(20,4) NOT NULL,
  `stock_transfer_product_detail_company_id` int(11) NOT NULL,
  `stock_transfer_product_detail_branch_id` int(11) NOT NULL,
  `stock_transfer_product_detail_financial_year` varchar(20) NOT NULL,
  `stock_transfer_product_detail_added_by` int(11) NOT NULL,
  `stock_transfer_product_detail_added_on` int(11) NOT NULL,
  `stock_transfer_product_detail_added_ip` varchar(20) NOT NULL,
  `stock_transfer_product_detail_modified_by` int(11) NOT NULL,
  `stock_transfer_product_detail_modified_on` int(11) NOT NULL,
  `stock_transfer_product_detail_modified_ip` varchar(20) NOT NULL,
  `stock_transfer_product_detail_deleted_by` int(11) NOT NULL,
  `stock_transfer_product_detail_deleted_on` int(11) NOT NULL,
  `stock_transfer_product_detail_deleted_ip` varchar(20) NOT NULL,
  `stock_transfer_product_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `supplier_id` int(11) NOT NULL,
  `supplier_uniq_id` varchar(100) NOT NULL,
  `supplier_code` varchar(10) NOT NULL,
  `supplier_name` varchar(80) NOT NULL,
  `supplier_company_name` varchar(100) NOT NULL,
  `supplier_billing_address` text NOT NULL,
  `supplier_shipping_address` text NOT NULL,
  `supplier_country_id` int(11) NOT NULL,
  `supplier_state_id` int(11) NOT NULL,
  `supplier_city_id` int(11) NOT NULL,
  `supplier_mobile_no` varchar(40) NOT NULL,
  `supplier_line_phone` varchar(40) NOT NULL,
  `supplier_contact_no` varchar(40) NOT NULL,
  `supplier_email` varchar(40) NOT NULL,
  `supplier_zip_code` varchar(40) NOT NULL,
  `supplier_fax_no` varchar(40) NOT NULL,
  `supplier_currency_id` int(11) NOT NULL,
  `supplier_minimum_credit_per_day` decimal(12,3) NOT NULL,
  `supplier_block_status` int(11) NOT NULL,
  `supplier_location` int(11) NOT NULL,
  `supplier_minimum_sales_limit` decimal(12,3) NOT NULL,
  `supplier_supplier_type_id` int(11) NOT NULL,
  `supplier_total_credit_limit` decimal(12,3) NOT NULL,
  `supplier_payment_days` int(11) NOT NULL,
  `supplier_company_id` int(11) NOT NULL,
  `supplier_added_by` int(11) NOT NULL,
  `supplier_added_on` int(11) NOT NULL,
  `supplier_added_ip` varchar(20) NOT NULL,
  `supplier_modified_by` int(11) NOT NULL,
  `supplier_modified_on` int(11) NOT NULL,
  `supplier_modified_ip` varchar(20) NOT NULL,
  `supplier_deleted_by` int(11) NOT NULL,
  `supplier_deleted_on` int(11) NOT NULL,
  `supplier_deleted_ip` varchar(20) NOT NULL,
  `supplier_active_status` varchar(20) NOT NULL DEFAULT 'active',
  `supplier_deleted_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`supplier_id`, `supplier_uniq_id`, `supplier_code`, `supplier_name`, `supplier_company_name`, `supplier_billing_address`, `supplier_shipping_address`, `supplier_country_id`, `supplier_state_id`, `supplier_city_id`, `supplier_mobile_no`, `supplier_line_phone`, `supplier_contact_no`, `supplier_email`, `supplier_zip_code`, `supplier_fax_no`, `supplier_currency_id`, `supplier_minimum_credit_per_day`, `supplier_block_status`, `supplier_location`, `supplier_minimum_sales_limit`, `supplier_supplier_type_id`, `supplier_total_credit_limit`, `supplier_payment_days`, `supplier_company_id`, `supplier_added_by`, `supplier_added_on`, `supplier_added_ip`, `supplier_modified_by`, `supplier_modified_on`, `supplier_modified_ip`, `supplier_deleted_by`, `supplier_deleted_on`, `supplier_deleted_ip`, `supplier_active_status`, `supplier_deleted_status`) VALUES
(1, 'f3d3a7brbx052ft11k818d69c38906eba984c5c6', 'SP000001', 'Ubenthiran', 'ASDF', 'Chennai', 'Vellore', 1, 1, 4, '456514412', '', '', '', '', '', 1, '0.000', 2, 1, '0.000', 0, '0.000', 0, 0, 1, 1506338022, '0', 0, 0, '', 0, 0, '', 'active', 0),
(2, 'e07d493ncq22792yzb48cb5cdfd8ddc668c80df0', 'SP000002', 'VE', 'VE Company', 'Myanmar , Soth Okkalar Township', 'Myanmar , Soth Okkalar Township', 1, 1, 1, '09979790828', '01383875', '01383876', 've@gmail.com', '', '', 2, '2.000', 2, 1, '2.000', 1, '300000.000', 1, 0, 1, 1506494809, '103', 1, 1506495009, '', 0, 0, '', 'active', 0),
(3, 'ae7a640c53852e5rwtzd8e965ba2a3b271aa0030', 'S 0099', 'Supplier Test', 'Test Company Limited', 'Other', 'China', 3, 6, 9, '998876554', '', '', 'suppliertest@gmail.com', '', '', 2, '0.000', 2, 2, '0.000', 0, '0.000', 0, 1, 1, 1512714879, '103', 0, 0, '', 0, 0, '', 'active', 0),
(4, 'b985eb7var4a156thr889b9472809c1192c3df02', 'Thaisup99', 'Thai Supplier', 'Thailand Coin Company Limited', 'Thailand', 'Thailand', 4, 7, 10, '213122313', '1231212', '11231231243', 'thailandsupplier@gmail.com', '', '', 0, '0.000', 2, 2, '0.000', 0, '0.000', 0, 1, 1, 1513142893, '103', 0, 0, '', 0, 0, '', 'active', 0),
(5, 'aa1cca9r8dd4bb7a0qa6277c680037d5a2e23df0', '0000001', '0000001', 'Other', 'Other', 'Other', 4, 7, 10, '312313131', '123123', '123231312312', '0000001@gmail.com', '', '', 0, '0.000', 2, 1, '0.000', 0, '0.000', 0, 1, 1, 1513312958, '203', 0, 0, '', 0, 0, '', 'active', 0),
(6, 'dd18da5ooa5e70ec12b447b462ab988bdceb39db', '', 'Global', 'Global', 'mawlamyaing', 'mawlamyaing', 1, 8, 11, '14212', '1324', '143435', 'global@gmail.com', '1', '14315', 3, '2.000', 2, 1, '2.000', 3, '14535.000', 4, 1, 1, 1513746193, '103', 1, 1513746315, '', 0, 0, '', 'active', 0),
(7, '7d98fa0ezj6554uej6b73f99951ea5d41892ba8a', '', 'Maung Phyu', 'Company Limited', 'Yangon', 'Yangon', 1, 1, 3, '09878778786', '', '', 'maungphyu@gmail.com', '', '', 0, '0.000', 2, 1, '0.000', 0, '0.000', 0, 1, 1, 1514866902, '103', 0, 0, '', 0, 0, '', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `supplier_multi_contacts`
--

CREATE TABLE `supplier_multi_contacts` (
  `supplier_multi_contact_id` int(11) NOT NULL,
  `supplier_multi_contact_supplier_id` int(11) NOT NULL,
  `supplier_multi_contact_title` varchar(80) NOT NULL,
  `supplier_multi_contact_name` varchar(80) NOT NULL,
  `supplier_multi_contact_department` varchar(80) NOT NULL,
  `supplier_multi_contact_mobile_no` varchar(40) NOT NULL,
  `supplier_multi_contact_email` varchar(80) NOT NULL,
  `supplier_multi_contact_extn_no` int(5) NOT NULL,
  `supplier_multi_contact_added_by` int(11) NOT NULL,
  `supplier_multi_contact_added_on` int(11) NOT NULL,
  `supplier_multi_contact_added_ip` varchar(20) NOT NULL,
  `supplier_multi_contact_modified_by` int(11) NOT NULL,
  `supplier_multi_contact_modified_on` int(11) NOT NULL,
  `supplier_multi_contact_modified_ip` varchar(20) NOT NULL,
  `supplier_multi_contact_deleted_by` int(11) NOT NULL,
  `supplier_multi_contact_deleted_on` int(11) NOT NULL,
  `supplier_multi_contact_deleted_ip` int(20) NOT NULL,
  `supplier_multi_contact_deleted_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier_multi_contacts`
--

INSERT INTO `supplier_multi_contacts` (`supplier_multi_contact_id`, `supplier_multi_contact_supplier_id`, `supplier_multi_contact_title`, `supplier_multi_contact_name`, `supplier_multi_contact_department`, `supplier_multi_contact_mobile_no`, `supplier_multi_contact_email`, `supplier_multi_contact_extn_no`, `supplier_multi_contact_added_by`, `supplier_multi_contact_added_on`, `supplier_multi_contact_added_ip`, `supplier_multi_contact_modified_by`, `supplier_multi_contact_modified_on`, `supplier_multi_contact_modified_ip`, `supplier_multi_contact_deleted_by`, `supplier_multi_contact_deleted_on`, `supplier_multi_contact_deleted_ip`, `supplier_multi_contact_deleted_status`) VALUES
(1, 3, 'Mr.', 'Test Person', 'Other', '9988123112', 'testperson@gmail.com', 90909, 1, 1512714879, '103.197.196.19', 0, 0, '', 0, 0, 0, 0),
(2, 6, 'Mr.', 'Aung', 'Sale', '678990999', 'aung@gmail.com', 889990, 1, 1513746193, '103.197.196.6', 1, 1513746315, '', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `supplier_types`
--

CREATE TABLE `supplier_types` (
  `supplier_type_id` int(11) NOT NULL,
  `supplier_type_uniq_id` varchar(100) NOT NULL,
  `supplier_type_name` varchar(80) NOT NULL,
  `supplier_type_company_id` int(11) NOT NULL,
  `supplier_type_added_by` int(11) NOT NULL,
  `supplier_type_added_on` int(11) NOT NULL,
  `supplier_type_added_ip` varchar(20) NOT NULL,
  `supplier_type_modified_by` int(11) NOT NULL,
  `supplier_type_modified_on` int(11) NOT NULL,
  `supplier_type_modified_ip` varchar(20) NOT NULL,
  `supplier_type_deleted_by` int(11) NOT NULL,
  `supplier_type_deleted_on` int(11) NOT NULL,
  `supplier_type_deleted_ip` varchar(20) NOT NULL,
  `supplier_type_active_status` varchar(20) NOT NULL DEFAULT 'active',
  `supplier_type_deleted_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier_types`
--

INSERT INTO `supplier_types` (`supplier_type_id`, `supplier_type_uniq_id`, `supplier_type_name`, `supplier_type_company_id`, `supplier_type_added_by`, `supplier_type_added_on`, `supplier_type_added_ip`, `supplier_type_modified_by`, `supplier_type_modified_on`, `supplier_type_modified_ip`, `supplier_type_deleted_by`, `supplier_type_deleted_on`, `supplier_type_deleted_ip`, `supplier_type_active_status`, `supplier_type_deleted_status`) VALUES
(1, '342468cihv7685oe0w8a6935a104a8ad2f2b1555', 'Agent', 0, 1, 1506157992, '::1', 0, 0, '', 0, 0, '', 'active', 0),
(2, 'f2ed3a9mld7db1v5ofa255232c173d40addf0af1', 'Supplier Type 2', 1, 1, 1512714584, '103.197.196.19', 0, 0, '', 0, 0, '', 'active', 0),
(3, 'f53857apg41594bsw8803bffa989504ed388eb2a', 'Oversea 1', 1, 1, 1513746026, '103.197.196.6', 0, 0, '', 0, 0, '', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_uniq_id` varchar(40) NOT NULL,
  `user_username` varchar(40) NOT NULL,
  `user_password` varchar(40) NOT NULL,
  `user_name` varchar(80) NOT NULL,
  `user_contact_no` varchar(80) NOT NULL,
  `user_email` varchar(80) NOT NULL,
  `user_level` varchar(80) NOT NULL,
  `user_accessibilities` text NOT NULL,
  `user_branch_ids` text NOT NULL,
  `user_company_ids` text NOT NULL,
  `user_last_login` int(11) NOT NULL,
  `user_login_status` tinyint(1) NOT NULL,
  `user_added_by` int(11) NOT NULL,
  `user_added_on` int(11) NOT NULL,
  `user_added_ip` varchar(20) NOT NULL,
  `user_modified_by` int(11) NOT NULL,
  `user_modified_on` int(11) NOT NULL,
  `user_modified_ip` varchar(20) NOT NULL,
  `user_deleted_by` int(11) NOT NULL,
  `user_deleted_on` int(11) NOT NULL,
  `user_deleted_ip` varchar(20) NOT NULL,
  `user_active_status` varchar(20) NOT NULL DEFAULT 'active',
  `user_delete_status` tinyint(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_uniq_id`, `user_username`, `user_password`, `user_name`, `user_contact_no`, `user_email`, `user_level`, `user_accessibilities`, `user_branch_ids`, `user_company_ids`, `user_last_login`, `user_login_status`, `user_added_by`, `user_added_on`, `user_added_ip`, `user_modified_by`, `user_modified_on`, `user_modified_ip`, `user_deleted_by`, `user_deleted_on`, `user_deleted_ip`, `user_active_status`, `user_delete_status`) VALUES
(1, '18ae7b5axy0b60b6cg9a980d01a495a18daab35c', 'admin', 'e64b78f0bnc3bcada9q91bcbc7dc232ba8ec59e0', 'Administrator', '', '', 'superadmin', '0', 'all', '1,2', 0, 0, 0, 0, '', 1, 1467283369, '::1', 0, 0, '', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `vendors`
--

CREATE TABLE `vendors` (
  `vendor_id` int(11) NOT NULL,
  `vendor_uniq_id` varchar(50) NOT NULL,
  `vendor_code` varchar(20) NOT NULL,
  `vendor_name` varchar(80) NOT NULL,
  `vendor_contact_no` varchar(40) NOT NULL,
  `vendor_address` varchar(200) NOT NULL,
  `vendor_service` int(11) NOT NULL,
  `vendor_spi_in` varchar(100) NOT NULL,
  `vendor_payment_mode` int(11) NOT NULL,
  `vendor_payment_day` int(11) NOT NULL,
  `vendor_contract_no` int(50) NOT NULL,
  `vendor_contract_vaild_from` date NOT NULL,
  `vendor_contract_expire_date` date NOT NULL,
  `vendor_active_status` int(11) NOT NULL,
  `vendor_company_id` int(11) NOT NULL,
  `vendor_added_by` int(11) NOT NULL,
  `vendor_added_on` int(11) NOT NULL,
  `vendor_added_ip` int(11) NOT NULL,
  `vendor_modified_by` int(11) NOT NULL,
  `vendor_modified_on` int(11) NOT NULL,
  `vendor_modified_ip` int(11) NOT NULL,
  `vendor_deleted_by` int(11) NOT NULL,
  `vendor_deleted_on` int(11) NOT NULL,
  `vendor_deleted_ip` int(11) NOT NULL,
  `vendor_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendors`
--

INSERT INTO `vendors` (`vendor_id`, `vendor_uniq_id`, `vendor_code`, `vendor_name`, `vendor_contact_no`, `vendor_address`, `vendor_service`, `vendor_spi_in`, `vendor_payment_mode`, `vendor_payment_day`, `vendor_contract_no`, `vendor_contract_vaild_from`, `vendor_contract_expire_date`, `vendor_active_status`, `vendor_company_id`, `vendor_added_by`, `vendor_added_on`, `vendor_added_ip`, `vendor_modified_by`, `vendor_modified_on`, `vendor_modified_ip`, `vendor_deleted_by`, `vendor_deleted_on`, `vendor_deleted_ip`, `vendor_status`) VALUES
(1, 'b522627lol8095ed2kwfb503b89177fb776fa87a', 'V00001', 'Jaya Prakash', '2147483647', 'chennai', 1, '10', 1, 10, 2147483647, '2017-05-01', '2018-05-01', 1, 0, 1, 1504507787, 0, 0, 0, 0, 0, 0, 0, 0),
(2, 'cae52ecpuxcd61f15ql92d92958951d4f75848fb', 'V001', 'Kyaw Kyaw', '9', 'Yangon', 2, 'Test', 1, 1, 9, '2017-10-01', '2017-11-30', 1, 0, 1, 1506918633, 10325, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `vendor_details`
--

CREATE TABLE `vendor_details` (
  `vendor_detail_id` int(11) NOT NULL,
  `vendor_detail_vendor_id` int(11) NOT NULL,
  `vendor_detail_contact_person` varchar(80) NOT NULL,
  `vendor_detail_designation` varchar(80) NOT NULL,
  `vendor_detail_contact_no` int(11) NOT NULL,
  `vendor_detail_added_by` int(11) NOT NULL,
  `vendor_detail_added_on` int(11) NOT NULL,
  `vendor_detail_added_ip` int(11) NOT NULL,
  `vendor_detail_modified_by` int(11) NOT NULL,
  `vendor_detail_modified_on` int(11) NOT NULL,
  `vendor_detail_modified_ip` int(11) NOT NULL,
  `vendor_detail_deleted_by` int(11) NOT NULL,
  `vendor_detail_deleted_on` int(11) NOT NULL,
  `vendor_detail_deleted_ip` int(11) NOT NULL,
  `vendor_detail_deleted_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendor_details`
--

INSERT INTO `vendor_details` (`vendor_detail_id`, `vendor_detail_vendor_id`, `vendor_detail_contact_person`, `vendor_detail_designation`, `vendor_detail_contact_no`, `vendor_detail_added_by`, `vendor_detail_added_on`, `vendor_detail_added_ip`, `vendor_detail_modified_by`, `vendor_detail_modified_on`, `vendor_detail_modified_ip`, `vendor_detail_deleted_by`, `vendor_detail_deleted_on`, `vendor_detail_deleted_ip`, `vendor_detail_deleted_status`) VALUES
(1, 2, 'U Hla', 'Worker', 2147483647, 1, 1506918633, 10325, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `width_cutting`
--

CREATE TABLE `width_cutting` (
  `width_cutting_id` int(11) NOT NULL,
  `width_cutting_uniq_id` varchar(255) NOT NULL,
  `width_cutting_no` varchar(30) NOT NULL,
  `width_cutting_date` date NOT NULL,
  `width_cutting_godown_id` int(11) NOT NULL,
  `width_cutting_type` varchar(30) NOT NULL,
  `width_cutting_status` int(11) NOT NULL DEFAULT '1',
  `width_cutting_company_id` int(11) NOT NULL,
  `width_cutting_branch_id` int(11) NOT NULL,
  `width_cutting_financial_year` int(11) NOT NULL,
  `width_cutting_added_by` int(11) NOT NULL,
  `width_cutting_added_on` int(11) NOT NULL,
  `width_cutting_added_ip` varchar(20) NOT NULL,
  `width_cutting_modified_by` int(11) NOT NULL,
  `width_cutting_modified_on` int(11) NOT NULL,
  `width_cutting_modified_ip` varchar(20) NOT NULL,
  `width_cutting_deleted_by` int(11) NOT NULL,
  `width_cutting_deleted_on` int(11) NOT NULL,
  `width_cutting_deleted_ip` varchar(20) NOT NULL,
  `width_cutting_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `width_cutting`
--

INSERT INTO `width_cutting` (`width_cutting_id`, `width_cutting_uniq_id`, `width_cutting_no`, `width_cutting_date`, `width_cutting_godown_id`, `width_cutting_type`, `width_cutting_status`, `width_cutting_company_id`, `width_cutting_branch_id`, `width_cutting_financial_year`, `width_cutting_added_by`, `width_cutting_added_on`, `width_cutting_added_ip`, `width_cutting_modified_by`, `width_cutting_modified_on`, `width_cutting_modified_ip`, `width_cutting_deleted_by`, `width_cutting_deleted_on`, `width_cutting_deleted_ip`, `width_cutting_deleted_status`) VALUES
(1, '875ebb5rbb7172olru7a736d95967d75ff0f02cc', '00001', '2017-12-13', 1, '1', 1, 1, 1, 1, 1, 1513145419, '103.197.196.27', 0, 0, '', 0, 0, '', 0),
(2, 'ed5a601fwa0fd7nqpdfac2a50afdf7ea40a85a8a', '00002', '2017-12-14', 1, '1', 1, 1, 1, 1, 1, 1513238585, '103.197.196.20', 0, 0, '', 0, 0, '', 0),
(3, 'fbce484bsaf042iz03fd9ab37404fbc43487fcb7', '00003', '2017-12-16', 1, '0', 1, 1, 1, 1, 1, 1513394120, '203.81.163.238', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `width_cutting_product_details`
--

CREATE TABLE `width_cutting_product_details` (
  `width_cutting_product_detail_id` int(11) NOT NULL,
  `width_cutting_product_detail_uniq_id` varchar(255) NOT NULL,
  `width_cutting_product_detail_width_cutting_id` int(11) NOT NULL,
  `width_cutting_product_detail_product_id` int(11) NOT NULL,
  `width_cutting_product_detail_width_inches` decimal(20,4) NOT NULL,
  `width_cutting_product_detail_width_mm` decimal(20,4) NOT NULL,
  `width_cutting_product_detail_length_feet` decimal(20,4) NOT NULL,
  `width_cutting_product_detail_length_mm` decimal(20,4) NOT NULL,
  `width_cutting_product_detail_qty` decimal(20,4) NOT NULL,
  `width_cutting_product_detail_type` int(11) NOT NULL,
  `width_cutting_product_detail_company_id` int(11) NOT NULL,
  `width_cutting_product_detail_branch_id` int(11) NOT NULL,
  `width_cutting_product_detail_financial_year` varchar(20) NOT NULL,
  `width_cutting_product_detail_added_by` int(11) NOT NULL,
  `width_cutting_product_detail_added_on` int(11) NOT NULL,
  `width_cutting_product_detail_added_ip` varchar(20) NOT NULL,
  `width_cutting_product_detail_modified_by` int(11) NOT NULL,
  `width_cutting_product_detail_modified_on` int(11) NOT NULL,
  `width_cutting_product_detail_modified_ip` varchar(20) NOT NULL,
  `width_cutting_product_detail_deleted_by` int(11) NOT NULL,
  `width_cutting_product_detail_deleted_on` int(11) NOT NULL,
  `width_cutting_product_detail_deleted_ip` varchar(20) NOT NULL,
  `width_cutting_product_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `width_cutting_product_details`
--

INSERT INTO `width_cutting_product_details` (`width_cutting_product_detail_id`, `width_cutting_product_detail_uniq_id`, `width_cutting_product_detail_width_cutting_id`, `width_cutting_product_detail_product_id`, `width_cutting_product_detail_width_inches`, `width_cutting_product_detail_width_mm`, `width_cutting_product_detail_length_feet`, `width_cutting_product_detail_length_mm`, `width_cutting_product_detail_qty`, `width_cutting_product_detail_type`, `width_cutting_product_detail_company_id`, `width_cutting_product_detail_branch_id`, `width_cutting_product_detail_financial_year`, `width_cutting_product_detail_added_by`, `width_cutting_product_detail_added_on`, `width_cutting_product_detail_added_ip`, `width_cutting_product_detail_modified_by`, `width_cutting_product_detail_modified_on`, `width_cutting_product_detail_modified_ip`, `width_cutting_product_detail_deleted_by`, `width_cutting_product_detail_deleted_on`, `width_cutting_product_detail_deleted_ip`, `width_cutting_product_detail_deleted_status`) VALUES
(1, '4dc711acrl7b86ac5l525c9938f4a635c823b41a', 1, 3, '36.0000', '914.4000', '200.0000', '60960.0000', '200.0000', 0, 0, 0, '', 1, 1513145419, '103.197.196.27', 0, 0, '', 0, 0, '', 0),
(2, 'f5593bfdgt2b4852cxb7e32312eb389088684bdd', 2, 48, '36.0000', '914.4000', '500.0000', '152400.0000', '500.0000', 0, 0, 0, '', 1, 1513238586, '103.197.196.20', 0, 0, '', 0, 0, '', 0),
(3, '5ccf033dwra8f3zbr7d6437ce9b11c22924f535a', 3, 61, '36.0000', '914.4000', '50.0000', '15240.0000', '0.0000', 0, 0, 0, '', 1, 1513394120, '203.81.163.238', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `width_cutting_width_details`
--

CREATE TABLE `width_cutting_width_details` (
  `width_cutting_width_detail_id` int(11) NOT NULL,
  `width_cutting_width_detail_uniq_id` varchar(255) NOT NULL,
  `width_cutting_width_detail_width_cutting_id` int(11) NOT NULL,
  `width_cutting_width_detail_name` varchar(255) NOT NULL,
  `width_cutting_width_detail_product_id` int(11) NOT NULL,
  `width_cutting_width_detail_width_inches_one` decimal(20,4) NOT NULL,
  `width_cutting_width_detail_width_inches_two` decimal(20,4) NOT NULL,
  `width_cutting_width_detail_width_inches_three` decimal(20,4) NOT NULL,
  `width_cutting_width_detail_width_inches_four` decimal(20,4) NOT NULL,
  `width_cutting_width_detail_inches_qty` decimal(20,4) NOT NULL,
  `width_cutting_width_detail_length` decimal(20,4) NOT NULL,
  `width_cutting_width_detail_length_qty` decimal(12,3) NOT NULL,
  `width_cutting_width_detail_type` int(11) NOT NULL,
  `width_cutting_width_detail_company_id` int(11) NOT NULL,
  `width_cutting_width_detail_branch_id` int(11) NOT NULL,
  `width_cutting_width_detail_financial_year` varchar(20) NOT NULL,
  `width_cutting_width_detail_added_by` int(11) NOT NULL,
  `width_cutting_width_detail_added_on` int(11) NOT NULL,
  `width_cutting_width_detail_added_ip` varchar(20) NOT NULL,
  `width_cutting_width_detail_modified_by` int(11) NOT NULL,
  `width_cutting_width_detail_modified_on` int(11) NOT NULL,
  `width_cutting_width_detail_modified_ip` varchar(20) NOT NULL,
  `width_cutting_width_detail_deleted_by` int(11) NOT NULL,
  `width_cutting_width_detail_deleted_on` int(11) NOT NULL,
  `width_cutting_width_detail_deleted_ip` varchar(20) NOT NULL,
  `width_cutting_width_detail_deleted_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `width_cutting_width_details`
--

INSERT INTO `width_cutting_width_details` (`width_cutting_width_detail_id`, `width_cutting_width_detail_uniq_id`, `width_cutting_width_detail_width_cutting_id`, `width_cutting_width_detail_name`, `width_cutting_width_detail_product_id`, `width_cutting_width_detail_width_inches_one`, `width_cutting_width_detail_width_inches_two`, `width_cutting_width_detail_width_inches_three`, `width_cutting_width_detail_width_inches_four`, `width_cutting_width_detail_inches_qty`, `width_cutting_width_detail_length`, `width_cutting_width_detail_length_qty`, `width_cutting_width_detail_type`, `width_cutting_width_detail_company_id`, `width_cutting_width_detail_branch_id`, `width_cutting_width_detail_financial_year`, `width_cutting_width_detail_added_by`, `width_cutting_width_detail_added_on`, `width_cutting_width_detail_added_ip`, `width_cutting_width_detail_modified_by`, `width_cutting_width_detail_modified_on`, `width_cutting_width_detail_modified_ip`, `width_cutting_width_detail_deleted_by`, `width_cutting_width_detail_deleted_on`, `width_cutting_width_detail_deleted_ip`, `width_cutting_width_detail_deleted_status`) VALUES
(1, '0eb5fa7s1eff672rb88b656b910b3a1d85b5a407', 1, 'WIDTH1', 3, '9.0000', '9.0000', '9.0000', '9.0000', '4.0000', '10.0000', '10.000', 0, 0, 0, '', 1, 1513145419, '103.197.196.27', 0, 0, '', 0, 0, '', 0),
(2, 'a4e24a6emp649csmpdg96a08716c2e6429a74374', 2, 'WIDTH1', 48, '9.0000', '27.0000', '0.0000', '0.0000', '2.0000', '100.0000', '2.000', 0, 0, 0, '', 1, 1513238586, '103.197.196.20', 0, 0, '', 0, 0, '', 0),
(3, 'f94dd67r5g5c5ale5sl3bfbc4fdec3c7fde2f388', 3, 'WIDTH1', 61, '9.0000', '9.0000', '9.0000', '9.0000', '4.0000', '10.0000', '1.000', 0, 0, 0, '', 1, 1513394120, '203.81.163.238', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `write_off`
--

CREATE TABLE `write_off` (
  `writeoffId` int(11) NOT NULL,
  `wr_dmgMsgScrpId` int(11) NOT NULL,
  `wr_branchid` int(11) NOT NULL,
  `wr_warehouseid` int(11) NOT NULL,
  `wr_date` date NOT NULL,
  `wr_type` int(11) NOT NULL,
  `wr_company_id` int(11) NOT NULL,
  `wr_added_by` int(11) NOT NULL,
  `wr_added_on` datetime NOT NULL,
  `wr_added_ip` varchar(20) NOT NULL,
  `wr_modified_by` int(11) NOT NULL,
  `wr_modified_on` datetime NOT NULL,
  `wr_modified_ip` varchar(20) NOT NULL,
  `wr_deleted_by` int(11) NOT NULL,
  `wr_deleted_on` datetime NOT NULL,
  `wr_deleted_ip` varchar(20) NOT NULL,
  `wr_deleted_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `write_off`
--

INSERT INTO `write_off` (`writeoffId`, `wr_dmgMsgScrpId`, `wr_branchid`, `wr_warehouseid`, `wr_date`, `wr_type`, `wr_company_id`, `wr_added_by`, `wr_added_on`, `wr_added_ip`, `wr_modified_by`, `wr_modified_on`, `wr_modified_ip`, `wr_deleted_by`, `wr_deleted_on`, `wr_deleted_ip`, `wr_deleted_status`) VALUES
(1, 1, 2, 1, '2017-12-15', 2, 1, 1, '2017-12-15 15:58:16', '203.81.163.246', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(2, 2, 1, 2, '2017-12-16', 2, 1, 1, '2017-12-16 07:49:00', '103.242.98.230', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0),
(3, 3, 1, 1, '2017-12-16', 2, 1, 1, '2017-12-16 12:09:52', '203.81.163.238', 0, '0000-00-00 00:00:00', '', 0, '0000-00-00 00:00:00', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `write_off_product_detail`
--

CREATE TABLE `write_off_product_detail` (
  `writeoffProductId` int(11) NOT NULL,
  `wrP_writeoffId` int(11) NOT NULL,
  `wrP_dmsProductId` int(11) NOT NULL,
  `wrP_product_id` int(11) NOT NULL,
  `wrP_addqty` int(11) NOT NULL,
  `wrP_lessqty` int(11) NOT NULL,
  `wrP_remarks` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `write_off_product_detail`
--

INSERT INTO `write_off_product_detail` (`writeoffProductId`, `wrP_writeoffId`, `wrP_dmsProductId`, `wrP_product_id`, `wrP_addqty`, `wrP_lessqty`, `wrP_remarks`) VALUES
(1, 1, 1, 6, 1, 2, ''),
(2, 2, 2, 5, 1020, 1020, ''),
(3, 3, 4, 22, 10, 20, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account_expense_payable`
--
ALTER TABLE `account_expense_payable`
  ADD PRIMARY KEY (`expensePayId`);

--
-- Indexes for table `account_heads`
--
ALTER TABLE `account_heads`
  ADD PRIMARY KEY (`account_head_id`);

--
-- Indexes for table `account_journal`
--
ALTER TABLE `account_journal`
  ADD PRIMARY KEY (`acJournalId`);

--
-- Indexes for table `account_manufacturing_costmaster`
--
ALTER TABLE `account_manufacturing_costmaster`
  ADD PRIMARY KEY (`acManuCostId`);

--
-- Indexes for table `account_manufacturing_costmaster_acs`
--
ALTER TABLE `account_manufacturing_costmaster_acs`
  ADD PRIMARY KEY (`idMcAcdetailsId`);

--
-- Indexes for table `account_manu_cost_entry`
--
ALTER TABLE `account_manu_cost_entry`
  ADD PRIMARY KEY (`manuCostEntryeId`);

--
-- Indexes for table `account_opening_balance`
--
ALTER TABLE `account_opening_balance`
  ADD PRIMARY KEY (`openingBalanceId`);

--
-- Indexes for table `account_payable`
--
ALTER TABLE `account_payable`
  ADD PRIMARY KEY (`acpayableId`);

--
-- Indexes for table `account_receivable`
--
ALTER TABLE `account_receivable`
  ADD PRIMARY KEY (`acReceivableId`);

--
-- Indexes for table `account_setup`
--
ALTER TABLE `account_setup`
  ADD PRIMARY KEY (`acountSetupId`);

--
-- Indexes for table `account_sub`
--
ALTER TABLE `account_sub`
  ADD PRIMARY KEY (`account_sub_id`),
  ADD KEY `account_sub_master_id` (`account_sub_master_id`);

--
-- Indexes for table `account_types`
--
ALTER TABLE `account_types`
  ADD PRIMARY KEY (`account_type_id`);

--
-- Indexes for table `advance_entry`
--
ALTER TABLE `advance_entry`
  ADD PRIMARY KEY (`advance_entry_id`),
  ADD UNIQUE KEY `advance_entry_uniq_id` (`advance_entry_uniq_id`),
  ADD KEY `advance_entry_company_id` (`advance_entry_company_id`),
  ADD KEY `advance_entry_branch_id` (`advance_entry_branch_id`),
  ADD KEY `advance_entry_financial_year` (`advance_entry_financial_year`),
  ADD KEY `advance_entry_deleted_status` (`advance_entry_deleted_status`),
  ADD KEY `advance_entry_customer_id` (`advance_entry_customer_id`);

--
-- Indexes for table `advance_entry_product_details`
--
ALTER TABLE `advance_entry_product_details`
  ADD PRIMARY KEY (`advance_entry_product_detail_id`),
  ADD UNIQUE KEY `advance_entry_product_detail_uniq_id` (`advance_entry_product_detail_uniq_id`),
  ADD KEY `advance_entry_product_detail_advance_entry_id` (`advance_entry_product_detail_advance_entry_id`),
  ADD KEY `advance_entry_product_detail_product_id` (`advance_entry_product_detail_product_id`),
  ADD KEY `advance_entry_product_detail_deleted_status` (`advance_entry_product_detail_deleted_status`);

--
-- Indexes for table `banks`
--
ALTER TABLE `banks`
  ADD PRIMARY KEY (`bank_id`);

--
-- Indexes for table `bank_multi_contacts`
--
ALTER TABLE `bank_multi_contacts`
  ADD PRIMARY KEY (`bank_multi_contact_id`);

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`branch_id`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`city_id`),
  ADD KEY `city_company_id` (`city_company_id`);

--
-- Indexes for table `collection_entry`
--
ALTER TABLE `collection_entry`
  ADD PRIMARY KEY (`collection_entry_id`),
  ADD UNIQUE KEY `collection_entry_uniq_id` (`collection_entry_uniq_id`),
  ADD KEY `collection_entry_company_id` (`collection_entry_company_id`),
  ADD KEY `collection_entry_branch_id` (`collection_entry_branch_id`),
  ADD KEY `collection_entry_financial_year` (`collection_entry_financial_year`),
  ADD KEY `collection_entry_deleted_status` (`collection_entry_deleted_status`);

--
-- Indexes for table `collection_entry_details`
--
ALTER TABLE `collection_entry_details`
  ADD PRIMARY KEY (`collection_entry_detail_id`),
  ADD UNIQUE KEY `collection_entry_detail_id` (`collection_entry_detail_id`);

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`company_id`);

--
-- Indexes for table `costing_entry`
--
ALTER TABLE `costing_entry`
  ADD PRIMARY KEY (`costingId`);

--
-- Indexes for table `costing_entry_details`
--
ALTER TABLE `costing_entry_details`
  ADD PRIMARY KEY (`costId`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`country_id`);

--
-- Indexes for table `credit_note_entry`
--
ALTER TABLE `credit_note_entry`
  ADD PRIMARY KEY (`credit_note_entry_id`),
  ADD UNIQUE KEY `credit_note_entry_uniq_id` (`credit_note_entry_uniq_id`),
  ADD KEY `credit_note_entry_company_id` (`credit_note_entry_company_id`),
  ADD KEY `credit_note_entry_branch_id` (`credit_note_entry_branch_id`),
  ADD KEY `credit_note_entry_financial_year` (`credit_note_entry_financial_year`),
  ADD KEY `credit_note_entry_deleted_status` (`credit_note_entry_deleted_status`),
  ADD KEY `credit_note_entry_customer_id` (`credit_note_entry_customer_id`);

--
-- Indexes for table `credit_note_entry_product_details`
--
ALTER TABLE `credit_note_entry_product_details`
  ADD PRIMARY KEY (`credit_note_entry_product_detail_id`),
  ADD UNIQUE KEY `credit_note_entry_product_detail_uniq_id` (`credit_note_entry_product_detail_uniq_id`),
  ADD KEY `credit_note_entry_product_detail_credit_note_entry_id` (`credit_note_entry_product_detail_credit_note_entry_id`),
  ADD KEY `credit_note_entry_product_detail_product_id` (`credit_note_entry_product_detail_product_id`),
  ADD KEY `credit_note_entry_product_detail_invoice_entry_id` (`credit_note_entry_product_detail_invoice_entry_id`),
  ADD KEY `credit_note_entry_product_detail_quotation_detail_id` (`credit_note_entry_product_detail_invoice_detail_id`),
  ADD KEY `credit_note_entry_product_detail_deleted_status` (`credit_note_entry_product_detail_deleted_status`);

--
-- Indexes for table `currencies`
--
ALTER TABLE `currencies`
  ADD PRIMARY KEY (`currency_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `customer_multi_contacts`
--
ALTER TABLE `customer_multi_contacts`
  ADD PRIMARY KEY (`customer_multi_contact_id`);

--
-- Indexes for table `customer_types`
--
ALTER TABLE `customer_types`
  ADD PRIMARY KEY (`customer_type_id`);

--
-- Indexes for table `damg_missing_scrp_details`
--
ALTER TABLE `damg_missing_scrp_details`
  ADD PRIMARY KEY (`dmgMsgScrpId`);

--
-- Indexes for table `damg_missing_scrp_details_products`
--
ALTER TABLE `damg_missing_scrp_details_products`
  ADD PRIMARY KEY (`dmsProductId`);

--
-- Indexes for table `delivery_entry`
--
ALTER TABLE `delivery_entry`
  ADD PRIMARY KEY (`delivery_entry_id`),
  ADD UNIQUE KEY `delivery_entry_uniq_id` (`delivery_entry_uniq_id`),
  ADD KEY `delivery_entry_company_id` (`delivery_entry_company_id`),
  ADD KEY `delivery_entry_branch_id` (`delivery_entry_branch_id`),
  ADD KEY `delivery_entry_financial_year` (`delivery_entry_financial_year`),
  ADD KEY `delivery_entry_deleted_status` (`delivery_entry_deleted_status`),
  ADD KEY `delivery_entry_customer_id` (`delivery_entry_customer_id`);

--
-- Indexes for table `delivery_entry_product_details`
--
ALTER TABLE `delivery_entry_product_details`
  ADD PRIMARY KEY (`delivery_entry_product_detail_id`),
  ADD UNIQUE KEY `delivery_entry_product_detail_uniq_id` (`delivery_entry_product_detail_uniq_id`),
  ADD KEY `delivery_entry_product_detail_delivery_entry_id` (`delivery_entry_product_detail_delivery_entry_id`),
  ADD KEY `delivery_entry_product_detail_product_id` (`delivery_entry_product_detail_product_id`),
  ADD KEY `delivery_entry_product_detail_deleted_status` (`delivery_entry_product_detail_deleted_status`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `do_god_entry`
--
ALTER TABLE `do_god_entry`
  ADD PRIMARY KEY (`do_god_entry_id`),
  ADD UNIQUE KEY `do_god_entry_uniq_id` (`do_god_entry_uniq_id`),
  ADD KEY `do_god_entry_company_id` (`do_god_entry_company_id`),
  ADD KEY `do_god_entry_branch_id` (`do_god_entry_branch_id`),
  ADD KEY `do_god_entry_financial_year` (`do_god_entry_financial_year`),
  ADD KEY `do_god_entry_deleted_status` (`do_god_entry_deleted_status`),
  ADD KEY `do_god_entry_customer_id` (`do_god_entry_customer_id`);

--
-- Indexes for table `do_god_entry_product_details`
--
ALTER TABLE `do_god_entry_product_details`
  ADD PRIMARY KEY (`do_god_entry_product_detail_id`),
  ADD UNIQUE KEY `do_god_entry_product_detail_uniq_id` (`do_god_entry_product_detail_uniq_id`),
  ADD KEY `do_god_entry_product_detail_do_god_entry_id` (`do_god_entry_product_detail_do_god_entry_id`),
  ADD KEY `do_god_entry_product_detail_product_id` (`do_god_entry_product_detail_product_id`),
  ADD KEY `do_god_entry_product_detail_production_order_id` (`do_god_entry_product_detail_production_order_id`),
  ADD KEY `do_god_entry_product_detail_quotation_detail_id` (`do_god_entry_product_detail_production_detail_id`),
  ADD KEY `do_god_entry_product_detail_deleted_status` (`do_god_entry_product_detail_deleted_status`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`employee_id`);

--
-- Indexes for table `emp_advance`
--
ALTER TABLE `emp_advance`
  ADD PRIMARY KEY (`empAdvanceId`);

--
-- Indexes for table `emp_attendance`
--
ALTER TABLE `emp_attendance`
  ADD PRIMARY KEY (`empAtncId`);

--
-- Indexes for table `emp_leave`
--
ALTER TABLE `emp_leave`
  ADD PRIMARY KEY (`empLeaveId`);

--
-- Indexes for table `emp_overtime`
--
ALTER TABLE `emp_overtime`
  ADD PRIMARY KEY (`empOtId`);

--
-- Indexes for table `expense_payable`
--
ALTER TABLE `expense_payable`
  ADD PRIMARY KEY (`expensePayId`);

--
-- Indexes for table `financial_years`
--
ALTER TABLE `financial_years`
  ADD PRIMARY KEY (`financial_year_id`);

--
-- Indexes for table `gate_pass`
--
ALTER TABLE `gate_pass`
  ADD PRIMARY KEY (`gatePassId`);

--
-- Indexes for table `gate_pass_product_details`
--
ALTER TABLE `gate_pass_product_details`
  ADD PRIMARY KEY (`gpProductdetailsId`);

--
-- Indexes for table `gin_entry`
--
ALTER TABLE `gin_entry`
  ADD PRIMARY KEY (`gin_entry_id`),
  ADD UNIQUE KEY `gin_entry_uniq_id` (`gin_entry_uniq_id`),
  ADD KEY `gin_entry_company_id` (`gin_entry_company_id`),
  ADD KEY `gin_entry_branch_id` (`gin_entry_branch_id`),
  ADD KEY `gin_entry_financial_year` (`gin_entry_financial_year`),
  ADD KEY `gin_entry_deleted_status` (`gin_entry_deleted_status`),
  ADD KEY `gin_entry_production_section_id` (`gin_entry_production_section_id`);

--
-- Indexes for table `gin_entry_product_details`
--
ALTER TABLE `gin_entry_product_details`
  ADD PRIMARY KEY (`gin_entry_product_detail_id`),
  ADD UNIQUE KEY `gin_entry_product_detail_uniq_id` (`gin_entry_product_detail_uniq_id`),
  ADD KEY `gin_entry_product_detail_gin_entry_id` (`gin_entry_product_detail_gin_entry_id`),
  ADD KEY `gin_entry_product_detail_product_id` (`gin_entry_product_detail_product_id`),
  ADD KEY `gin_entry_product_detail_deleted_status` (`gin_entry_product_detail_deleted_status`),
  ADD KEY `gin_entry_product_detail_invoice_entry_id` (`gin_entry_product_detail_production_order_id`),
  ADD KEY `gin_entry_product_detail_invoice_detail_id` (`gin_entry_product_detail_production_order_detail_id`);

--
-- Indexes for table `gin_entry_raw_product_details`
--
ALTER TABLE `gin_entry_raw_product_details`
  ADD PRIMARY KEY (`gin_entry_raw_product_detail_id`),
  ADD UNIQUE KEY `gin_entry_raw_product_detail_uniq_id` (`gin_entry_raw_product_detail_uniq_id`),
  ADD KEY `gin_entry_raw_product_detail_gin_entry_id` (`gin_entry_raw_product_detail_gin_entry_id`),
  ADD KEY `gin_entry_raw_product_detail_product_id` (`gin_entry_raw_product_detail_product_id`),
  ADD KEY `gin_entry_raw_product_detail_deleted_status` (`gin_entry_raw_product_detail_deleted_status`),
  ADD KEY `gin_entry_raw_product_detail_raw_product_id` (`gin_entry_raw_product_detail_raw_product_id`);

--
-- Indexes for table `godowns`
--
ALTER TABLE `godowns`
  ADD PRIMARY KEY (`godown_id`);

--
-- Indexes for table `godown_multi_contacts`
--
ALTER TABLE `godown_multi_contacts`
  ADD PRIMARY KEY (`godown_multi_contact_id`);

--
-- Indexes for table `grn_child_product_details`
--
ALTER TABLE `grn_child_product_details`
  ADD PRIMARY KEY (`grn_child_product_detail_id`),
  ADD UNIQUE KEY `grn_child_product_detail_uniq_id` (`grn_child_product_detail_uniq_id`),
  ADD KEY `grn_child_product_detail_grn_id` (`grn_child_product_detail_grn_id`),
  ADD KEY `grn_child_product_detail_inv_child_detail_id` (`grn_child_product_detail_inv_detail_id`),
  ADD KEY `grn_child_product_detail_product_id` (`grn_child_product_detail_product_id`),
  ADD KEY `grn_child_product_detail_deleted_status` (`grn_child_product_detail_deleted_status`);

--
-- Indexes for table `grn_details`
--
ALTER TABLE `grn_details`
  ADD PRIMARY KEY (`grnId`);

--
-- Indexes for table `grn_details_products`
--
ALTER TABLE `grn_details_products`
  ADD PRIMARY KEY (`grnProdId`);

--
-- Indexes for table `grn_entry`
--
ALTER TABLE `grn_entry`
  ADD PRIMARY KEY (`grn_entry_id`),
  ADD UNIQUE KEY `grn_entry_uniq_id` (`grn_entry_uniq_id`),
  ADD KEY `grn_entry_company_id` (`grn_entry_company_id`),
  ADD KEY `grn_entry_branch_id` (`grn_entry_branch_id`),
  ADD KEY `grn_entry_financial_year` (`grn_entry_financial_year`),
  ADD KEY `grn_entry_deleted_status` (`grn_entry_deleted_status`),
  ADD KEY `grn_entry_production_section_id` (`grn_entry_production_section_id`);

--
-- Indexes for table `grn_entry_product_details`
--
ALTER TABLE `grn_entry_product_details`
  ADD PRIMARY KEY (`grn_entry_product_detail_id`),
  ADD UNIQUE KEY `grn_entry_product_detail_uniq_id` (`grn_entry_product_detail_uniq_id`),
  ADD KEY `grn_entry_product_detail_grn_entry_id` (`grn_entry_product_detail_grn_entry_id`),
  ADD KEY `grn_entry_product_detail_product_id` (`grn_entry_product_detail_product_id`),
  ADD KEY `grn_entry_product_detail_deleted_status` (`grn_entry_product_detail_deleted_status`),
  ADD KEY `grn_entry_product_detail_invoice_entry_id` (`grn_entry_product_detail_gin_entry_id`),
  ADD KEY `grn_entry_product_detail_invoice_detail_id` (`grn_entry_product_detail_gin_entry_detail_id`);

--
-- Indexes for table `grn_entry_raw_product_details`
--
ALTER TABLE `grn_entry_raw_product_details`
  ADD PRIMARY KEY (`grn_entry_raw_product_detail_id`),
  ADD UNIQUE KEY `grn_entry_raw_product_detail_uniq_id` (`grn_entry_raw_product_detail_uniq_id`),
  ADD KEY `grn_entry_raw_product_detail_grn_entry_id` (`grn_entry_raw_product_detail_grn_entry_id`),
  ADD KEY `grn_entry_raw_product_detail_product_id` (`grn_entry_raw_product_detail_product_id`),
  ADD KEY `grn_entry_raw_product_detail_deleted_status` (`grn_entry_raw_product_detail_deleted_status`),
  ADD KEY `grn_entry_raw_product_detail_raw_product_id` (`grn_entry_raw_product_detail_raw_product_id`);

--
-- Indexes for table `invoice_entry`
--
ALTER TABLE `invoice_entry`
  ADD PRIMARY KEY (`invoice_entry_id`),
  ADD UNIQUE KEY `invoice_entry_uniq_id` (`invoice_entry_uniq_id`),
  ADD KEY `invoice_entry_company_id` (`invoice_entry_company_id`),
  ADD KEY `invoice_entry_branch_id` (`invoice_entry_branch_id`),
  ADD KEY `invoice_entry_financial_year` (`invoice_entry_financial_year`),
  ADD KEY `invoice_entry_deleted_status` (`invoice_entry_deleted_status`),
  ADD KEY `invoice_entry_customer_id` (`invoice_entry_customer_id`);

--
-- Indexes for table `invoice_entry_product_details`
--
ALTER TABLE `invoice_entry_product_details`
  ADD PRIMARY KEY (`invoice_entry_product_detail_id`),
  ADD UNIQUE KEY `invoice_entry_product_detail_uniq_id` (`invoice_entry_product_detail_uniq_id`),
  ADD KEY `invoice_entry_product_detail_invoice_entry_id` (`invoice_entry_product_detail_invoice_entry_id`),
  ADD KEY `invoice_entry_product_detail_product_id` (`invoice_entry_product_detail_product_id`),
  ADD KEY `invoice_entry_product_detail_deleted_status` (`invoice_entry_product_detail_deleted_status`);

--
-- Indexes for table `opening_stock`
--
ALTER TABLE `opening_stock`
  ADD PRIMARY KEY (`opening_stock_id`),
  ADD UNIQUE KEY `opening_stock_uniq_id` (`opening_stock_uniq_id`),
  ADD KEY `opening_stock_company_id` (`opening_stock_company_id`),
  ADD KEY `opening_stock_branch_id` (`opening_stock_branch_id`),
  ADD KEY `opening_stock_financial_year` (`opening_stock_financial_year`),
  ADD KEY `opening_stock_deleted_status` (`opening_stock_deleted_status`);

--
-- Indexes for table `opening_stock_product_details`
--
ALTER TABLE `opening_stock_product_details`
  ADD PRIMARY KEY (`opening_stock_product_detail_id`),
  ADD UNIQUE KEY `opening_stock_product_detail_id` (`opening_stock_product_detail_id`);

--
-- Indexes for table `payroll`
--
ALTER TABLE `payroll`
  ADD PRIMARY KEY (`payroll_id`);

--
-- Indexes for table `pdo_entry`
--
ALTER TABLE `pdo_entry`
  ADD PRIMARY KEY (`pdo_entry_id`),
  ADD UNIQUE KEY `pdo_entry_uniq_id` (`pdo_entry_uniq_id`),
  ADD KEY `pdo_entry_company_id` (`pdo_entry_company_id`),
  ADD KEY `pdo_entry_branch_id` (`pdo_entry_branch_id`),
  ADD KEY `pdo_entry_financial_year` (`pdo_entry_financial_year`),
  ADD KEY `pdo_entry_deleted_status` (`pdo_entry_deleted_status`);

--
-- Indexes for table `pdo_entry_product_details`
--
ALTER TABLE `pdo_entry_product_details`
  ADD PRIMARY KEY (`pdo_entry_product_detail_id`),
  ADD UNIQUE KEY `pdo_entry_product_detail_uniq_id` (`pdo_entry_product_detail_uniq_id`),
  ADD KEY `pdo_entry_product_detail_pdo_entry_id` (`pdo_entry_product_detail_pdo_entry_id`),
  ADD KEY `pdo_entry_product_detail_product_id` (`pdo_entry_product_detail_product_id`),
  ADD KEY `pdo_entry_product_detail_deleted_status` (`pdo_entry_product_detail_deleted_status`),
  ADD KEY `pdo_entry_product_detail_invoice_entry_id` (`pdo_entry_product_detail_production_entry_id`),
  ADD KEY `pdo_entry_product_detail_invoice_detail_id` (`pdo_entry_product_detail_production_entry_detail_id`);

--
-- Indexes for table `prn_entry`
--
ALTER TABLE `prn_entry`
  ADD PRIMARY KEY (`prn_entry_id`),
  ADD UNIQUE KEY `prn_entry_uniq_id` (`prn_entry_uniq_id`),
  ADD KEY `prn_entry_company_id` (`prn_entry_company_id`),
  ADD KEY `prn_entry_branch_id` (`prn_entry_branch_id`),
  ADD KEY `prn_entry_financial_year` (`prn_entry_financial_year`),
  ADD KEY `prn_entry_deleted_status` (`prn_entry_deleted_status`);

--
-- Indexes for table `prn_entry_product_details`
--
ALTER TABLE `prn_entry_product_details`
  ADD PRIMARY KEY (`prn_entry_product_detail_id`),
  ADD UNIQUE KEY `prn_entry_product_detail_uniq_id` (`prn_entry_product_detail_uniq_id`),
  ADD KEY `prn_entry_product_detail_prn_entry_id` (`prn_entry_product_detail_prn_entry_id`),
  ADD KEY `prn_entry_product_detail_product_id` (`prn_entry_product_detail_product_id`),
  ADD KEY `prn_entry_product_detail_deleted_status` (`prn_entry_product_detail_deleted_status`),
  ADD KEY `prn_entry_product_detail_invoice_entry_id` (`prn_entry_product_detail_production_entry_id`),
  ADD KEY `prn_entry_product_detail_invoice_detail_id` (`prn_entry_product_detail_production_entry_detail_id`);

--
-- Indexes for table `production_entry`
--
ALTER TABLE `production_entry`
  ADD PRIMARY KEY (`production_entry_id`),
  ADD UNIQUE KEY `production_entry_uniq_id` (`production_entry_uniq_id`),
  ADD KEY `production_entry_company_id` (`production_entry_company_id`),
  ADD KEY `production_entry_branch_id` (`production_entry_branch_id`),
  ADD KEY `production_entry_financial_year` (`production_entry_financial_year`),
  ADD KEY `production_entry_deleted_status` (`production_entry_deleted_status`),
  ADD KEY `production_entry_godown_id` (`production_entry_godown_id`);

--
-- Indexes for table `production_entry_dam_product_details`
--
ALTER TABLE `production_entry_dam_product_details`
  ADD PRIMARY KEY (`production_entry_dam_product_detail_id`),
  ADD UNIQUE KEY `production_entry_dam_product_detail_uniq_id` (`production_entry_dam_product_detail_uniq_id`),
  ADD KEY `production_entry_dam_product_detail_production_entry_id` (`production_entry_dam_product_detail_production_entry_id`),
  ADD KEY `production_entry_dam_product_detail_product_id` (`production_entry_dam_product_detail_product_id`),
  ADD KEY `production_entry_dam_product_detail_deleted_status` (`production_entry_dam_product_detail_deleted_status`),
  ADD KEY `production_entry_dam_product_detail_raw_product_id` (`production_entry_dam_product_detail_raw_product_id`);

--
-- Indexes for table `production_entry_product_details`
--
ALTER TABLE `production_entry_product_details`
  ADD PRIMARY KEY (`production_entry_product_detail_id`),
  ADD UNIQUE KEY `production_entry_product_detail_uniq_id` (`production_entry_product_detail_uniq_id`),
  ADD KEY `production_entry_product_detail_production_entry_id` (`production_entry_product_detail_production_entry_id`),
  ADD KEY `production_entry_product_detail_product_id` (`production_entry_product_detail_product_id`),
  ADD KEY `production_entry_product_detail_deleted_status` (`production_entry_product_detail_deleted_status`),
  ADD KEY `production_entry_product_detail_grn_entry_id` (`production_entry_product_detail_grn_entry_id`),
  ADD KEY `production_entry_product_detail_grn_entry_detail_id` (`production_entry_product_detail_grn_entry_detail_id`);

--
-- Indexes for table `production_entry_raw_product_details`
--
ALTER TABLE `production_entry_raw_product_details`
  ADD PRIMARY KEY (`production_entry_raw_product_detail_id`),
  ADD UNIQUE KEY `production_entry_raw_product_detail_uniq_id` (`production_entry_raw_product_detail_uniq_id`),
  ADD KEY `production_entry_raw_product_detail_production_entry_id` (`production_entry_raw_product_detail_production_entry_id`),
  ADD KEY `production_entry_raw_product_detail_product_id` (`production_entry_raw_product_detail_product_id`),
  ADD KEY `production_entry_raw_product_detail_deleted_status` (`production_entry_raw_product_detail_deleted_status`),
  ADD KEY `production_entry_raw_product_detail_raw_product_id` (`production_entry_raw_product_detail_raw_product_id`);

--
-- Indexes for table `production_entry_work_details`
--
ALTER TABLE `production_entry_work_details`
  ADD PRIMARY KEY (`production_entry_work_detail_id`),
  ADD UNIQUE KEY `production_entry_work_detail_uniq_id` (`production_entry_work_detail_uniq_id`),
  ADD KEY `production_entry_work_detail_production_entry_id` (`production_entry_work_detail_production_entry_id`),
  ADD KEY `production_entry_work_detail_production_section_id` (`production_entry_work_detail_production_section_id`),
  ADD KEY `production_entry_work_detail_deleted_status` (`production_entry_work_detail_deleted_status`),
  ADD KEY `production_entry_work_detail_production_machine_id` (`production_entry_work_detail_production_machine_id`);

--
-- Indexes for table `production_machines`
--
ALTER TABLE `production_machines`
  ADD UNIQUE KEY `production_machine_id` (`production_machine_id`);

--
-- Indexes for table `production_order`
--
ALTER TABLE `production_order`
  ADD PRIMARY KEY (`production_order_id`),
  ADD UNIQUE KEY `production_order_uniq_id` (`production_order_uniq_id`),
  ADD KEY `production_order_company_id` (`production_order_company_id`),
  ADD KEY `production_order_branch_id` (`production_order_branch_id`),
  ADD KEY `production_order_financial_year` (`production_order_financial_year`),
  ADD KEY `production_order_deleted_status` (`production_order_deleted_status`),
  ADD KEY `production_order_production_section_id` (`production_order_production_section_id`);

--
-- Indexes for table `production_order_product_details`
--
ALTER TABLE `production_order_product_details`
  ADD PRIMARY KEY (`production_order_product_detail_id`),
  ADD UNIQUE KEY `production_order_product_detail_uniq_id` (`production_order_product_detail_uniq_id`),
  ADD KEY `production_order_product_detail_production_order_id` (`production_order_product_detail_production_order_id`),
  ADD KEY `production_order_product_detail_product_id` (`production_order_product_detail_product_id`),
  ADD KEY `production_order_product_detail_deleted_status` (`production_order_product_detail_deleted_status`);

--
-- Indexes for table `production_sections`
--
ALTER TABLE `production_sections`
  ADD UNIQUE KEY `production_section_id` (`production_section_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `product_calculations`
--
ALTER TABLE `product_calculations`
  ADD PRIMARY KEY (`product_calculation_id`);

--
-- Indexes for table `product_categories`
--
ALTER TABLE `product_categories`
  ADD PRIMARY KEY (`product_category_id`);

--
-- Indexes for table `product_colours`
--
ALTER TABLE `product_colours`
  ADD PRIMARY KEY (`product_colour_id`);

--
-- Indexes for table `product_con_entry`
--
ALTER TABLE `product_con_entry`
  ADD PRIMARY KEY (`product_con_entry_id`),
  ADD UNIQUE KEY `product_con_entry_uniq_id` (`product_con_entry_uniq_id`),
  ADD KEY `product_con_entry_company_id` (`product_con_entry_company_id`),
  ADD KEY `product_con_entry_branch_id` (`product_con_entry_branch_id`),
  ADD KEY `product_con_entry_financial_year` (`product_con_entry_financial_year`),
  ADD KEY `product_con_entry_deleted_status` (`product_con_entry_deleted_status`),
  ADD KEY `product_con_entry_godown_id` (`product_con_entry_godown_id`);

--
-- Indexes for table `product_con_entry_child_product_details`
--
ALTER TABLE `product_con_entry_child_product_details`
  ADD PRIMARY KEY (`product_con_entry_child_product_detail_id`),
  ADD UNIQUE KEY `product_con_entry_child_product_detail_uniq_id` (`product_con_entry_child_product_detail_uniq_id`),
  ADD KEY `product_con_entry_child_product_detail_product_con_entry_id` (`product_con_entry_child_product_detail_product_con_entry_id`),
  ADD KEY `product_con_entry_child_product_detail_product_id` (`product_con_entry_child_product_detail_product_id`),
  ADD KEY `product_con_entry_child_product_detail_invoice_entry_id` (`product_con_entry_child_product_detail_invoice_entry_id`),
  ADD KEY `product_con_entry_child_product_detail_invoice_detail_id` (`product_con_entry_child_product_detail_invoice_detail_id`),
  ADD KEY `product_con_entry_child_product_detail_deleted_status` (`product_con_entry_child_product_detail_deleted_status`);

--
-- Indexes for table `product_con_entry_product_details`
--
ALTER TABLE `product_con_entry_product_details`
  ADD PRIMARY KEY (`product_con_entry_product_detail_id`),
  ADD UNIQUE KEY `product_con_entry_product_detail_uniq_id` (`product_con_entry_product_detail_uniq_id`),
  ADD KEY `product_con_entry_product_detail_product_con_entry_id` (`product_con_entry_product_detail_product_con_entry_id`),
  ADD KEY `product_con_entry_product_detail_product_id` (`product_con_entry_product_detail_product_id`),
  ADD KEY `product_con_entry_product_detail_invoice_entry_id` (`product_con_entry_product_detail_invoice_entry_id`),
  ADD KEY `product_con_entry_product_detail_invoice_detail_id` (`product_con_entry_product_detail_invoice_detail_id`),
  ADD KEY `product_con_entry_product_detail_deleted_status` (`product_con_entry_product_detail_deleted_status`);

--
-- Indexes for table `product_details`
--
ALTER TABLE `product_details`
  ADD PRIMARY KEY (`product_detail_id`);

--
-- Indexes for table `product_status`
--
ALTER TABLE `product_status`
  ADD PRIMARY KEY (`product_status_id`);

--
-- Indexes for table `product_uoms`
--
ALTER TABLE `product_uoms`
  ADD PRIMARY KEY (`product_uom_id`);

--
-- Indexes for table `product_weight_cals`
--
ALTER TABLE `product_weight_cals`
  ADD UNIQUE KEY `pwc_id` (`pwc_id`);

--
-- Indexes for table `purchase_debit_note`
--
ALTER TABLE `purchase_debit_note`
  ADD PRIMARY KEY (`debitnoteId`);

--
-- Indexes for table `purchase_debit_note_child_products`
--
ALTER TABLE `purchase_debit_note_child_products`
  ADD PRIMARY KEY (`purchase_debit_note_child_product_id`),
  ADD UNIQUE KEY `purchase_debit_note_child_product_uniq_id` (`purchase_debit_note_child_product_uniq_id`),
  ADD KEY `purchase_debit_note_child_product_grn_id` (`purchase_debit_note_child_product_grn_id`),
  ADD KEY `purchase_debit_note_child_product_inv_child_detail_id` (`purchase_debit_note_child_product_inv_detail_id`),
  ADD KEY `purchase_debit_note_child_product_product_id` (`purchase_debit_note_child_product_product_id`),
  ADD KEY `purchase_debit_note_child_product_deleted_status` (`purchase_debit_note_child_product_deleted_status`);

--
-- Indexes for table `purchase_debit_note_products`
--
ALTER TABLE `purchase_debit_note_products`
  ADD PRIMARY KEY (`debitProductId`);

--
-- Indexes for table `purchase_invoice`
--
ALTER TABLE `purchase_invoice`
  ADD PRIMARY KEY (`invoiceId`);

--
-- Indexes for table `purchase_invoice_products`
--
ALTER TABLE `purchase_invoice_products`
  ADD PRIMARY KEY (`invoiceProductId`);

--
-- Indexes for table `purchase_order`
--
ALTER TABLE `purchase_order`
  ADD PRIMARY KEY (`purchaseId`);

--
-- Indexes for table `purchase_order_products`
--
ALTER TABLE `purchase_order_products`
  ADD PRIMARY KEY (`purOrdPorductId`);

--
-- Indexes for table `purchase_payment`
--
ALTER TABLE `purchase_payment`
  ADD PRIMARY KEY (`paymentId`);

--
-- Indexes for table `purchase_payment_details`
--
ALTER TABLE `purchase_payment_details`
  ADD PRIMARY KEY (`paymentInvioiceId`);

--
-- Indexes for table `quotation_entry`
--
ALTER TABLE `quotation_entry`
  ADD PRIMARY KEY (`quotation_entry_id`),
  ADD UNIQUE KEY `quotation_entry_uniq_id` (`quotation_entry_uniq_id`),
  ADD KEY `quotation_entry_company_id` (`quotation_entry_company_id`),
  ADD KEY `quotation_entry_branch_id` (`quotation_entry_branch_id`),
  ADD KEY `quotation_entry_financial_year` (`quotation_entry_financial_year`),
  ADD KEY `quotation_entry_deleted_status` (`quotation_entry_deleted_status`),
  ADD KEY `quotation_entry_customer_id` (`quotation_entry_customer_id`);

--
-- Indexes for table `quotation_entry_product_details`
--
ALTER TABLE `quotation_entry_product_details`
  ADD PRIMARY KEY (`quotation_entry_product_detail_id`),
  ADD UNIQUE KEY `quotation_entry_product_detail_uniq_id` (`quotation_entry_product_detail_uniq_id`),
  ADD KEY `quotation_entry_product_detail_quotation_entry_id` (`quotation_entry_product_detail_quotation_entry_id`),
  ADD KEY `quotation_entry_product_detail_product_id` (`quotation_entry_product_detail_product_id`),
  ADD KEY `quotation_entry_product_detail_deleted_status` (`quotation_entry_product_detail_deleted_status`);

--
-- Indexes for table `recycle_entry`
--
ALTER TABLE `recycle_entry`
  ADD PRIMARY KEY (`recycle_entry_id`),
  ADD UNIQUE KEY `recycle_entry_uniq_id` (`recycle_entry_uniq_id`),
  ADD KEY `recycle_entry_company_id` (`recycle_entry_company_id`),
  ADD KEY `recycle_entry_branch_id` (`recycle_entry_branch_id`),
  ADD KEY `recycle_entry_financial_year` (`recycle_entry_financial_year`),
  ADD KEY `recycle_entry_deleted_status` (`recycle_entry_deleted_status`);

--
-- Indexes for table `recycle_entry_product_details`
--
ALTER TABLE `recycle_entry_product_details`
  ADD PRIMARY KEY (`recycle_entry_product_detail_id`),
  ADD UNIQUE KEY `recycle_entry_product_detail_uniq_id` (`recycle_entry_product_detail_uniq_id`),
  ADD KEY `recycle_entry_product_detail_recycle_entry_id` (`recycle_entry_product_detail_recycle_entry_id`),
  ADD KEY `recycle_entry_product_detail_product_id` (`recycle_entry_product_detail_product_id`),
  ADD KEY `recycle_entry_product_detail_deleted_status` (`recycle_entry_product_detail_deleted_status`);

--
-- Indexes for table `recycle_entry_width_details`
--
ALTER TABLE `recycle_entry_width_details`
  ADD PRIMARY KEY (`recycle_entry_width_detail_id`),
  ADD UNIQUE KEY `recycle_entry_width_detail_uniq_id` (`recycle_entry_width_detail_uniq_id`),
  ADD KEY `recycle_entry_width_detail_recycle_entry_id` (`recycle_entry_width_detail_recycle_entry_id`),
  ADD KEY `recycle_entry_width_detail_product_id` (`recycle_entry_width_detail_product_id`),
  ADD KEY `recycle_entry_width_detail_deleted_status` (`recycle_entry_width_detail_deleted_status`);

--
-- Indexes for table `reserve_entry`
--
ALTER TABLE `reserve_entry`
  ADD PRIMARY KEY (`reserve_entry_id`),
  ADD UNIQUE KEY `reserve_entry_uniq_id` (`reserve_entry_uniq_id`),
  ADD KEY `reserve_entry_company_id` (`reserve_entry_company_id`),
  ADD KEY `reserve_entry_branch_id` (`reserve_entry_branch_id`),
  ADD KEY `reserve_entry_financial_year` (`reserve_entry_financial_year`),
  ADD KEY `reserve_entry_deleted_status` (`reserve_entry_deleted_status`);

--
-- Indexes for table `reserve_entry_product_details`
--
ALTER TABLE `reserve_entry_product_details`
  ADD PRIMARY KEY (`reserve_entry_product_detail_id`),
  ADD UNIQUE KEY `reserve_entry_product_detail_id` (`reserve_entry_product_detail_id`);

--
-- Indexes for table `salesmans`
--
ALTER TABLE `salesmans`
  ADD PRIMARY KEY (`salesman_id`);

--
-- Indexes for table `salesmodes`
--
ALTER TABLE `salesmodes`
  ADD PRIMARY KEY (`salesmode_id`);

--
-- Indexes for table `so_entry`
--
ALTER TABLE `so_entry`
  ADD PRIMARY KEY (`so_entry_id`),
  ADD UNIQUE KEY `so_entry_uniq_id` (`so_entry_uniq_id`),
  ADD KEY `so_entry_customer_id` (`so_entry_customer_id`),
  ADD KEY `so_entry_company_id` (`so_entry_company_id`),
  ADD KEY `so_entry_branch_id` (`so_entry_branch_id`),
  ADD KEY `so_entry_financial_year` (`so_entry_financial_year`),
  ADD KEY `so_entry_deleted_status` (`so_entry_deleted_status`);

--
-- Indexes for table `so_entry_product_details`
--
ALTER TABLE `so_entry_product_details`
  ADD PRIMARY KEY (`so_entry_product_detail_id`),
  ADD UNIQUE KEY `so_entry_product_detail_id` (`so_entry_product_detail_id`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`state_id`);

--
-- Indexes for table `stock_ledger`
--
ALTER TABLE `stock_ledger`
  ADD PRIMARY KEY (`stock_ledger_id`);

--
-- Indexes for table `stock_ledger_sales`
--
ALTER TABLE `stock_ledger_sales`
  ADD PRIMARY KEY (`stock_ledger_id`);

--
-- Indexes for table `stock_transfer`
--
ALTER TABLE `stock_transfer`
  ADD PRIMARY KEY (`stock_transfer_id`),
  ADD UNIQUE KEY `stock_transfer_uniq_id` (`stock_transfer_uniq_id`),
  ADD KEY `stock_transfer_company_id` (`stock_transfer_company_id`),
  ADD KEY `stock_transfer_branch_id` (`stock_transfer_branch_id`),
  ADD KEY `stock_transfer_financial_year` (`stock_transfer_financial_year`),
  ADD KEY `stock_transfer_deleted_status` (`stock_transfer_deleted_status`);

--
-- Indexes for table `stock_transfer_product_details`
--
ALTER TABLE `stock_transfer_product_details`
  ADD PRIMARY KEY (`stock_transfer_product_detail_id`),
  ADD UNIQUE KEY `stock_transfer_product_detail_id` (`stock_transfer_product_detail_id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`supplier_id`);

--
-- Indexes for table `supplier_multi_contacts`
--
ALTER TABLE `supplier_multi_contacts`
  ADD PRIMARY KEY (`supplier_multi_contact_id`);

--
-- Indexes for table `supplier_types`
--
ALTER TABLE `supplier_types`
  ADD PRIMARY KEY (`supplier_type_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `vendors`
--
ALTER TABLE `vendors`
  ADD PRIMARY KEY (`vendor_id`);

--
-- Indexes for table `vendor_details`
--
ALTER TABLE `vendor_details`
  ADD PRIMARY KEY (`vendor_detail_id`);

--
-- Indexes for table `width_cutting`
--
ALTER TABLE `width_cutting`
  ADD PRIMARY KEY (`width_cutting_id`),
  ADD UNIQUE KEY `width_cutting_uniq_id` (`width_cutting_uniq_id`),
  ADD KEY `width_cutting_company_id` (`width_cutting_company_id`),
  ADD KEY `width_cutting_branch_id` (`width_cutting_branch_id`),
  ADD KEY `width_cutting_financial_year` (`width_cutting_financial_year`),
  ADD KEY `width_cutting_deleted_status` (`width_cutting_deleted_status`);

--
-- Indexes for table `width_cutting_product_details`
--
ALTER TABLE `width_cutting_product_details`
  ADD PRIMARY KEY (`width_cutting_product_detail_id`),
  ADD UNIQUE KEY `width_cutting_product_detail_uniq_id` (`width_cutting_product_detail_uniq_id`),
  ADD KEY `width_cutting_product_detail_width_cutting_id` (`width_cutting_product_detail_width_cutting_id`),
  ADD KEY `width_cutting_product_detail_product_id` (`width_cutting_product_detail_product_id`),
  ADD KEY `width_cutting_product_detail_deleted_status` (`width_cutting_product_detail_deleted_status`);

--
-- Indexes for table `width_cutting_width_details`
--
ALTER TABLE `width_cutting_width_details`
  ADD PRIMARY KEY (`width_cutting_width_detail_id`),
  ADD UNIQUE KEY `width_cutting_width_detail_uniq_id` (`width_cutting_width_detail_uniq_id`),
  ADD KEY `width_cutting_width_detail_width_cutting_id` (`width_cutting_width_detail_width_cutting_id`),
  ADD KEY `width_cutting_width_detail_product_id` (`width_cutting_width_detail_product_id`),
  ADD KEY `width_cutting_width_detail_deleted_status` (`width_cutting_width_detail_deleted_status`);

--
-- Indexes for table `write_off`
--
ALTER TABLE `write_off`
  ADD PRIMARY KEY (`writeoffId`);

--
-- Indexes for table `write_off_product_detail`
--
ALTER TABLE `write_off_product_detail`
  ADD PRIMARY KEY (`writeoffProductId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account_expense_payable`
--
ALTER TABLE `account_expense_payable`
  MODIFY `expensePayId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `account_heads`
--
ALTER TABLE `account_heads`
  MODIFY `account_head_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `account_journal`
--
ALTER TABLE `account_journal`
  MODIFY `acJournalId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `account_manufacturing_costmaster`
--
ALTER TABLE `account_manufacturing_costmaster`
  MODIFY `acManuCostId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `account_manufacturing_costmaster_acs`
--
ALTER TABLE `account_manufacturing_costmaster_acs`
  MODIFY `idMcAcdetailsId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `account_manu_cost_entry`
--
ALTER TABLE `account_manu_cost_entry`
  MODIFY `manuCostEntryeId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `account_opening_balance`
--
ALTER TABLE `account_opening_balance`
  MODIFY `openingBalanceId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `account_payable`
--
ALTER TABLE `account_payable`
  MODIFY `acpayableId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `account_receivable`
--
ALTER TABLE `account_receivable`
  MODIFY `acReceivableId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `account_setup`
--
ALTER TABLE `account_setup`
  MODIFY `acountSetupId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `account_sub`
--
ALTER TABLE `account_sub`
  MODIFY `account_sub_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `account_types`
--
ALTER TABLE `account_types`
  MODIFY `account_type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `advance_entry`
--
ALTER TABLE `advance_entry`
  MODIFY `advance_entry_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `advance_entry_product_details`
--
ALTER TABLE `advance_entry_product_details`
  MODIFY `advance_entry_product_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `banks`
--
ALTER TABLE `banks`
  MODIFY `bank_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `bank_multi_contacts`
--
ALTER TABLE `bank_multi_contacts`
  MODIFY `bank_multi_contact_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `branches`
--
ALTER TABLE `branches`
  MODIFY `branch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `city_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `collection_entry`
--
ALTER TABLE `collection_entry`
  MODIFY `collection_entry_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `collection_entry_details`
--
ALTER TABLE `collection_entry_details`
  MODIFY `collection_entry_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `company_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `costing_entry`
--
ALTER TABLE `costing_entry`
  MODIFY `costingId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `costing_entry_details`
--
ALTER TABLE `costing_entry_details`
  MODIFY `costId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `country_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `credit_note_entry`
--
ALTER TABLE `credit_note_entry`
  MODIFY `credit_note_entry_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `credit_note_entry_product_details`
--
ALTER TABLE `credit_note_entry_product_details`
  MODIFY `credit_note_entry_product_detail_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `currencies`
--
ALTER TABLE `currencies`
  MODIFY `currency_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `customer_multi_contacts`
--
ALTER TABLE `customer_multi_contacts`
  MODIFY `customer_multi_contact_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `customer_types`
--
ALTER TABLE `customer_types`
  MODIFY `customer_type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `damg_missing_scrp_details`
--
ALTER TABLE `damg_missing_scrp_details`
  MODIFY `dmgMsgScrpId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `damg_missing_scrp_details_products`
--
ALTER TABLE `damg_missing_scrp_details_products`
  MODIFY `dmsProductId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `delivery_entry`
--
ALTER TABLE `delivery_entry`
  MODIFY `delivery_entry_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `delivery_entry_product_details`
--
ALTER TABLE `delivery_entry_product_details`
  MODIFY `delivery_entry_product_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `department_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `do_god_entry`
--
ALTER TABLE `do_god_entry`
  MODIFY `do_god_entry_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `do_god_entry_product_details`
--
ALTER TABLE `do_god_entry_product_details`
  MODIFY `do_god_entry_product_detail_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `employee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `emp_advance`
--
ALTER TABLE `emp_advance`
  MODIFY `empAdvanceId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `emp_attendance`
--
ALTER TABLE `emp_attendance`
  MODIFY `empAtncId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `emp_leave`
--
ALTER TABLE `emp_leave`
  MODIFY `empLeaveId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `emp_overtime`
--
ALTER TABLE `emp_overtime`
  MODIFY `empOtId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `expense_payable`
--
ALTER TABLE `expense_payable`
  MODIFY `expensePayId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gate_pass`
--
ALTER TABLE `gate_pass`
  MODIFY `gatePassId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gate_pass_product_details`
--
ALTER TABLE `gate_pass_product_details`
  MODIFY `gpProductdetailsId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gin_entry`
--
ALTER TABLE `gin_entry`
  MODIFY `gin_entry_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `gin_entry_product_details`
--
ALTER TABLE `gin_entry_product_details`
  MODIFY `gin_entry_product_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `gin_entry_raw_product_details`
--
ALTER TABLE `gin_entry_raw_product_details`
  MODIFY `gin_entry_raw_product_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `godowns`
--
ALTER TABLE `godowns`
  MODIFY `godown_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `godown_multi_contacts`
--
ALTER TABLE `godown_multi_contacts`
  MODIFY `godown_multi_contact_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `grn_child_product_details`
--
ALTER TABLE `grn_child_product_details`
  MODIFY `grn_child_product_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `grn_details`
--
ALTER TABLE `grn_details`
  MODIFY `grnId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `grn_details_products`
--
ALTER TABLE `grn_details_products`
  MODIFY `grnProdId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `grn_entry`
--
ALTER TABLE `grn_entry`
  MODIFY `grn_entry_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `grn_entry_product_details`
--
ALTER TABLE `grn_entry_product_details`
  MODIFY `grn_entry_product_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `grn_entry_raw_product_details`
--
ALTER TABLE `grn_entry_raw_product_details`
  MODIFY `grn_entry_raw_product_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `invoice_entry`
--
ALTER TABLE `invoice_entry`
  MODIFY `invoice_entry_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `invoice_entry_product_details`
--
ALTER TABLE `invoice_entry_product_details`
  MODIFY `invoice_entry_product_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `opening_stock`
--
ALTER TABLE `opening_stock`
  MODIFY `opening_stock_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `opening_stock_product_details`
--
ALTER TABLE `opening_stock_product_details`
  MODIFY `opening_stock_product_detail_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `payroll`
--
ALTER TABLE `payroll`
  MODIFY `payroll_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `pdo_entry`
--
ALTER TABLE `pdo_entry`
  MODIFY `pdo_entry_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pdo_entry_product_details`
--
ALTER TABLE `pdo_entry_product_details`
  MODIFY `pdo_entry_product_detail_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `prn_entry`
--
ALTER TABLE `prn_entry`
  MODIFY `prn_entry_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `prn_entry_product_details`
--
ALTER TABLE `prn_entry_product_details`
  MODIFY `prn_entry_product_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `production_entry`
--
ALTER TABLE `production_entry`
  MODIFY `production_entry_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `production_entry_dam_product_details`
--
ALTER TABLE `production_entry_dam_product_details`
  MODIFY `production_entry_dam_product_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `production_entry_product_details`
--
ALTER TABLE `production_entry_product_details`
  MODIFY `production_entry_product_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `production_entry_raw_product_details`
--
ALTER TABLE `production_entry_raw_product_details`
  MODIFY `production_entry_raw_product_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `production_entry_work_details`
--
ALTER TABLE `production_entry_work_details`
  MODIFY `production_entry_work_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `production_machines`
--
ALTER TABLE `production_machines`
  MODIFY `production_machine_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `production_order`
--
ALTER TABLE `production_order`
  MODIFY `production_order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `production_order_product_details`
--
ALTER TABLE `production_order_product_details`
  MODIFY `production_order_product_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `production_sections`
--
ALTER TABLE `production_sections`
  MODIFY `production_section_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `product_calculations`
--
ALTER TABLE `product_calculations`
  MODIFY `product_calculation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `product_categories`
--
ALTER TABLE `product_categories`
  MODIFY `product_category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `product_colours`
--
ALTER TABLE `product_colours`
  MODIFY `product_colour_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `product_con_entry`
--
ALTER TABLE `product_con_entry`
  MODIFY `product_con_entry_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `product_con_entry_child_product_details`
--
ALTER TABLE `product_con_entry_child_product_details`
  MODIFY `product_con_entry_child_product_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `product_con_entry_product_details`
--
ALTER TABLE `product_con_entry_product_details`
  MODIFY `product_con_entry_product_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `product_details`
--
ALTER TABLE `product_details`
  MODIFY `product_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `product_status`
--
ALTER TABLE `product_status`
  MODIFY `product_status_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `product_uoms`
--
ALTER TABLE `product_uoms`
  MODIFY `product_uom_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `product_weight_cals`
--
ALTER TABLE `product_weight_cals`
  MODIFY `pwc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `purchase_debit_note`
--
ALTER TABLE `purchase_debit_note`
  MODIFY `debitnoteId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `purchase_debit_note_child_products`
--
ALTER TABLE `purchase_debit_note_child_products`
  MODIFY `purchase_debit_note_child_product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `purchase_debit_note_products`
--
ALTER TABLE `purchase_debit_note_products`
  MODIFY `debitProductId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `purchase_invoice`
--
ALTER TABLE `purchase_invoice`
  MODIFY `invoiceId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `purchase_invoice_products`
--
ALTER TABLE `purchase_invoice_products`
  MODIFY `invoiceProductId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `purchase_order`
--
ALTER TABLE `purchase_order`
  MODIFY `purchaseId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `purchase_order_products`
--
ALTER TABLE `purchase_order_products`
  MODIFY `purOrdPorductId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `purchase_payment`
--
ALTER TABLE `purchase_payment`
  MODIFY `paymentId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `purchase_payment_details`
--
ALTER TABLE `purchase_payment_details`
  MODIFY `paymentInvioiceId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `quotation_entry`
--
ALTER TABLE `quotation_entry`
  MODIFY `quotation_entry_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `quotation_entry_product_details`
--
ALTER TABLE `quotation_entry_product_details`
  MODIFY `quotation_entry_product_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `recycle_entry`
--
ALTER TABLE `recycle_entry`
  MODIFY `recycle_entry_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `recycle_entry_product_details`
--
ALTER TABLE `recycle_entry_product_details`
  MODIFY `recycle_entry_product_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `recycle_entry_width_details`
--
ALTER TABLE `recycle_entry_width_details`
  MODIFY `recycle_entry_width_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `reserve_entry`
--
ALTER TABLE `reserve_entry`
  MODIFY `reserve_entry_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `reserve_entry_product_details`
--
ALTER TABLE `reserve_entry_product_details`
  MODIFY `reserve_entry_product_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `salesmans`
--
ALTER TABLE `salesmans`
  MODIFY `salesman_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `salesmodes`
--
ALTER TABLE `salesmodes`
  MODIFY `salesmode_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `so_entry`
--
ALTER TABLE `so_entry`
  MODIFY `so_entry_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `so_entry_product_details`
--
ALTER TABLE `so_entry_product_details`
  MODIFY `so_entry_product_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `state_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `stock_ledger`
--
ALTER TABLE `stock_ledger`
  MODIFY `stock_ledger_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;
--
-- AUTO_INCREMENT for table `stock_ledger_sales`
--
ALTER TABLE `stock_ledger_sales`
  MODIFY `stock_ledger_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `stock_transfer`
--
ALTER TABLE `stock_transfer`
  MODIFY `stock_transfer_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `stock_transfer_product_details`
--
ALTER TABLE `stock_transfer_product_details`
  MODIFY `stock_transfer_product_detail_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `supplier_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `supplier_multi_contacts`
--
ALTER TABLE `supplier_multi_contacts`
  MODIFY `supplier_multi_contact_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `supplier_types`
--
ALTER TABLE `supplier_types`
  MODIFY `supplier_type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `vendors`
--
ALTER TABLE `vendors`
  MODIFY `vendor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `vendor_details`
--
ALTER TABLE `vendor_details`
  MODIFY `vendor_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `width_cutting`
--
ALTER TABLE `width_cutting`
  MODIFY `width_cutting_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `width_cutting_product_details`
--
ALTER TABLE `width_cutting_product_details`
  MODIFY `width_cutting_product_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `width_cutting_width_details`
--
ALTER TABLE `width_cutting_width_details`
  MODIFY `width_cutting_width_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `write_off`
--
ALTER TABLE `write_off`
  MODIFY `writeoffId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `write_off_product_detail`
--
ALTER TABLE `write_off_product_detail`
  MODIFY `writeoffProductId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
